# DARK_SURF PRO et ADMIN — applications vendeur et administrateur (Android)

Coquille WebView autour de **ton** portail (vendeur ou administrateur, selon le compte), verrouillée par un code d'activation signé et lié au téléphone.

## Ce que contient l'appli (V12)
- Barre d'icônes en bas, **une page par icône** : PRO = Vendre · Mes clés · Appareils · Crédits ; ADMIN = Accueil · Clients · Forfaits · Protocoles · Plus (demandes, annonces, versions, activation vendeur, nouveau vendeur, journal).
- Thème auto / sombre / clair et Français / English (menu OUTILS).
- À la création d'une clé, le vendeur choisit 1 à 3 appareils ; les forfaits illimités sont plafonnés à 30 Go par 24 h (géré par le serveur).
- `PORTAL_URL` = https://vpn.zidanexmd.space/ et `ACTIVATION_PUBLIC_KEY` (clé publique de seller-private.pem) sont déjà renseignés.
- L'appli ADMIN n'a pas de code d'activation (ton compte admin protège le portail) ; l'appli PRO en exige un.
- Compilation : `./gradlew assembleSellerRelease assembleAdminRelease` (Android Studio ou GitHub Actions, workflow fourni).

## Donner accès à un vendeur (le plus simple)
1. Le vendeur installe DARK_SURF PRO : l'appli affiche l'**identifiant du téléphone** (AAAA-BBBB-CCCC-DDDD-EEEE) et un bouton WhatsApp.
2. Dans l'appli ADMIN : **Plus → Activation vendeur** → colle l'identifiant, mets le nom et la durée, **Générer le code**, puis « Envoyer par WhatsApp ».
   (La première fois, colle le contenu de `seller-private.pem` dans cette page : la clé est enregistrée sur le serveur.)
3. Le vendeur colle le code dans l'appli : il ne marche que sur ce téléphone et expire à la date prévue (0 jour = illimité).
Alternative sur PC : `node tools/activation.js issue --device AAAA-BBBB-CCCC-DDDD-EEEE --days 30 --label "Nom" --key seller-private.pem`.
Garde `seller-private.pem` secret : qui l'a peut autoriser n'importe quel téléphone.

## Contrat avec ton portail
Pour la connexion automatique (page `/login` du serveur DARK_SURF, déjà conforme), la page de connexion doit contenir `<form id="form">`, `<input id="login">` et `<input id="password">`.
Le revendeur saisit son identifiant une seule fois ; il est stocké chiffré (AndroidKeyStore), jamais dans le code.
L'appli s'arrête après 2 tentatives refusées pour ne pas bloquer le compte.

## Sécurité
- HTTPS uniquement, un seul hôte autorisé, certificats invalides refusés, liens externes ouverts hors de l'appli.
- Aucun identifiant ni clé privée dans l'APK ; seule la clé publique y figure.
- Limite : l'heure du téléphone sert à l'expiration (un téléphone dont l'horloge est reculée prolonge un code).


## Identité des applications
- `sellerDebug` / `sellerRelease` : DARK_SURF PRO avec icône Android dédiée.
- `adminDebug` / `adminRelease` : DARK_SURF ADMIN avec icône Android dédiée.
- Le portail V8 affiche le prix des forfaits en crédits et en FCFA (1 crédit = 100 FCFA), ainsi que le coût total de la vente dans les deux unités.
