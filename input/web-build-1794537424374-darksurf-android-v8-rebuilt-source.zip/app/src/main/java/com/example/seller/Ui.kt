package com.example.seller

import android.content.Context
import android.content.res.Resources
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** Même identité que l'app DARK_SURF : fond sombre, menthe + ambre, polices mixées. */
object Ds {
    val BG = Color.parseColor("#070B14")
    val SURFACE = Color.parseColor("#0F1626")
    val SURFACE2 = Color.parseColor("#172034")
    val LINE = Color.parseColor("#243049")
    val GREEN = Color.parseColor("#2EE6A8")
    val YELLOW = Color.parseColor("#E6A45B")
    val TEXT = Color.parseColor("#EAF0FA")
    val MUTED = Color.parseColor("#8493AD")
    val DANGER = Color.parseColor("#FF6B6B")
    val DISPLAY: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    val BLACK: Typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
    val BODY: Typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    val MONO: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    val ACCENT: Typeface = Typeface.create("serif", Typeface.ITALIC)
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

val Int.dp: Int get() = (this * Resources.getSystem().displayMetrics.density).toInt()
val Float.dp: Float get() = this * Resources.getSystem().displayMetrics.density

fun rect(fill: Int, radius: Float = 16f, stroke: Int = 0, strokeW: Int = 1) = GradientDrawable().apply {
    setColor(fill); cornerRadius = radius.dp
    if (stroke != 0) setStroke(strokeW.dp, stroke)
}

fun gradient(radius: Float = 16f) =
    GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Ds.GREEN, Ds.YELLOW)).apply { cornerRadius = radius.dp }

fun lin(w: Int = MATCH, h: Int = WRAP, top: Int = 0, weight: Float = 0f) =
    LinearLayout.LayoutParams(w, h, weight).apply { topMargin = top.dp }

fun Context.tv(s: CharSequence, size: Float, color: Int = Ds.TEXT, font: Typeface = Ds.BODY, spacing: Float = 0f) =
    TextView(this).apply { text = s; textSize = size; setTextColor(color); typeface = font; letterSpacing = spacing }

fun Context.col(pad: Int = 0) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; setPadding(pad.dp, pad.dp, pad.dp, pad.dp)
}

fun Context.row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

fun Context.overline(s: String) = tv(s.uppercase(), 11f, Ds.MUTED, Ds.MONO, 0.18f)

fun Context.primaryButton(label: String, onClick: () -> Unit) =
    tv(label.uppercase(), 15f, Ds.BG, Ds.DISPLAY, 0.14f).apply {
        gravity = Gravity.CENTER; background = gradient(16f); minHeight = 52.dp
        setOnClickListener { onClick() }
    }

fun Context.ghostButton(label: String, color: Int = Ds.GREEN, onClick: () -> Unit) =
    tv(label.uppercase(), 13f, color, Ds.DISPLAY, 0.14f).apply {
        gravity = Gravity.CENTER; background = rect(0, 16f, color, 1); minHeight = 48.dp
        setOnClickListener { onClick() }
    }

/** Logo provisoire (anneau dégradé + vagues). À remplacer par le tien. */
class LogoView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat(); val cx = width / 2f; val cy = height / 2f
        p.shader = LinearGradient(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2, Ds.GREEN, Ds.YELLOW, Shader.TileMode.CLAMP)
        p.strokeWidth = s * 0.07f
        cv.drawCircle(cx, cy, s * 0.42f, p)
        for ((k, dy) in listOf(-0.10f, 0.12f).withIndex()) {
            val x0 = cx - s * 0.26f; val w = s * 0.52f; val y = cy + s * dy
            val path = Path().apply {
                moveTo(x0, y)
                quadTo(x0 + w * 0.25f, y - s * 0.14f, x0 + w * 0.5f, y)
                quadTo(x0 + w * 0.75f, y + s * 0.14f, x0 + w, y)
            }
            p.strokeWidth = s * (if (k == 0) 0.07f else 0.05f)
            cv.drawPath(path, p)
        }
    }
}
