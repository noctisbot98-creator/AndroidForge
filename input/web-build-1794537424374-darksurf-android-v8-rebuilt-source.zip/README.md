# DARK_SURF PRO et ADMIN — applications vendeur et administrateur (Android)

Coquille WebView autour de **ton** portail (vendeur ou administrateur, selon le compte), verrouillée par un code d'activation signé et lié au téléphone.

## Mise en route
1. `node tools/activation.js keygen tools/` → crée `seller-private.pem` (**secrète**, reste sur ton PC/serveur) et `seller-public.b64`.
2. Dans `app/build.gradle.kts`, renseigne :
   - `PORTAL_URL` : adresse HTTPS de ton portail (seul cet hôte est autorisé dans l'appli) ;
   - `ACTIVATION_PUBLIC_KEY` : contenu de `seller-public.b64` ;
   - `SUPPORT_WHATSAPP` : numéro qui reçoit les demandes d'accès (format international, sans « + »).
3. Ouvre le dossier dans Android Studio. Deux variantes : `sellerRelease` (DARK_SURF PRO, pour les vendeurs) et `adminRelease`
   (DARK_SURF ADMIN, pour toi seul) : `./gradlew assembleSellerRelease assembleAdminRelease`.
   Le portail montre à chacun son espace : le vendeur génère/recharge des clés avec ses crédits ; l'administrateur crée les vendeurs,
   recharge leurs crédits, voit clés actives, forfaits et consommations, gère la grille des forfaits et publie des annonces.

## Donner accès à un vendeur
1. Le vendeur ouvre l'appli : elle affiche son **identifiant** (AAAA-BBBB-CCCC-DDDD-EEEE) et propose de te l'envoyer par WhatsApp.
2. Toi : `node tools/activation.js issue --device AAAA-BBBB-CCCC-DDDD-EEEE --days 30 --label "Nom" --key tools/seller-private.pem`
3. Tu lui renvoies le code ; il le colle dans l'appli. Le code ne marche que sur ce téléphone et expire à la date prévue (`--days 0` = illimité).
4. Test : `node tools/test.js`

## Contrat avec ton portail
Pour la connexion automatique (page `/login` du serveur DARK_SURF, déjà conforme), la page de connexion doit contenir `<form id="form">`, `<input id="login">` et `<input id="password">`.
Le revendeur saisit son identifiant une seule fois ; il est stocké chiffré (AndroidKeyStore), jamais dans le code.
L'appli s'arrête après 2 tentatives refusées pour ne pas bloquer le compte.

## Sécurité
- HTTPS uniquement, un seul hôte autorisé, certificats invalides refusés, liens externes ouverts hors de l'appli.
- Aucun identifiant ni clé privée dans l'APK ; seule la clé publique y figure.
- Limite : l'heure du téléphone sert à l'expiration (un téléphone dont l'horloge est reculée prolonge un code).


## Identité des applications
- `sellerDebug` / `sellerRelease` : DARK_SURF PRO avec icône Android dédiée.
- `adminDebug` / `adminRelease` : DARK_SURF ADMIN avec icône Android dédiée.
- Le portail V8 affiche le prix des forfaits en crédits et en FCFA (1 crédit = 100 FCFA), ainsi que le coût total de la vente dans les deux unités.
