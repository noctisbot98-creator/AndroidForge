const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const nodePath = require('path');
const cfgMod = require('./config');
const dbMod = require('./db');
const { makeBackend } = require('./core');
const { Service, HttpError } = require('./service');
const S = require('./security');
const P = require('./portal');

const SID = 'ds_sid';

function createApp(overrides = {}) {
  const cfg = { ...cfgMod.load(), ...overrides };
  cfg.core = { ...cfgMod.load().wg, ...(overrides.core || {}) };
  const db = overrides.db || dbMod.open(cfg.dbPath);
  const core = overrides.coreBackend || makeBackend(cfg.core);
  const service = new Service({ db, cfg, core, clock: overrides.clock });

  const apiLimit = new S.RateLimiter(600, 60_000);         // 600 requêtes / minute / IP (réseaux mobiles : beaucoup d'abonnés derrière la même adresse)
  const loginLimit = new S.RateLimiter(8, 15 * 60_000);     // 8 tentatives / 15 min / IP
  const flashes = new Map();                                // sid -> clé de message (une seule lecture)

  const clientIp = (req) => (cfg.trustProxy && req.headers['x-forwarded-for']
    ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : req.socket.remoteAddress) || '?';
  const isSecure = (req) => cfg.cookieSecure || (cfg.trustProxy && req.headers['x-forwarded-proto'] === 'https');

  function readBody(req, max = 16_384) {
    return new Promise((resolve, reject) => {
      let size = 0; const chunks = [];
      req.on('data', (c) => { size += c.length; if (size > max) { reject(new HttpError(413, 'too_large')); req.destroy(); } else chunks.push(c); });
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      req.on('error', reject);
    });
  }

  const cookies = (req) => Object.fromEntries(String(req.headers.cookie || '').split(';').map((c) => c.trim().split('=')).filter((p) => p[0]).map(([k, ...v]) => [k, v.join('=')]));

  function sendJson(res, status, obj) {
    res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    res.end(JSON.stringify(obj));
  }

  function sendHtml(req, res, status, render, extra = {}) {
    const nonce = crypto.randomBytes(16).toString('base64');
    const headers = {
      'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'same-origin', 'X-Frame-Options': 'DENY',
      'Content-Security-Policy': `default-src 'none'; style-src 'nonce-${nonce}'; style-src-attr 'unsafe-inline'; script-src 'nonce-${nonce}'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'`,
      ...extra,
    };
    if (isSecure(req)) headers['Strict-Transport-Security'] = 'max-age=31536000';
    res.writeHead(status, headers);
    res.end(render(nonce));
  }

  const redirect = (res, to, extra = {}) => { res.writeHead(303, { Location: to, 'Cache-Control': 'no-store', ...extra }); res.end(); };

  // Protection CSRF : cookie SameSite=Strict + vérification de l'origine + jeton lié à la session.
  function sameOrigin(req) {
    const site = req.headers['sec-fetch-site'];            // Fetch Metadata : fiable, posé par le navigateur
    if (site === 'same-origin') return true;
    if (site) return false;                                // cross-site, same-site, none sur un POST → refusé
    const o = req.headers.origin;
    if (!o) return true;                                   // clients sans navigateur (curl, tests)
    if (o === 'null') return false;
    try {
      const host = (cfg.trustProxy && req.headers['x-forwarded-host']) || req.headers.host;
      return new URL(o).host === host;
    } catch { return false; }
  }
  const tokenOk = (a, b) => typeof a === 'string' && typeof b === 'string' && a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));

  // ------------------------------------------------------------------ API client
  const API = {
    enroll: (b) => service.enroll(b),
    challenge: (b) => service.challenge(b),
    session: (b) => service.session(b),
    status: (b) => service.status(b),
    'app/android': (b, req) => {
      const r = service.checkApp(b);
      if (r.update) { r.url = `${publicBase(req)}/downloads/${r.file}`; delete r.file; }
      return r;
    },
  };
  const publicBase = (req) => cfg.publicUrl || `${isSecure(req) ? 'https' : 'http'}://${req.headers.host}`;
  const dlLimit = new S.RateLimiter(30, 60_000);

  async function handleApi(req, res, name) {
    if (!apiLimit.allow(clientIp(req))) return sendJson(res, 429, { error: 'rate_limited' });
    if (req.method !== 'POST' || !API[name]) return sendJson(res, 404, { error: 'not_found' });
    let body;
    try { body = JSON.parse(await readBody(req, 8192)); } catch (e) {
      return sendJson(res, e instanceof HttpError ? e.status : 400, { error: e instanceof HttpError ? e.code : 'bad_json' });
    }
    if (!body || typeof body !== 'object' || Array.isArray(body)) return sendJson(res, 400, { error: 'bad_json' });
    try { sendJson(res, 200, await API[name](body, req)); } catch (e) {
      if (e instanceof HttpError) return sendJson(res, e.status, { error: e.code });
      console.error('api error', e); sendJson(res, 500, { error: 'server_error' });
    }
  }

  // ------------------------------------------------------- téléchargement des APK publiés
  function handleDownload(req, res, url) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return sendJson(res, 405, { error: 'method_not_allowed' });
    if (!dlLimit.allow(clientIp(req))) return sendJson(res, 429, { error: 'rate_limited' });
    const name = url.pathname.slice('/downloads/'.length);
    if (!/^darksurf-\d+\.apk$/.test(name)) return sendJson(res, 404, { error: 'not_found' });          // pas de traversée de chemin
    const rel = db.prepare('SELECT * FROM releases WHERE file_name = ? AND active = 1').get(name);
    const file = nodePath.join(nodePath.resolve(cfg.releasesDir), name);
    if (!rel || !fs.existsSync(file)) return sendJson(res, 404, { error: 'not_found' });
    res.writeHead(200, {
      'Content-Type': 'application/vnd.android.package-archive', 'Content-Length': fs.statSync(file).size,
      'Content-Disposition': `attachment; filename="${name}"`, 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store',
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
  }

  // ---------------------------------------------------------------------- portail
  const randomPassword = () => crypto.randomBytes(12).toString('base64url');
  const csvCell = (v) => { const s = String(v ?? ''); return '"' + (/^[=+\-@\t\r]/.test(s) ? "'" + s : s).replace(/"/g, '""') + '"'; };
  const isoDate = (t) => (t ? new Date(t * 1000).toISOString() : '');
  const FLASHABLE = new Set(['insufficient_credit', 'bad_plan', 'bad_quantity', 'code_revoked', 'not_activated', 'bad_login', 'bad_password',
    'bad_amount', 'login_taken', 'plan_exists', 'bad_notice', 'not_found', 'rate_limited', 'limit_reached', 'trial_plan', 'note_required', 'too_many_requests', 'seller_has_keys', 'admin_cannot_sell']);

  // Où revenir après une erreur de formulaire.
  function backFor(path, form) {
    if (path === '/sell') return '/sell';
    if (path === '/recharge') return `/recharge?code=${encodeURIComponent(form.get('code') || '')}`;
    if (path.startsWith('/devices') && String(form.get('back') || '').startsWith('/admin/clients/')) return form.get('back');
    if (path.startsWith('/devices')) return '/devices';
    if (path === '/credits/request') return '/credits';
    if (path === '/admin/sellers') return '/admin/sellers/new';
    const m = path.match(/^\/admin\/sellers\/(\d+)\//);
    if (m) return `/admin/sellers/${m[1]}`;
    if (path.startsWith('/admin/plans')) return '/admin/plans';
    if (path.startsWith('/admin/notices')) return '/admin/notices';
    if (path.startsWith('/admin/requests')) return '/admin/requests';
    if (path === '/codes/revoke' && String(form.get('back') || '').startsWith('/admin/')) return form.get('back');
    return '/codes';
  }

  async function handlePortal(req, res, url) {
    const path = url.pathname;
    const sid = cookies(req)[SID];
    const session = service.session_(sid);
    const now = service.now();
    const page = (status, render) => sendHtml(req, res, status, render);
    const notFound = () => page(404, (n) => P.messagePage({ nonce: n, title: 'Introuvable', text: 'Cette page n\'existe pas.' }));

    if (req.method === 'POST' && !sameOrigin(req)) return page(403, (n) => P.messagePage({ nonce: n, title: 'Refusé', text: 'Origine invalide.' }));

    if (path === '/login') {
      const home = (s) => (s.reseller.role === 'admin' ? '/admin' : '/sell');
      if (req.method === 'GET') return session ? redirect(res, home(session)) : page(200, (n) => P.loginPage({ nonce: n }));
      if (req.method === 'POST') {
        const form = new URLSearchParams(await readBody(req));
        if (!loginLimit.allow(clientIp(req))) return page(429, (n) => P.loginPage({ nonce: n, error: 'Trop de tentatives. Patientez quelques minutes.' }));
        const s = service.login(form.get('login'), form.get('password'));
        if (s) { const who = service.session_(s.sid).reseller; if (who.role === 'admin') service.audit(who.login, 'Connexion administrateur', clientIp(req)); }
        if (!s) return page(401, (n) => P.loginPage({ nonce: n, error: 'Identifiant ou mot de passe incorrect.' }));
        const cookie = `${SID}=${s.sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${isSecure(req) ? '; Secure' : ''}`;
        return redirect(res, '/', { 'Set-Cookie': cookie });
      }
    }

    if (!session) return redirect(res, '/login');
    const me = session.reseller, admin = me.role === 'admin';
    if (path.startsWith('/admin') && !admin) return page(403, (n) => P.messagePage({ nonce: n, title: 'Accès refusé', text: 'Cette page est réservée à l\'administrateur.' }));
    const flashKey = flashes.get(sid); flashes.delete(sid);
    if (flashes.size > 5000) flashes.clear();
    const setFlash = (k) => flashes.set(sid, k);
    const sellerNotices = () => service.noticesFor('sellers');

    if (admin && /^\/(sell|codes|codes\.csv|recharge|devices|credits)$/.test(path)) return redirect(res, '/admin');   // l'administrateur ne vend pas
    if (req.method === 'GET') {
      if (path === '/') return redirect(res, admin ? '/admin' : '/sell');
      if (path === '/sell') return page(200, (n) => P.sellPage({ nonce: n, session, plans: service.plansFor(me), flashKey, notices: sellerNotices() }));
      if (path === '/codes') {
        return page(200, (n) => P.keysPage({ nonce: n, session, codes: service.listCodes(me.id), stats: service.stats(me.id), flashKey, now }));
      }
      if (path === '/recharge') {
        const code = service.getCode(me, url.searchParams.get('code') || '');
        if (!code) return notFound();
        return page(200, (n) => P.rechargePage({ nonce: n, session, code, plans: service.plansFor(me), flashKey, now }));
      }
      if (path === '/devices') return page(200, (n) => P.devicesPage({ nonce: n, session, devices: service.listDevices(me.id), flashKey, now }));
      if (path === '/credits') return page(200, (n) => P.creditsPage({ nonce: n, session, ledger: service.ledger(me.id), notices: sellerNotices(), requests: service.myRequests(me.id), phone: cfg.supportPhone, flashKey }));
      if (path === '/codes.csv') {
        const rows = [['code', 'forfait', 'note', 'cree', 'active', 'expire', 'revoque', 'appareils', 'donnees_utilisees_octets']].concat(
          service.listCodes(me.id, 5000).map((c) => [c.code, c.plan_name, c.note, isoDate(c.created_at), isoDate(c.activated_at), isoDate(c.expires_at), c.revoked ? 'oui' : 'non', c.devices, c.used]));
        res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="cles.csv"', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
        return res.end(rows.map((r) => r.map(csvCell).join(',')).join('\r\n') + '\r\n');
      }
      if (admin) {
        if (path === '/admin') {
          const [info, cl] = await Promise.all([service.serverInfo(), service.adminClients({ limit: 0 })]);
          return page(200, (n) => P.adminDashboard({ nonce: n, session, stats: service.adminStats(), sellers: service.listSellers(), flashKey, notices: [], info, bySeller: cl.bySeller, counts: cl.counts }));
        }
        if (path === '/admin/clients') {
          const f = { q: (url.searchParams.get('q') || '').slice(0, 60), state: ['all', 'online', 'active', 'expired', 'quota', 'unused', 'revoked'].includes(url.searchParams.get('state')) ? url.searchParams.get('state') : 'all', seller: Number(url.searchParams.get('seller')) || 0 };
          const data = await service.adminClients(f);
          return page(200, (n) => P.clientsPage({ nonce: n, session, data, sellers: service.listSellers(), f, now }));
        }
        const cm = path.match(/^\/admin\/clients\/([A-Za-z0-9_-]{8,80})$/);
        if (cm) {
          const c = await service.adminClient(cm[1]);
          return c ? page(200, (n) => P.clientPage({ nonce: n, session, c, flashKey, now })) : notFound();
        }
        if (path === '/admin/requests') return page(200, (n) => P.requestsPage({ nonce: n, session, requests: service.listRequests(), flashKey }));
        if (path === '/admin/audit') return page(200, (n) => P.auditPage({ nonce: n, session, rows: service.auditLog() }));
        if (path === '/admin/sellers/new') return page(200, (n) => P.sellerNewPage({ nonce: n, session, flashKey }));
        const sm = path.match(/^\/admin\/sellers\/(\d+)$/);
        if (sm) {
          const seller = service.getSeller(sm[1]);
          if (!seller) return notFound();
          return page(200, (n) => P.sellerPage({ nonce: n, session, seller, codes: service.listCodes(seller.id), ledger: service.ledger(seller.id), flashKey, now }));
        }
        if (path === '/admin/plans') return page(200, (n) => P.plansAdminPage({ nonce: n, session, plans: service.allPlans(), flashKey }));
        if (path === '/admin/notices') return page(200, (n) => P.noticesAdminPage({ nonce: n, session, notices: service.allNotices(), flashKey }));
        if (path === '/admin/releases') return page(200, (n) => P.releasesAdminPage({ nonce: n, session, releases: service.releases() }));
      }
      return notFound();
    }

    if (req.method === 'POST') {
      const form = new URLSearchParams(await readBody(req));
      if (!tokenOk(form.get('csrf'), session.csrf)) return page(403, (n) => P.messagePage({ nonce: n, title: 'Refusé', text: 'Jeton de sécurité invalide. Recharge la page.' }));
      try {
        if (path === '/logout') { service.logout(sid); return redirect(res, '/login', { 'Set-Cookie': `${SID}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0` }); }
        if (path === '/credits/request') {
          service.requestRecharge(me, form.get('credits'));
          setFlash('requested'); return redirect(res, '/credits');
        }
        if (path === '/sell') {
          const created = service.generateCodes(me, form.get('plan'), form.get('qty'), form.get('note'));
          return page(200, (n) => P.createdPage({ nonce: n, session: service.session_(sid), created }));
        }
        if (path === '/recharge') {
          await service.rechargeCode(me, form.get('code'), form.get('plan'));
          setFlash('recharged'); return redirect(res, '/codes');
        }
        if (path === '/codes/revoke') {
          await service.revokeCode(me, form.get('code'));
          service.audit(me.login, 'Clé révoquée', String(form.get('code')).slice(0, 12) + '…');
          setFlash('revoked');
          const back = form.get('back');
          return redirect(res, admin && (/^\/admin\/sellers\/\d+$/.test(back || '') || /^\/admin\/clients\/[A-Za-z0-9_-]+$/.test(back || '')) ? back : '/codes');
        }
        const dm = path.match(/^\/devices\/([0-9a-f-]{36})\/(toggle|delete)$/);
        if (dm) { await service.setDevice(me, dm[1], dm[2]); service.audit(me.login, 'Appareil ' + dm[2], dm[1].slice(0, 8)); setFlash('device'); const b = form.get('back'); return redirect(res, admin && /^\/admin\/clients\/[A-Za-z0-9_-]+$/.test(b || '') ? b : '/devices'); }

        if (admin) {
          if (path === '/admin/sellers') {
            const password = (form.get('password') || '').trim() || randomPassword();
            const id = service.createSeller({ login: form.get('login'), name: form.get('name'), password, credits: form.get('credits') || 0 });
            const seller = service.getSeller(id);
            service.audit(me.login, 'Vendeur créé', seller.login);
            return page(200, (n) => P.secretPage({ nonce: n, session, title: 'Vendeur créé', login: seller.login, password, sellerId: id }));
          }
          const am = path.match(/^\/admin\/sellers\/(\d+)\/(credit|toggle|password|delete)$/);
          if (am) {
            const id = Number(am[1]);
            const seller = service.getSeller(id);
            if (!seller) throw new HttpError(404, 'not_found');
            if (am[2] === 'credit') {
              const remove = form.get('mode') === 'remove';
              if (remove && !String(form.get('note') || '').trim()) throw new HttpError(400, 'note_required');
              const raw = String(form.get('amount') || '').trim();
              if (raw.startsWith('-')) throw new HttpError(400, 'bad_amount');
              service.addCredits(id, remove ? '-' + raw : raw, form.get('note'));
              service.audit(me.login, remove ? 'Crédits retirés' : 'Crédits ajoutés', `${seller.login} : ${raw}${form.get('note') ? ' — ' + String(form.get('note')).slice(0, 80) : ''}`);
              setFlash('credited'); return redirect(res, `/admin/sellers/${id}`);
            }
            if (am[2] === 'delete') { service.deleteSeller(id); service.audit(me.login, 'Vendeur supprimé', seller.login); setFlash('deleted'); return redirect(res, '/admin'); }
            if (am[2] === 'toggle') { service.setSellerActive(id, !seller.active); service.audit(me.login, seller.active ? 'Vendeur suspendu' : 'Vendeur réactivé', seller.login); setFlash('saved'); return redirect(res, `/admin/sellers/${id}`); }
            const password = randomPassword();
            service.resetPassword(id, password);
            service.audit(me.login, 'Mot de passe réinitialisé', seller.login);
            return page(200, (n) => P.secretPage({ nonce: n, session, title: 'Nouveau mot de passe', login: seller.login, password, sellerId: id }));
          }
          if (path === '/admin/plans/seed') { const n = service.seedPlans(); service.audit(me.login, 'Forfaits Geny chargés', `${n} créés`); setFlash('seeded'); return redirect(res, '/admin/plans'); }
          if (path === '/admin/plans') {
            const hrs = form.get('unit') === 'hours';
            service.createPlan({ name: form.get('name'), hours: hrs ? form.get('duration') : undefined, days: hrs ? undefined : form.get('duration'),
              quotaGb: String(form.get('quota_gb') || '').replace(',', '.'), unlimited: form.get('unlimited') === '1' || !form.get('quota_gb'),
              credits: form.get('credits'), devices: 1, window: (form.get('window') || '').trim() || undefined, limit: form.get('limit') || undefined,
              position: 100 });
            service.audit(me.login, 'Forfait créé', String(form.get('name')).slice(0, 40));
            setFlash('saved'); return redirect(res, '/admin/plans');
          }
          const pm = path.match(/^\/admin\/plans\/(\d+)$/);
          if (pm) {
            service.audit(me.login, 'Forfait modifié', `#${pm[1]}`);
            service.updatePlan(pm[1], { credits: form.has('credits') ? form.get('credits') : undefined, active: form.has('active') ? form.get('active') === '1' : undefined });
            setFlash('saved'); return redirect(res, '/admin/plans');
          }
          const rq = path.match(/^\/admin\/requests\/(\d+)\/(accept|refuse)$/);
          if (rq) { const r = service.decideRequest(rq[1], rq[2] === 'accept'); service.audit(me.login, rq[2] === 'accept' ? 'Demande acceptée' : 'Demande refusée', `#${r.id} ${r.amount} F`); setFlash(rq[2] === 'accept' ? 'accepted' : 'refused'); return redirect(res, '/admin/requests'); }
          if (path === '/admin/notices') {
            service.createNotice({ audience: form.get('audience'), title: form.get('title'), body: form.get('body'), days: form.get('days') });
            setFlash('saved'); return redirect(res, '/admin/notices');
          }
          const nm = path.match(/^\/admin\/notices\/(\d+)\/remove$/);
          if (nm) { service.removeNotice(nm[1]); setFlash('saved'); return redirect(res, '/admin/notices'); }
        }
      } catch (e) {
        if (e instanceof HttpError) { setFlash(FLASHABLE.has(e.code) ? e.code : 'error'); return redirect(res, backFor(path, form)); }
        throw e;
      }
    }
    return notFound();
  }

  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://x');
      if (url.pathname.startsWith('/api/v1/')) {
        // Journal minimal des appels de l'appli (sans corps ni secrets) : permet de voir où une connexion s'arrête.
        res.on('finish', () => { if (!process.env.DS_QUIET) console.log(`api ${req.method} ${url.pathname} -> ${res.statusCode}`); });
        return await handleApi(req, res, url.pathname.slice(8));
      }
      if (url.pathname.startsWith('/downloads/')) return handleDownload(req, res, url);
      if (url.pathname === '/healthz') return sendJson(res, 200, { ok: true });
      return await handlePortal(req, res, url);
    } catch (e) {
      if (e instanceof HttpError) return sendJson(res, e.status, { error: e.code });
      console.error('erreur', e);
      if (!res.headersSent) sendJson(res, 500, { error: 'server_error' });
    }
  });
  server.headersTimeout = 15_000; server.requestTimeout = 20_000;

  let timer = null;
  const start = () => new Promise((resolve) => {
    service.enforce().catch(() => {});                                   // resynchronise les pairs au démarrage
    timer = setInterval(() => service.enforce().catch((e) => console.error('enforce', e)), cfg.enforceIntervalMs);
    timer.unref();
    server.listen(cfg.port, cfg.host, () => resolve(server.address().port));
  });
  const close = () => new Promise((resolve) => { clearInterval(timer); server.close(() => { db.close(); resolve(); }); });

  return { server, service, cfg, db, core, start, close };
}

module.exports = { createApp };

if (require.main === module) {
  const app = createApp();
  app.start().then((port) => console.log(`DARK_SURF server : http://${app.cfg.host}:${port} (CORE_MODE=${app.cfg.core.mode})`));
  const stop = () => app.close().then(() => process.exit(0));
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
}
