# DARK SURF — audit technique initial

## Architecture confirmée dans les sources fournies
- Android : `VpnService` + moteur `libv2ray.aar` AndroidLibXrayLite v26.10.31.
- Tunnel : VLESS / WebSocket / TLS vers le serveur, port public 443.
- Serveur : Xray écoute sur `127.0.0.1:10000`; Caddy termine TLS et relaie le chemin WebSocket vers Xray.
- API Xray : `127.0.0.1:10085`, non destinée à être exposée sur Internet.
- Les clés et l'association cryptographique appareil sont conservées ; aucune base ni clé de production n'a été modifiée.

## Points à vérifier avant tout changement de transport
1. Le serveur installe « Xray latest » si aucun binaire n'est déjà présent, tandis que l'application embarque une version AndroidLibXrayLite fixe (v26.10.31). La compatibilité exacte des deux moteurs n'est donc pas garantie par les sources.
2. L'application marque le tunnel comme démarré dès que `startLoop()` revient, sans test de trafic de bout en bout. Cet état technique ne prouve pas à lui seul que le trafic Internet traverse réellement le tunnel.
3. Le profil Android utilise `sni` aussi comme valeur de l'en-tête HTTP `Host`. C'est cohérent avec le profil serveur actuel, mais devra être distingué si un jour le domaine TLS et l'hôte WebSocket deviennent différents.
4. L'installateur serveur n'a pas été exécuté sur le VPS pendant cet audit. Aucun test réel du téléphone, du DNS, de Caddy ou du routage Internet n'a été effectué.

## Vérifications exécutées
- Première exécution : le test de recherche admin échouait de façon intermittente lorsque le préfixe d’une clé contenait `_`, car SQL `LIKE` interprétait `_` comme un joker.
- Correction appliquée dans `server/src/service.js` : les caractères `\`, `%` et `_` sont désormais échappés et recherchés littéralement dans tous les champs.
- Test renforcé dans `server/test/admin.test.js` avec une clé contenant `_`, une recherche partielle et une tentative d’injection SQL.
- Nouvelle exécution complète : **42 tests réussis, 0 échec**.
- Aucune compilation Android/APK ni aucun test réseau réel sur téléphone n'ont été effectués dans cet environnement. La suite de tests backend est entièrement verte, mais cela ne valide pas encore le passage Internet du tunnel.

## Changements de cette livraison
- Correction de la recherche administrateur : `_`, `%` et `\` sont traités comme des caractères ordinaires, pas comme des jokers SQL.
- Ajout de tests de non-régression sur les recherches avec caractères spéciaux et injection SQL.
- Correction de la documentation Android qui annonçait WireGuard alors que le code utilise Xray.
- Correction de la description du package serveur (Xray/VLESS, pas WireGuard).
- Aucun changement de protocole, de clé, de compte, de liaison appareil ou de configuration active du VPS.

## Suite nécessaire pour valider le vrai passage Internet
Exécuter `sudo darksurf-doctor` sur le VPS, puis vérifier depuis un téléphone autorisé le démarrage du tunnel et un test HTTPS/DNS via le VPN. Comparer les journaux Xray/Caddy et les compteurs de trafic du même UUID pendant ce test. Ne pas publier une nouvelle configuration transport avant d'avoir confirmé les versions Xray réellement installées côté VPS et Android.
