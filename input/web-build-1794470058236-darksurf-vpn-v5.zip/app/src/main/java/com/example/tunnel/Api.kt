package com.example.tunnel

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.SSLException

/** Erreurs métier, alignées sur docs/API.md. */
enum class ApiError { Rejected, Unauthorized, Forbidden, RateLimited, ServerBusy, Unreachable, Intercepted }

class ApiException(val kind: ApiError, val code: String? = null) : IOException("$kind ${code ?: ""}")

/** Profil Xray renvoyé par le serveur (VLESS sur WebSocket + TLS, port 443). Aucun secret propre à l'appareil : l'UUID est attribué par le serveur. */
data class Profile(
    val address: String,        // hôte du serveur
    val port: Int,              // 443
    val uuid: String,
    val path: String,           // chemin WebSocket secret
    val sni: String,
    val dns: String,            // ex. "1.1.1.1"
) {
    fun toJson() = JSONObject()
        .put("address", address).put("port", port).put("uuid", uuid)
        .put("path", path).put("sni", sni).put("dns", dns)

    companion object {
        fun fromJson(j: JSONObject): Profile {
            require(j.optString("protocol", "vless") == "vless" && j.optString("network", "ws") == "ws") { "unsupported_profile" }
            val addr = j.getString("address")
            return Profile(addr, j.optInt("port", 443), j.getString("uuid"), j.getString("path"), j.optString("sni", addr), j.optString("dns", "1.1.1.1"))
        }
    }
}

/** Forfait. quotaBytes == null -> illimité. */
data class Plan(
    val name: String, val quotaBytes: Long?, val usedBytes: Long, val expiresAt: Long,
    /** Plage horaire d'utilisation en minutes depuis minuit (heure du Cameroun), -1 = 24 h/24. */
    val windowStart: Int = -1, val windowEnd: Int = -1,
) {
    fun toJson() = JSONObject().put("name", name).put("used_bytes", usedBytes).put("expires_at", expiresAt)
        .also { if (quotaBytes != null) it.put("quota_bytes", quotaBytes) }
        .also { if (windowStart >= 0) it.put("window", JSONObject().put("start", windowStart).put("end", windowEnd)) }

    /** « 00h–06h » ou null. */
    fun windowText(): String? = if (windowStart < 0) null else "%02dh–%02dh".format(windowStart / 60 % 24, windowEnd / 60 % 24)

    companion object {
        fun fromJson(j: JSONObject) = Plan(
            j.optString("name", "Plan"),
            if (j.isNull("quota_bytes") || !j.has("quota_bytes")) null else j.getLong("quota_bytes"),
            j.optLong("used_bytes"), j.optLong("expires_at"),
            j.optJSONObject("window")?.getInt("start") ?: -1, j.optJSONObject("window")?.getInt("end") ?: -1,
        )
    }
}

data class SessionResponse(val token: String, val expiresAt: Long, val profile: Profile, val plan: Plan?)

data class Notice(val id: Int, val title: String, val body: String)

/** État du forfait renvoyé par /status : active | expired | quota_exceeded | revoked | disabled | outside_window. */
data class StatusResponse(val state: String, val now: Long, val plan: Plan, val notices: List<Notice>)

/** Version plus récente annoncée par le serveur. */
data class UpdateInfo(
    val versionCode: Int, val versionName: String, val url: String, val sha256: String,
    val size: Long, val notes: String, val required: Boolean,
)

class Api(private val base: String = BuildConfig.API_BASE) {

    fun enroll(code: String, label: String): String {
        val signingKey = DeviceIdentity.publicKeyB64()
        val signature = DeviceIdentity.sign("Tunnel/activate/v2\n$code\n$signingKey")
        val r = post(
            "enroll",
            JSONObject().put("code", code).put("signing_key", signingKey).put("label", label).put("signature", signature)
        )
        return r.getString("device_id")
    }

    fun session(deviceId: String, network: String): SessionResponse {
        val ch = post("challenge", JSONObject().put("device_id", deviceId))
        val challenge = ch.getString("challenge")
        val signature = DeviceIdentity.sign(ch.getString("message"))
        val r = post(
            "session",
            JSONObject().put("device_id", deviceId).put("challenge", challenge)
                .put("signature", signature).put("network", network)
        )
        return SessionResponse(
            token = r.getString("token"),
            expiresAt = r.getLong("expires_at"),
            profile = Profile.fromJson(r.getJSONObject("profile")),
            plan = r.optJSONObject("plan")?.let(Plan::fromJson),
        )
    }

    /** État du forfait + annonces, sans toucher au tunnel (même défi signé que la session). */
    fun status(deviceId: String, sinceNotice: Int): StatusResponse {
        val ch = post("challenge", JSONObject().put("device_id", deviceId))
        val signature = DeviceIdentity.sign(ch.getString("message"))
        val r = post(
            "status",
            JSONObject().put("device_id", deviceId).put("challenge", ch.getString("challenge"))
                .put("signature", signature).put("since_notice", sinceNotice)
        )
        val ns = r.optJSONArray("notices")
        val notices = List(ns?.length() ?: 0) { i -> ns!!.getJSONObject(i).let { Notice(it.getInt("id"), it.getString("title"), it.getString("body")) } }
        return StatusResponse(r.getString("state"), r.getLong("now"), Plan.fromJson(r.getJSONObject("plan")), notices.sortedBy { it.id })
    }

    /** null = à jour. */
    fun checkUpdate(currentVersionCode: Int): UpdateInfo? {
        val r = post("app/android", JSONObject().put("version_code", currentVersionCode))
        if (!r.optBoolean("update")) return null
        return UpdateInfo(
            r.getInt("version_code"), r.getString("version_name"), r.getString("url"), r.getString("sha256").lowercase(),
            r.optLong("size"), r.optString("notes"), r.optBoolean("required"),
        )
    }

    /** Réseaux mobiles instables : si la connexion ou la poignée de main TLS expire (rien n'a encore été envoyé), on réessaie jusqu'à 3 fois. */
    private fun post(path: String, body: JSONObject): JSONObject {
        var last: ApiException? = null
        for (attempt in 1..3) {
            try { return postOnce(path, body) } catch (e: ApiException) {
                if (e.kind != ApiError.Unreachable && e.kind != ApiError.Intercepted) throw e
                last = e
                if (attempt < 3) Thread.sleep(1200L * attempt)
            }
        }
        throw last!!
    }

    private fun postOnce(path: String, body: JSONObject): JSONObject {
        val conn = URL(base + path).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 25_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val status = conn.responseCode
            val text = (if (status < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status in 200..299) return JSONObject(text)
            val code = runCatching { JSONObject(text).optString("error") }.getOrNull()?.ifEmpty { null }
            throw ApiException(
                when (status) {
                    401 -> ApiError.Unauthorized
                    403 -> ApiError.Forbidden
                    429 -> ApiError.RateLimited
                    in 500..599 -> ApiError.ServerBusy
                    else -> ApiError.Rejected
                }, code
            )
        } catch (e: ApiException) {
            throw e
        } catch (e: SSLException) {
            throw ApiException(ApiError.Intercepted, e.javaClass.simpleName + ": " + (e.message ?: "").take(80))   // certificat invalide / interception TLS
        } catch (e: IOException) {
            throw ApiException(ApiError.Unreachable, e.javaClass.simpleName + ": " + (e.message ?: "").take(80))
        } catch (e: org.json.JSONException) {
            throw ApiException(ApiError.ServerBusy, "bad_json")
        } finally {
            conn.disconnect()
        }
    }
}
