package com.example.seller

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout

/** Une page de l'application : icône + libellé (FR/EN) + chemin du portail. */
data class Page(val icon: String, val fr: String, val en: String, val path: String, val match: List<String> = listOf(path))

/** Icônes dessinées à la main (aucune ressource) : trait fin, coins ronds, couleur du thème. */
class IconView(c: Context, private val kind: String) : View(c) {
    var tint = Ds.MUTED
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat(); val x0 = (width - s) / 2f; val y0 = (height - s) / 2f
        p.color = tint; p.strokeWidth = s * 0.085f; p.style = Paint.Style.STROKE
        fun X(v: Float) = x0 + s * v
        fun Y(v: Float) = y0 + s * v
        fun line(a: Float, b: Float, c: Float, d: Float) = cv.drawLine(X(a), Y(b), X(c), Y(d), p)
        fun rr(l: Float, t: Float, r: Float, b: Float, rad: Float) = cv.drawRoundRect(RectF(X(l), Y(t), X(r), Y(b)), s * rad, s * rad, p)
        when (kind) {
            "sell" -> {                                   // étiquette de prix
                val path = Path().apply { moveTo(X(.12f), Y(.45f)); lineTo(X(.12f), Y(.14f)); lineTo(X(.43f), Y(.14f)); lineTo(X(.88f), Y(.59f)); lineTo(X(.59f), Y(.88f)); close() }
                cv.drawPath(path, p); cv.drawCircle(X(.3f), Y(.3f), s * .05f, p)
            }
            "keys" -> {                                   // clé
                cv.drawCircle(X(.28f), Y(.5f), s * .17f, p); line(.45f, .5f, .9f, .5f); line(.74f, .5f, .74f, .66f); line(.62f, .5f, .62f, .62f)
            }
            "devices" -> { rr(.3f, .1f, .7f, .9f, .1f); line(.45f, .78f, .55f, .78f) }
            "credits" -> { cv.drawCircle(X(.5f), Y(.5f), s * .38f, p); line(.5f, .28f, .5f, .72f); line(.38f, .4f, .62f, .4f); line(.38f, .6f, .62f, .6f) }
            "dash" -> { rr(.14f, .14f, .44f, .44f, .06f); rr(.56f, .14f, .86f, .44f, .06f); rr(.14f, .56f, .44f, .86f, .06f); rr(.56f, .56f, .86f, .86f, .06f) }
            "users" -> { cv.drawCircle(X(.4f), Y(.33f), s * .15f, p); val a = Path().apply { moveTo(X(.12f), Y(.86f)); quadTo(X(.4f), Y(.38f), X(.68f), Y(.86f)) }; cv.drawPath(a, p); line(.72f, .5f, .88f, .5f) }
            "plans" -> { line(.5f, .14f, .88f, .34f); line(.88f, .34f, .5f, .54f); line(.5f, .54f, .12f, .34f); line(.12f, .34f, .5f, .14f); line(.12f, .54f, .5f, .74f); line(.5f, .74f, .88f, .54f); line(.12f, .72f, .5f, .92f); line(.5f, .92f, .88f, .72f) }
            "shield" -> { val a = Path().apply { moveTo(X(.5f), Y(.1f)); lineTo(X(.84f), Y(.24f)); lineTo(X(.84f), Y(.5f)); quadTo(X(.84f), Y(.78f), X(.5f), Y(.92f)); quadTo(X(.16f), Y(.78f), X(.16f), Y(.5f)); lineTo(X(.16f), Y(.24f)); close() }; cv.drawPath(a, p) }
            "more" -> { p.style = Paint.Style.FILL; for (v in listOf(.2f, .5f, .8f)) cv.drawCircle(X(v), Y(.5f), s * .07f, p) }
            "bell" -> { val a = Path().apply { moveTo(X(.2f), Y(.72f)); quadTo(X(.3f), Y(.64f), X(.3f), Y(.44f)); quadTo(X(.3f), Y(.18f), X(.5f), Y(.18f)); quadTo(X(.7f), Y(.18f), X(.7f), Y(.44f)); quadTo(X(.7f), Y(.64f), X(.8f), Y(.72f)); close() }; cv.drawPath(a, p); line(.42f, .86f, .58f, .86f) }
            "log" -> { rr(.2f, .1f, .8f, .9f, .08f); line(.34f, .34f, .66f, .34f); line(.34f, .52f, .66f, .52f); line(.34f, .7f, .55f, .7f) }
            "key2" -> { rr(.14f, .42f, .86f, .88f, .1f); val a = Path().apply { moveTo(X(.3f), Y(.42f)); lineTo(X(.3f), Y(.3f)); quadTo(X(.3f), Y(.12f), X(.5f), Y(.12f)); quadTo(X(.7f), Y(.12f), X(.7f), Y(.3f)); lineTo(X(.7f), Y(.42f)) }; cv.drawPath(a, p) }
            else -> cv.drawCircle(X(.5f), Y(.5f), s * .3f, p)
        }
    }
}

/** Barre de navigation flottante : une pastille par page, l'icône de la page active est mise en couleur. */
class FloatingNav(c: Context, private val pages: List<Page>, private val lang: () -> String, private val onPick: (Int) -> Unit) : LinearLayout(c) {
    private val icons = ArrayList<IconView>(); private val labels = ArrayList<android.widget.TextView>(); private val cells = ArrayList<LinearLayout>()
    var selected = 0
        set(v) { field = v; paint() }

    init {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(8.dp, 6.dp, 8.dp, 6.dp)
        elevation = 12f.dp
        pages.forEachIndexed { i, pg ->
            val cell = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, 6.dp, 0, 6.dp)
                val ic = IconView(c, pg.icon); icons.add(ic); addView(ic, lin(24.dp, 24.dp))
                val lb = c.tv(if (lang() == "en") pg.en else pg.fr, 10f, Ds.MUTED, Ds.DISPLAY, 0.04f); lb.maxLines = 1; labels.add(lb)
                addView(lb, lin(WRAP, WRAP, 2))
                setOnClickListener { onPick(i) }
            }
            cells.add(cell); addView(cell, LayoutParams(0, WRAP, 1f))
        }
        paint()
    }

    fun paint() {
        background = rect(Ds.SURFACE, 28f, Ds.LINE, 1)
        for (i in pages.indices) {
            val on = i == selected
            icons[i].tint = if (on) Ds.GREEN else Ds.MUTED
            labels[i].setTextColor(if (on) Ds.GREEN else Ds.MUTED)
            cells[i].background = if (on) rect(Ds.SURFACE2, 20f) else null
        }
    }
}
