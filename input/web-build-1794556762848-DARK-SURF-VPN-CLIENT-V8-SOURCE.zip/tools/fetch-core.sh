#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p app/libs
URL="https://github.com/2dust/AndroidLibXrayLite/releases/download/v26.10.31/libv2ray.aar"
TMP="app/libs/libv2ray.aar.tmp"
trap 'rm -f "$TMP"' EXIT
curl -fL --retry 4 --retry-all-errors --connect-timeout 30 --max-time 240 -A "DARK-SURF-Android-Build" -o "$TMP" "$URL"
test "$(stat -c%s "$TMP")" -gt 10000000
unzip -tq "$TMP" >/dev/null
unzip -Z1 "$TMP" | grep -qx 'classes.jar'
mv "$TMP" app/libs/libv2ray.aar
trap - EXIT
ls -lh app/libs/libv2ray.aar
