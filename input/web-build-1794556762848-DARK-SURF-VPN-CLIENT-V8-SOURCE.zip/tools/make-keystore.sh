#!/usr/bin/env bash
# Crée TA clé de signature (une seule fois !) et le fichier keystore.properties lu par Gradle.
# ⚠ Sauvegarde dark-surf-release.jks ET keystore.properties dans un endroit sûr (hors dépôt, plusieurs copies) :
#   si tu perds cette clé, aucun client ne pourra plus se mettre à jour.
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f dark-surf-release.jks ] && { echo "dark-surf-release.jks existe déjà : je n'écrase rien."; exit 1; }
command -v keytool >/dev/null || { echo "keytool introuvable (installe un JDK 17)."; exit 1; }

PASS=$(head -c 24 /dev/urandom | base64 | tr -d '/+=' | cut -c1-24)
keytool -genkeypair -v -keystore dark-surf-release.jks -alias darksurf -keyalg RSA -keysize 4096 -validity 36500 \
  -storepass "$PASS" -keypass "$PASS" -dname "CN=DARK_SURF, O=DARK_SURF"
cat > keystore.properties <<PROPS
storeFile=dark-surf-release.jks
storePassword=$PASS
keyAlias=darksurf
keyPassword=$PASS
PROPS
chmod 600 keystore.properties dark-surf-release.jks
echo
echo "Clé créée. Build signé :  ./gradlew assembleRelease"
echo "APK : app/build/outputs/apk/release/app-release.apk"
