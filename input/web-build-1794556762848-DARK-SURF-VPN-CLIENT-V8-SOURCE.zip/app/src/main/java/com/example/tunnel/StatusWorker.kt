package com.example.tunnel

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Tâche de fond (toutes les 30 min, réseau requis) : état du forfait, annonces, nouvelle version. */
class StatusWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val tm = TunnelManager.get(applicationContext)
        try {
            if (tm.isEnrolled()) tm.refreshStatus()
            Api().checkUpdate(BuildConfig.VERSION_CODE)?.let { PlanEvents.updateAvailable(applicationContext, it) }
        } catch (e: ApiException) {
            if (e.kind == ApiError.Unreachable || e.kind == ApiError.ServerBusy || e.kind == ApiError.RateLimited) return Result.retry()
        } catch (e: Exception) { return Result.retry() }
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<StatusWorker>(30, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 5, TimeUnit.MINUTES).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("darksurf-status", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
