package com.example.tunnel

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Mise à jour intégrée : télécharge l'APK depuis TON serveur (HTTPS, même hôte que l'API),
 * vérifie son empreinte SHA-256 puis sa signature, et lance l'installation Android.
 * Android refuse toute mise à jour qui n'est pas signée avec la même clé que l'appli installée.
 */
object Updater {
    private const val MAX_BYTES = 300L * 1024 * 1024

    class UpdateException(val reason: String) : IOException(reason)

    /** Téléchargement bloquant (appeler hors du thread principal). onProgress reçoit 0..100. */
    fun download(context: Context, info: UpdateInfo, onProgress: (Int) -> Unit): File {
        val url = URL(info.url)
        val apiHost = URL(BuildConfig.API_BASE).host
        if (url.protocol != "https" || !url.host.equals(apiHost, ignoreCase = true)) throw UpdateException("untrusted_url")

        val dir = File(context.cacheDir, "updates").apply { deleteRecursively(); mkdirs() }
        val out = File(dir, "darksurf-${info.versionCode}.apk")
        val md = MessageDigest.getInstance("SHA-256")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000; conn.readTimeout = 30_000
            conn.instanceFollowRedirects = false                       // pas de redirection vers un autre hôte
            if (conn.responseCode != 200) throw UpdateException("http_${conn.responseCode}")
            val total = conn.contentLengthLong.takeIf { it > 0 } ?: info.size
            if (total > MAX_BYTES || (info.size > 0 && total != info.size)) throw UpdateException("bad_size")
            var done = 0L; var last = -1
            conn.inputStream.use { input ->
                out.outputStream().use { os ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buf); if (n < 0) break
                        done += n
                        if (done > MAX_BYTES) throw UpdateException("bad_size")
                        md.update(buf, 0, n); os.write(buf, 0, n)
                        if (total > 0) (done * 100 / total).toInt().let { if (it != last) { last = it; onProgress(it) } }
                    }
                }
            }
            if (info.size > 0 && done != info.size) throw UpdateException("bad_size")
            val sha = md.digest().joinToString("") { "%02x".format(it) }
            if (sha != info.sha256) throw UpdateException("bad_checksum")
            if (!sameSigner(context, out)) throw UpdateException("bad_signature")
            return out
        } catch (e: Exception) {
            out.delete()
            if (e is UpdateException) throw e
            throw UpdateException("network")
        } finally {
            conn.disconnect()
        }
    }

    /** Même nom de paquet et même certificat que l'appli installée (sinon Android refuserait de toute façon). */
    private fun sameSigner(context: Context, apk: File): Boolean {
        if (Build.VERSION.SDK_INT < 28) return true                    // l'installateur fait foi sur Android 8/8.1
        return try {
            val pm = context.packageManager
            val flags = PackageManager.GET_SIGNING_CERTIFICATES
            val archive = pm.getPackageArchiveInfo(apk.path, flags) ?: return false
            if (archive.packageName != context.packageName) return false
            fun certs(i: android.content.pm.PackageInfo) = i.signingInfo?.apkContentsSigners
                ?.map { MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).toList() }?.toSet()
            val mine = certs(pm.getPackageInfo(context.packageName, flags))
            val theirs = certs(archive)
            mine != null && mine == theirs
        } catch (e: Exception) { false }
    }

    fun canInstall(context: Context) = context.packageManager.canRequestPackageInstalls()

    /** Ouvre l'écran Android « autoriser l'installation d'applis inconnues » pour DARK_SURF. */
    fun requestInstallPermission(activity: Activity) {
        activity.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
        )
    }

    /** Lance l'installateur Android (l'utilisateur confirme). */
    fun install(activity: Activity, apk: File) {
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.updates", apk)
        activity.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
