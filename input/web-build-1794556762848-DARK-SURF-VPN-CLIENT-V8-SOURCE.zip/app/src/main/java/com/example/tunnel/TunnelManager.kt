package com.example.tunnel

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.content.Intent
import android.net.TrafficStats
import android.os.Process
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(val start: Long, val end: Long, val rx: Long, val tx: Long)

/**
 * Orchestre : enrôlement -> session signée -> tunnel Xray/TUN en VLESS ou via un transport SSH.
 * Même logique que Geny (code d'activation, challenge signé, profil à durée limitée),
 * le tunnel est assuré par le noyau Xray.
 */
class TunnelManager private constructor(context: Context) {
    private val app = context.applicationContext
    private val store = SecureStore(app)
    private val api = Api()
    private val lock = Any()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var monitor: Job? = null

    @Volatile var listener: ((Boolean) -> Unit)? = null
    /** Appelé quand l'état du forfait change (nouvelle lecture du serveur). */
    @Volatile var onPlanChanged: (() -> Unit)? = null
    /** Raison du dernier arrêt automatique : expired | quota_exceeded | revoked | disabled (null = arrêt normal). */
    @Volatile var lastStop: String? = null
        private set
    @Volatile private var sessionBase = 0L
    @Volatile var connectedAt: Long = 0L
        private set

    // ---- état persistant ----
    private class State(
        val deviceId: String,
        var profile: Profile? = null, var expiresAt: Long = 0, var token: String? = null,
        var plan: Plan? = null, val history: MutableList<HistoryEntry> = mutableListOf(),
        var lastNotice: Int = 0, val code: String = "",
    ) {
        fun toJson() = JSONObject().put("device_id", deviceId)
            .put("expires_at", expiresAt).put("token", token).put("last_notice", lastNotice).put("code", code)
            .put("history", JSONArray().also { a ->
                history.forEach { a.put(JSONObject().put("s", it.start).put("e", it.end).put("rx", it.rx).put("tx", it.tx)) }
            })
            .also { j ->
                profile?.let { j.put("profile", it.toJson()) }
                plan?.let { j.put("plan", it.toJson()) }
            }
    }

    private fun load(): State? = store.read()?.let {
        runCatching {
            val j = JSONObject(it)
            val h = j.optJSONArray("history") ?: JSONArray()
            State(
                j.getString("device_id"),
                j.optJSONObject("profile")?.let(Profile::fromJson),
                j.optLong("expires_at"), j.optString("token").ifEmpty { null },
                j.optJSONObject("plan")?.let(Plan::fromJson),
                MutableList(h.length()) { i ->
                    h.getJSONObject(i).let { o -> HistoryEntry(o.getLong("s"), o.getLong("e"), o.getLong("rx"), o.getLong("tx")) }
                },
                j.optInt("last_notice"), j.optString("code"),
            )
        }.getOrNull()
    }

    private fun save(st: State) = store.write(st.toJson().toString())

    /** Lecture-modification-écriture atomique (le moniteur, la tâche de fond et l'écran écrivent le même fichier). */
    private fun <T> edit(block: (State) -> T): T? = synchronized(lock) { load()?.let { st -> block(st).also { save(st) } } }

    // ---- lecture (rapide, utilisable depuis le thread principal) ----
    fun isEnrolled() = load() != null
    fun isConnected() = XrayVpnService.running
    fun deviceId(): String? = load()?.deviceId
    /** Clé d'activation, affichée masquée sur l'accueil (« TUN-gLw3••••hw-X »). */
    fun code(): String? = load()?.code?.takeIf { it.isNotEmpty() }
    fun plan(): Plan? = load()?.plan
    fun isPlanOver(): Boolean = load()?.plan?.let { it.expiresAt in 1..(System.currentTimeMillis() / 1000) } == true
    fun history(): List<HistoryEntry> = load()?.history.orEmpty()

    /** Octets échangés avec le serveur (chiffrés) par ce processus, depuis le démarrage du tunnel : débit réel du tunnel. */
    private fun uidRx() = TrafficStats.getUidRxBytes(Process.myUid()).coerceAtLeast(0)
    private fun uidTx() = TrafficStats.getUidTxBytes(Process.myUid()).coerceAtLeast(0)
    @Volatile private var baseRx = 0L
    @Volatile private var baseTx = 0L

    /** (octets reçus, octets envoyés) de la session en cours. */
    suspend fun stats(): Pair<Long, Long> = withContext(Dispatchers.IO) {
        if (!isConnected()) 0L to 0L else (uidRx() - baseRx).coerceAtLeast(0) to (uidTx() - baseTx).coerceAtLeast(0)
    }

    // ---- opérations ----
    suspend fun activate(rawCode: String) = withContext(Dispatchers.IO) {
        val code = ActivationCode.normalize(rawCode) ?: throw ApiException(ApiError.Rejected, "bad_code_format")
        val deviceId = api.enroll(code, "${Build.MANUFACTURER} ${Build.MODEL}")
        save(State(deviceId, code = code))
    }

    suspend fun connect() = withContext(Dispatchers.IO) {
        val st = load() ?: throw IllegalStateException("not_enrolled")
        val now = System.currentTimeMillis() / 1000
        lastStop = null
        val plan = st.plan
        // Le VPS est l'unique autorité de configuration : récupérer le profil à chaque connexion
        // afin qu'un changement de protocole/port/identifiants dans le panel soit appliqué immédiatement.
        val s = api.session(st.deviceId, networkType())
        edit { it.profile = s.profile; it.expiresAt = s.expiresAt; it.token = s.token; it.plan = s.plan }
        val fresh = load()!!
        XrayVpnService.error = null
        baseRx = uidRx(); baseTx = uidTx()
        app.startForegroundService(Intent(app, XrayVpnService::class.java).putExtra(XrayVpnService.EXTRA_PROFILE, fresh.profile!!.toJson().toString()))
        var waited = 0
        while (!XrayVpnService.running && XrayVpnService.error == null && waited < 12_000) { delay(200); waited += 200 }
        if (!XrayVpnService.running) throw IllegalStateException(XrayVpnService.error ?: "timeout")
        connectedAt = System.currentTimeMillis()
        sessionBase = 0L
        startMonitor()
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        monitor?.cancel(); monitor = null
        val (rx, tx) = stats()
        stopService()
        val start = connectedAt
        connectedAt = 0L; sessionBase = 0L
        if (start > 0) edit { st ->
            st.history.add(0, HistoryEntry(start, System.currentTimeMillis(), rx, tx))
            while (st.history.size > 50) st.history.removeAt(st.history.size - 1)
        }
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) { edit { it.history.clear() }; Unit }

    /** Consommation affichée : valeur du serveur + trafic de la session depuis cette valeur. */
    fun liveUsed(plan: Plan, sessionTotal: Long) = plan.usedBytes + (sessionTotal - sessionBase).coerceAtLeast(0L)

    /**
     * Lit l'état du forfait chez le serveur (n'ouvre jamais l'accès), mémorise le forfait,
     * déclenche les notifications (forfait, données, annonces).
     */
    suspend fun refreshStatus(): StatusResponse = withContext(Dispatchers.IO) {
        val st = load() ?: throw IllegalStateException("not_enrolled")
        val r = api.status(st.deviceId, st.lastNotice)
        edit { it.plan = r.plan; it.lastNotice = maxOf(it.lastNotice, r.notices.maxOfOrNull { n -> n.id } ?: 0) }
        sessionBase = (uidRx() - baseRx).coerceAtLeast(0) + (uidTx() - baseTx).coerceAtLeast(0)
        PlanEvents.process(app, r)
        onPlanChanged?.invoke()
        r
    }

    /**
     * Tant que le tunnel est monté : date d'expiration vérifiée toutes les 5 s (arrêt à la seconde près),
     * état serveur (données, clé révoquée, recharge) toutes les 30 s. Le serveur coupe aussi l'accès de son côté :
     * ceci sert à arrêter proprement le VPN et à prévenir l'utilisateur.
     */
    private fun startMonitor() {
        monitor?.cancel()
        monitor = scope.launch {
            var lastPoll = System.currentTimeMillis()
            while (isActive) {
                delay(5_000)
                if (!XrayVpnService.running) break
                val plan = load()?.plan
                var stop: String? = null
                if (plan != null && plan.expiresAt > 0 && System.currentTimeMillis() / 1000 >= plan.expiresAt) {
                    stop = "expired"; PlanEvents.ended(app, "expired", plan)
                } else if (System.currentTimeMillis() - lastPoll >= STATUS_EVERY_MS) {
                    lastPoll = System.currentTimeMillis()
                    try { refreshStatus().takeIf { it.state != "active" }?.let { stop = it.state } }
                    catch (e: ApiException) { /* réseau indisponible : on réessaie au prochain tour */ }
                    catch (e: Exception) { /* idem */ }
                }
                stop?.let { reason ->
                    lastStop = reason
                    runCatching { disconnect() }
                    listener?.invoke(false)
                    return@launch
                }
            }
        }
    }

    suspend fun reset() = withContext(Dispatchers.IO) {
        monitor?.cancel(); monitor = null
        stopService()
        connectedAt = 0L
        store.clear(); DeviceIdentity.reset()
    }

    // ---- helpers ----
    private fun stopService() {
        runCatching { app.startService(Intent(app, XrayVpnService::class.java).setAction(XrayVpnService.ACTION_STOP)) }
        XrayVpnService.running = false
    }

    private fun networkType(): String {
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        return if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) "wifi" else "mobile"
    }

    companion object {
        private const val RENEW_MARGIN_S = 120L
        private const val STATUS_EVERY_MS = 30_000L
        @Volatile private var instance: TunnelManager? = null
        fun get(ctx: Context): TunnelManager = instance ?: synchronized(this) {
            instance ?: TunnelManager(ctx.applicationContext).also { instance = it }
        }
    }
}
