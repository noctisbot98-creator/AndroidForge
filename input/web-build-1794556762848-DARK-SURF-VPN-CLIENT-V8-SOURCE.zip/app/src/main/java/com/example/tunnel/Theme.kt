package com.example.tunnel

import android.content.res.Resources
import android.graphics.Color
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Identité visuelle DARK SURF PRO : pétrole profond, turquoise et cuivre. */
object Ds {
    val BG = Color.parseColor("#071412")
    val BG2 = Color.parseColor("#102522")
    val SURFACE = Color.parseColor("#102522")        // verre : blanc translucide
    val SURFACE2 = Color.parseColor("#15312C")
    val LINE = Color.parseColor("#28534A")           // liseré lumineux
    val ACCENT = Color.parseColor("#00D6B8")           // bleu électrique
    val ACCENT2 = Color.parseColor("#00A88F")          // violet
    val WARM = Color.parseColor("#E6A45B")             // ambre
    val OK = Color.parseColor("#00D6B8")
    val ON = Color.parseColor("#00D6B8")               // connecté : vert menthe
    val TEXT = Color.parseColor("#F1F5F2")
    val MUTED = Color.parseColor("#91AAA1")
    val DANGER = Color.parseColor("#FF6B6B")

    // Mélange de styles : titres condensés, chiffres monospace, accroches serif italique, corps fin.
    val DISPLAY: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    val BLACK: Typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
    val BODY: Typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    val MONO: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    val SERIF: Typeface = Typeface.create("serif", Typeface.ITALIC)
}

val Int.dp: Int get() = (this * Resources.getSystem().displayMetrics.density).toInt()
val Float.dp: Float get() = this * Resources.getSystem().displayMetrics.density

/** Bilingue FR/EN, comme Geny. */
object Lang {
    @Volatile var fr: Boolean = Locale.getDefault().language == "fr"
    fun t(f: String, e: String) = if (fr) f else e
    fun locale(): Locale = if (fr) Locale.FRANCE else Locale.US
}

fun fmtBytes(b: Long): String {
    val unit = Lang.t("o", "B")
    val v = b.toDouble()
    return when {
        v >= 1e9 -> "%.2f G%s".format(v / 1e9, unit)
        v >= 1e6 -> "%.1f M%s".format(v / 1e6, unit)
        v >= 1e3 -> "%.0f k%s".format(v / 1e3, unit)
        else -> "$b $unit"
    }
}

fun fmtDuration(ms: Long): String {
    val s = ms / 1000
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

fun fmtDate(epochMs: Long, pattern: String = "d MMM yyyy"): String =
    SimpleDateFormat(pattern, Lang.locale()).format(Date(epochMs))
