package com.example.tunnel

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.File
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.text.Normalizer
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Code d'activation : TUN-<32 caractères [A-Za-z0-9_-]>. */
object ActivationCode {
    private val RE = Regex("^TUN-[A-Za-z0-9_-]{32}$")

    fun normalize(raw: String): String? {
        val s = Normalizer.normalize(raw.trim(), Normalizer.Form.NFKC)
        return if (RE.matches(s)) s else null
    }
}

/**
 * Identité de l'appareil : clé ECDSA P-256 dans l'AndroidKeyStore.
 * La clé privée ne quitte jamais le keystore ; le serveur ne reçoit que la clé publique.
 */
object DeviceIdentity {
    private const val ALIAS = "tunnel.identity.v1"

    private fun keystore(): KeyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    /** Clé publique au format X.509 SubjectPublicKeyInfo (DER), en base64. */
    fun publicKeyB64(): String {
        val ks = keystore()
        if (!ks.containsAlias(ALIAS)) {
            val gen = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
            gen.initialize(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN)
                    .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .build()
            )
            gen.generateKeyPair()
        }
        return Base64.encodeToString(ks.getCertificate(ALIAS).publicKey.encoded, Base64.NO_WRAP)
    }

    /** SHA256withECDSA, signature DER, base64. */
    fun sign(message: String): String {
        publicKeyB64() // garantit que la clé existe
        val key = keystore().getKey(ALIAS, null) as PrivateKey
        val sig = Signature.getInstance("SHA256withECDSA")
        sig.initSign(key)
        sig.update(message.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(sig.sign(), Base64.NO_WRAP)
    }

    fun reset() {
        runCatching { keystore().deleteEntry(ALIAS) }
    }
}

/** Stockage local chiffré en AES-256-GCM (clé dans le keystore), hors sauvegardes. */
class SecureStore(context: Context) {
    private val file = File(context.noBackupFilesDir, "state.bin")
    private val aad = "com.example.tunnel/state/v1".toByteArray()

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    @Synchronized
    fun write(plain: String) {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        c.updateAAD(aad)
        val iv = c.iv
        val out = byteArrayOf(iv.size.toByte()) + iv + c.doFinal(plain.toByteArray(Charsets.UTF_8))
        val tmp = File(file.parentFile, "state.bin.part")
        tmp.outputStream().use { it.write(out); it.fd.sync() }
        if (!tmp.renameTo(file)) { tmp.delete(); error("écriture atomique impossible") }
    }

    @Synchronized
    fun read(): String? {
        if (!file.exists()) return null
        return runCatching {
            val b = file.readBytes()
            val n = b[0].toInt()
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b.copyOfRange(1, 1 + n)))
            c.updateAAD(aad)
            String(c.doFinal(b, 1 + n, b.size - 1 - n), Charsets.UTF_8)
        }.getOrNull() // clé invalidée / fichier corrompu -> on repart de zéro
    }

    @Synchronized
    fun clear() { file.delete() }

    private companion object { const val ALIAS = "tunnel.storage.v1" }
}
