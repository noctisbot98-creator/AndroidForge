package com.example.tunnel

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** Notifications locales (aucun service tiers) : forfait, données, expiration, annonces, mise à jour. */
object Notifier {
    const val CH_PLAN = "plan"
    const val CH_INFO = "info"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_PLAN, "Forfait / Plan", NotificationManager.IMPORTANCE_HIGH).apply { setShowBadge(true) })
        nm.createNotificationChannel(NotificationChannel(CH_INFO, "Annonces / News", NotificationManager.IMPORTANCE_DEFAULT).apply { setShowBadge(true) })
    }

    fun canNotify(ctx: Context) = Build.VERSION.SDK_INT < 33 ||
        ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    /** Mémorise les dernières notifications : la cloche de l'accueil les relit. */
    fun log(ctx: Context, title: String, text: String) {
        val p = ctx.getSharedPreferences("events", Context.MODE_PRIVATE)
        val a = org.json.JSONArray(p.getString("log", "[]"))
        val n = org.json.JSONArray().put(org.json.JSONObject().put("t", title).put("x", text).put("at", System.currentTimeMillis()))
        for (i in 0 until minOf(a.length(), 19)) n.put(a.getJSONObject(i))
        p.edit().putString("log", n.toString()).putInt("unread", p.getInt("unread", 0) + 1).apply()
    }

    /** Nombre de notifications non lues : pastille de la cloche et numéro sur l'icône de l'appli. */
    fun unread(ctx: Context) = ctx.getSharedPreferences("events", Context.MODE_PRIVATE).getInt("unread", 0)

    fun markRead(ctx: Context) {
        ctx.getSharedPreferences("events", Context.MODE_PRIVATE).edit().putInt("unread", 0).apply()
        runCatching { ctx.getSystemService(NotificationManager::class.java).cancelAll() }
    }

    fun recent(ctx: Context): List<Triple<String, String, Long>> {
        val a = runCatching { org.json.JSONArray(ctx.getSharedPreferences("events", Context.MODE_PRIVATE).getString("log", "[]")) }.getOrDefault(org.json.JSONArray())
        return List(a.length()) { i -> a.getJSONObject(i).let { Triple(it.optString("t"), it.optString("x"), it.optLong("at")) } }
    }

    fun show(ctx: Context, id: Int, title: String, text: String, channel: String = CH_INFO) {
        log(ctx, title, text)
        if (!canNotify(ctx)) return
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open).setAutoCancel(true)
            .setNumber(unread(ctx)).setBadgeIconType(Notification.BADGE_ICON_SMALL)
            .build()
        runCatching { ctx.getSystemService(NotificationManager::class.java).notify(id, n) }
    }
}

/**
 * Règles de notification du forfait. Chaque alerte n'est envoyée qu'une fois par forfait
 * (la clé de mémorisation contient la date d'expiration : une recharge réarme tout).
 */
object PlanEvents {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("events", Context.MODE_PRIVATE)

    private fun once(ctx: Context, key: String): Boolean {
        val p = prefs(ctx)
        val seen = p.getStringSet("seen", emptySet()).orEmpty()
        if (key in seen) return false
        val next = (seen + key).toList().takeLast(60).toSet()
        p.edit().putStringSet("seen", next).apply()
        return true
    }

    private fun sync(ctx: Context) {
        ctx.getSharedPreferences("ui", Context.MODE_PRIVATE).let { if (it.contains("fr")) Lang.fr = it.getBoolean("fr", Lang.fr) }
    }

    /** Le forfait est terminé (état != active). */
    fun ended(ctx: Context, state: String, plan: Plan) {
        sync(ctx)
        if (!once(ctx, "end:$state:${plan.expiresAt}:${plan.quotaBytes}")) return
        val t = Lang::t
        val (title, text) = when (state) {
            "expired" -> t("Forfait expiré", "Plan expired") to
                t("Le VPN est arrêté. Demandez à votre vendeur de recharger votre clé, puis reconnectez-vous.", "The VPN has stopped. Ask your seller to top up your key, then reconnect.")
            "quota_exceeded" -> t("Données épuisées", "Data used up") to
                t("Le VPN est arrêté. Demandez à votre vendeur de recharger votre clé, puis reconnectez-vous.", "The VPN has stopped. Ask your seller to top up your key, then reconnect.")
            "outside_window" -> t("Hors plage horaire", "Outside allowed hours") to
                t("Ce forfait est utilisable de ${plan.windowText() ?: "—"} seulement. Reconnectez-vous pendant cette plage.", "This plan only works ${plan.windowText() ?: "—"}. Reconnect during that window.")
            else -> t("Clé désactivée", "Key disabled") to t("Cette clé n'est plus valable. Contactez votre vendeur.", "This key is no longer valid. Contact your seller.")
        }
        Notifier.show(ctx, 10, title, text, Notifier.CH_PLAN)
    }

    /** À appeler après chaque lecture de /status. */
    fun process(ctx: Context, r: StatusResponse) {
        sync(ctx)
        val t = Lang::t
        if (r.state != "active") ended(ctx, r.state, r.plan)
        else {
            val left = r.plan.expiresAt - r.now
            val tag = "${r.plan.expiresAt}:${r.plan.quotaBytes}"
            if (left in 1..3 * 3600 && once(ctx, "exp3:$tag"))
                Notifier.show(ctx, 11, t("Forfait bientôt terminé", "Plan ending soon"), t("Il expire dans moins de 3 heures.", "It expires in less than 3 hours."), Notifier.CH_PLAN)
            else if (left in 1..86400 && once(ctx, "exp24:$tag"))
                Notifier.show(ctx, 11, t("Forfait bientôt terminé", "Plan ending soon"), t("Il expire dans moins de 24 heures.", "It expires in less than 24 hours."), Notifier.CH_PLAN)
            r.plan.quotaBytes?.let { q ->
                val ratio = r.plan.usedBytes.toDouble() / q
                if (ratio >= 0.95 && once(ctx, "d95:$tag"))
                    Notifier.show(ctx, 12, t("Presque plus de données", "Almost out of data"), t("Plus que ${fmtBytes((q - r.plan.usedBytes).coerceAtLeast(0))} (95 % utilisés).", "Only ${fmtBytes((q - r.plan.usedBytes).coerceAtLeast(0))} left (95% used)."), Notifier.CH_PLAN)
                else if (ratio >= 0.8 && once(ctx, "d80:$tag"))
                    Notifier.show(ctx, 12, t("80 % des données utilisés", "80% of data used"), t("Il reste ${fmtBytes((q - r.plan.usedBytes).coerceAtLeast(0))}.", "${fmtBytes((q - r.plan.usedBytes).coerceAtLeast(0))} left."), Notifier.CH_PLAN)
            }
        }
        r.notices.forEach { Notifier.show(ctx, 2000 + it.id, it.title, it.body, Notifier.CH_INFO) }
    }

    fun updateAvailable(ctx: Context, info: UpdateInfo) {
        sync(ctx)
        if (!once(ctx, "upd:${info.versionCode}")) return
        Notifier.show(ctx, 13, Lang.t("Mise à jour disponible", "Update available"),
            Lang.t("DARK_SURF ${info.versionName} est prêt. Ouvrez l'application pour l'installer.", "DARK_SURF ${info.versionName} is ready. Open the app to install it."), Notifier.CH_INFO)
    }
}
