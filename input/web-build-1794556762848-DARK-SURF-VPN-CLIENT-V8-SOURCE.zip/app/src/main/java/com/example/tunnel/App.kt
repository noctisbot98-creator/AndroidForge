package com.example.tunnel

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.ensureChannels(this)
        StatusWorker.schedule(this)
    }
}
