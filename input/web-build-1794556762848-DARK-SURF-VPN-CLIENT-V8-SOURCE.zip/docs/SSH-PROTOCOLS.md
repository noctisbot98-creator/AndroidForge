# DARK SURF — transports SSH

Le protocole est choisi **uniquement par le serveur** (page admin « Protocoles VPN »). L'appli n'a aucun réglage : le client colle sa clé et se connecte.

| Mode | Chemin réseau | Port côté VPS |
|---|---|---:|
| SSH-WS | SSH dans WebSocket sécurisé (WSS) via Caddy | 443 / `/ssh-ws` |
| SSH-TCP | SSH direct | 2222/tcp |
| SSH-TCP Payload | HTTP CONNECT personnalisé puis SSH | port Payload configurable vers port SSH configurable |

Le client Android utilise JSch pour ouvrir un SOCKS dynamique local ; le noyau Xray garde l'interface TUN et envoie les flux TCP dans ce SOCKS. Le compte SSH est propre à chaque appareil, créé à la première session autorisée, coupé (session tuée) dès que l'accès n'est plus valide.

**Sécurité côté serveur :** `sshd` séparé, sans shell ni terminal, uniquement le transfert de ports ; un pare-feu (`darksurf-ssh-firewall`) interdit à ces comptes le réseau interne du serveur (API Xray, portail, sshd), les réseaux privés et le port 25 ; chaque octet transféré est compté et déduit du forfait comme pour VLESS.

**Limite de SSH :** il ne transporte que du TCP. Les usages qui exigent de l'UDP (certains jeux, appels) restent sur VLESS.

Ouvrir les ports 2222/tcp (SSH-TCP) et 2223/tcp (SSH-TCP Payload) dans le pare-feu du VPS et du fournisseur ; 443 doit déjà être accessible.


Pour SSH-TCP Payload, le serveur admin transmet au client un modèle HTTP CONNECT personnalisé avec variables `{host}` et `{port}`. L’application 0.3.0 (versionCode 2) applique les en-têtes définis dans le profil global lors de la prochaine connexion. Le premier verbe doit être CONNECT.
