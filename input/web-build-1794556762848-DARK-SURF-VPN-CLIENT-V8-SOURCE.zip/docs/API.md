# Contrat d'API DARK SURF (v1)

Base : `https://<ton-domaine>/api/v1/` — POST JSON, HTTPS obligatoire.

| Endpoint | Corps | Réponse |
|---|---|---|
| `enroll` | `code, signing_key` (SPKI DER b64), `label`, `signature` | `{device_id}` |
| `challenge` | `device_id` | `{challenge, message}` |
| `session` | `device_id, challenge, signature, network` | `{token, expires_at, plan, profile}` |
| `status` | `device_id, challenge, signature, since_notice?` | `{state, now, plan, notices}` |

- `enroll` : signature ECDSA (SHA-256, DER) de `Tunnel/activate/v2\n<code>\n<signing_key>`. L'appareil est lié à sa clé ECDSA Android Keystore.
- `session` : challenge à usage unique valable 60 secondes, signé par l'identité de l'appareil.
- `profile` VLESS : `protocol=vless`, `address`, `port`, `uuid`, `network=ws`, `path`, `sni`, `dns`, et éventuellement `reality` ou `kcp`.
- `profile.ssh` (si `SSH_ENABLED=1`) : `host`, `tcp_port`, `ws_port`, `payload_port`, `username`, `password`, `ws_path`, `host_key`. Ces identifiants sont dérivés de l'identifiant de l'appareil et ne sont pas partagés entre appareils.
- Transports Android : `ssh-tcp` se connecte en SSH direct au port TCP ; `ssh-ws` encapsule le flux SSH dans WebSocket TLS sur le chemin configuré ; `ssh-payload` envoie une requête HTTP CONNECT au port payload, qui relaie vers SSH.
- Les modes SSH utilisent un tunnel TCP (pas de transport UDP arbitraire). VLESS reste disponible pour les usages UDP.
- Le serveur verrouille le compte SSH quand l'appareil est désactivé, le forfait expire, est révoqué ou atteint son quota. La clé d'hôte SSH est épinglée côté client.

Erreurs : 401 appareil/défi non reconnu · 403 forfait interdit (`invalid_code`, `device_limit`, `plan_expired`, `quota_exceeded`, `device_disabled`) · 429 limite de débit · 5xx serveur occupé.

## Mise à jour de l'application

`POST app/android` `{version_code}` → `{update:false}` ou `{update:true, version_code, version_name, url, sha256, size, notes, required}`. L'URL est HTTPS sur le même hôte que l'API ; l'application vérifie SHA-256, taille et signature avant installation. `required` rend la mise à jour obligatoire.


## Configuration centralisée des protocoles (panel VPS)

Le client Android ne permet plus de choisir ni de paramétrer le transport. Le panel admin définit le protocole actif et ses paramètres pour le compte/appareil. À chaque tentative de connexion, l'application demande une nouvelle session à l'API et applique exclusivement `profile.protocol` et `profile.ssh` renvoyés par le VPS. Valeurs prises en charge : `vless`, `ssh-ws`, `ssh-tcp`, `ssh-payload`. Pour changer de protocole, l'administrateur modifie le profil côté VPS ; aucune recompilation de l'APK n'est nécessaire.
