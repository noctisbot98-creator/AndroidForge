# DARK_SURF PRO et ADMIN — applications vendeur et administrateur (Android)

Coquille WebView autour de **ton** portail (vendeur ou administrateur, selon le compte), verrouillée par un code d'activation signé et lié au téléphone.

## Mise en route
1. `node tools/activation.js keygen tools/` → crée `seller-private.pem` (**secrète**, reste sur ton PC/serveur) et `seller-public.b64`.
2. Dans `app/build.gradle.kts`, renseigne :
   - `PORTAL_URL` : adresse HTTPS de ton portail (seul cet hôte est autorisé dans l'appli) ;
   - `ACTIVATION_PUBLIC_KEY` : contenu de `seller-public.b64` ;
   - `SUPPORT_WHATSAPP` : numéro qui reçoit les demandes d'accès (format international, sans « + »).
3. Ouvre le dossier dans Android Studio. Deux variantes : `sellerRelease` (DARK_SURF PRO, pour les vendeurs) et `adminRelease`
   (DARK_SURF ADMIN, pour toi seul) : `./gradlew assembleSellerRelease assembleAdminRelease`.
   Le portail montre à chacun son espace : le vendeur génère/recharge des clés avec ses crédits ; l'administrateur crée les vendeurs,
   recharge leurs crédits, voit clés actives, forfaits et consommations, gère la grille des forfaits et publie des annonces.

## Donner accès à un vendeur
1. Le vendeur ouvre l'appli : elle affiche son **identifiant** (AAAA-BBBB-CCCC-DDDD-EEEE) et propose de te l'envoyer par WhatsApp.
2. Toi : `node tools/activation.js issue --device AAAA-BBBB-CCCC-DDDD-EEEE --days 30 --label "Nom" --key tools/seller-private.pem`
3. Tu lui renvoies le code ; il le colle dans l'appli. Le code ne marche que sur ce téléphone et expire à la date prévue (`--days 0` = illimité).
4. Test : `node tools/test.js`

## Contrat avec ton portail
Pour la connexion automatique (page `/login` du serveur DARK_SURF, déjà conforme), la page de connexion doit contenir `<form id="form">`, `<input id="login">` et `<input id="password">`.
Le revendeur saisit son identifiant une seule fois ; il est stocké chiffré (AndroidKeyStore), jamais dans le code.
L'appli s'arrête après 2 tentatives refusées pour ne pas bloquer le compte.

## Sécurité
- HTTPS uniquement, un seul hôte autorisé, certificats invalides refusés, liens externes ouverts hors de l'appli.
- Aucun identifiant ni clé privée dans l'APK ; seule la clé publique y figure.
- Limite : l'heure du téléphone sert à l'expiration (un téléphone dont l'horloge est reculée prolonge un code).


## Configuration DARK_SURF en ligne
- Portail vendeur : `https://15-235-111-58.sslip.io/`
- Le portail utilise les vrais comptes et sessions du serveur ; aucune API vendeur fictive n'est ajoutée dans l'APK.
- Le contact administrateur ouvre le composeur téléphonique au `+237 621 86 21 34` (pas de notification WhatsApp inventée).
- Android Gradle Plugin 8.6.1 est utilisé pour compiler avec `compileSdk 35` sur Gradle 8.7.


## Refonte visuelle professionnelle — novembre 2026

- Identité DARK SURF unifiée : pétrole profond `#071412`, surfaces `#102522`, turquoise `#00D6B8`, cuivre `#E6A45B`, texte `#F1F5F2`.
- Contraste et hiérarchie visuelle harmonisés entre les deux applications.
- Architecture réseau et logique métier conservées : VPN Xray/VLESS WebSocket + TLS pour l’application VPN ; portail vendeur HTTPS pour DARK SURF PRO.
- Cette livraison est un projet Android source pour AndroidForge, pas un APK précompilé.
