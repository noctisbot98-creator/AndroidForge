package com.example.seller

import android.content.Context
import android.provider.Settings
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.File
import java.security.KeyFactory
import java.security.KeyStore
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Activation par code signé, lié au téléphone.
 *
 * Code = base64url(payload) + "." + base64url(signature ECDSA P-256 / SHA-256, DER)
 * payload = "DSV1|<identifiant téléphone>|<expiration epoch s, 0 = illimité>|<libellé>"
 * La clé privée reste chez toi (tools/activation.js) ; l'appli ne contient que la clé publique.
 */
object Activation {
    sealed class Result {
        data class Valid(val expiresAt: Long, val label: String) : Result()
        data class Invalid(val reason: String) : Result()
    }

    /** Identifiant à communiquer au vendeur de codes : 5 groupes de 4 hexadécimaux. */
    fun deviceCode(context: Context): String {
        val id = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val h = MessageDigest.getInstance("SHA-256").digest("darksurf-seller-v1:$id".toByteArray())
        return h.take(10).joinToString("") { "%02X".format(it) }.chunked(4).joinToString("-")
    }

    fun verify(
        code: String,
        deviceCode: String,
        nowSec: Long = System.currentTimeMillis() / 1000,
        publicKeyB64: String = BuildConfig.ACTIVATION_PUBLIC_KEY,
    ): Result {
        if (publicKeyB64.startsWith("REPLACE")) return Result.Invalid("Clé publique non configurée dans l'application.")
        try {
            val parts = code.trim().split(".")
            if (parts.size != 2) return Result.Invalid("Format de code invalide.")
            val flags = Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
            val payloadBytes = Base64.decode(parts[0], flags)
            val signature = Base64.decode(parts[1], flags)

            val key = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.decode(publicKeyB64, Base64.DEFAULT)))
            val v = Signature.getInstance("SHA256withECDSA")
            v.initVerify(key); v.update(payloadBytes)
            if (!v.verify(signature)) return Result.Invalid("Signature invalide.")

            val f = String(payloadBytes, Charsets.UTF_8).split("|", limit = 4)
            if (f.size != 4 || f[0] != "DSV1") return Result.Invalid("Code non reconnu.")
            if (!f[1].equals(deviceCode.trim(), ignoreCase = true)) return Result.Invalid("Code prévu pour un autre téléphone.")
            val exp = f[2].toLongOrNull() ?: return Result.Invalid("Code non reconnu.")
            if (exp != 0L && nowSec > exp) return Result.Invalid("Code expiré.")
            return Result.Valid(exp, f[3])
        } catch (e: Exception) {
            return Result.Invalid("Code invalide.")
        }
    }
}

/** Stockage chiffré AES-256-GCM (clé dans l'AndroidKeyStore) pour l'identifiant revendeur. */
class SecureStore(context: Context, name: String) {
    private val file = File(context.noBackupFilesDir, name)
    private val aad = "com.example.seller/$name".toByteArray()

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return gen.generateKey()
    }

    @Synchronized
    fun write(plain: String) {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key()); c.updateAAD(aad)
        val iv = c.iv
        val out = byteArrayOf(iv.size.toByte()) + iv + c.doFinal(plain.toByteArray())
        val tmp = File(file.parentFile, file.name + ".part")
        tmp.outputStream().use { it.write(out); it.fd.sync() }
        if (!tmp.renameTo(file)) { tmp.delete(); error("écriture impossible") }
    }

    @Synchronized
    fun read(): String? {
        if (!file.exists()) return null
        return runCatching {
            val b = file.readBytes(); val n = b[0].toInt()
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b.copyOfRange(1, 1 + n)))
            c.updateAAD(aad)
            String(c.doFinal(b, 1 + n, b.size - 1 - n))
        }.getOrNull()
    }

    @Synchronized
    fun clear() { file.delete() }

    private companion object { const val ALIAS = "seller.storage.v1" }
}
