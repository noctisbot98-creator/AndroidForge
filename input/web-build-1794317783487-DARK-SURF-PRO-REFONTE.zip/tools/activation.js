#!/usr/bin/env node
// Émet et vérifie les codes d'activation de l'appli vendeur DARK_SURF PRO.
//   node activation.js keygen [dossier]
//   node activation.js issue  --device AAAA-BBBB-CCCC-DDDD-EEEE [--days 30] [--label nom] [--key seller-private.pem]
//   node activation.js verify --code <code> --device <id> [--pub seller-public.b64]
// Code = base64url(payload) + "." + base64url(signature ECDSA P-256/SHA-256 DER)
// payload = "DSV1|<id téléphone>|<expiration epoch s, 0 = illimité>|<libellé>"
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const DEVICE_RE = /^[0-9A-F]{4}(-[0-9A-F]{4}){4}$/;

function keygen(dir = '.') {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const priv = path.join(dir, 'seller-private.pem');
  fs.writeFileSync(priv, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
  const spki = publicKey.export({ type: 'spki', format: 'der' }).toString('base64');
  fs.writeFileSync(path.join(dir, 'seller-public.b64'), spki + '\n');
  return { priv, spki };
}

function issue({ privatePem, device, days = 30, label = 'vendeur', exp }) {
  device = String(device).trim().toUpperCase();
  if (!DEVICE_RE.test(device)) throw new Error('identifiant invalide (attendu : AAAA-BBBB-CCCC-DDDD-EEEE)');
  if (exp === undefined) exp = days > 0 ? Math.floor(Date.now() / 1000) + Math.round(days * 86400) : 0;
  const clean = String(label).replace(/[|\r\n]/g, ' ').slice(0, 40);
  const payload = Buffer.from(['DSV1', device, exp, clean].join('|'));
  const sig = crypto.sign('sha256', payload, crypto.createPrivateKey(privatePem)); // DER
  return payload.toString('base64url') + '.' + sig.toString('base64url');
}

// Reflète exactement Activation.verify() côté Android.
function verify({ code, device, publicB64, nowSec = Math.floor(Date.now() / 1000) }) {
  try {
    const parts = code.trim().split('.');
    if (parts.length !== 2) return { ok: false, reason: 'format' };
    const payload = Buffer.from(parts[0], 'base64url');
    const sig = Buffer.from(parts[1], 'base64url');
    const key = crypto.createPublicKey({ key: Buffer.from(publicB64, 'base64'), format: 'der', type: 'spki' });
    if (!crypto.verify('sha256', payload, key, sig)) return { ok: false, reason: 'signature' };
    const f = payload.toString().split('|');
    if (f.length < 4 || f[0] !== 'DSV1') return { ok: false, reason: 'non reconnu' };
    const label = f.slice(3).join('|');
    if (f[1].toUpperCase() !== String(device).trim().toUpperCase()) return { ok: false, reason: 'autre téléphone' };
    const exp = Number(f[2]);
    if (!Number.isInteger(exp)) return { ok: false, reason: 'non reconnu' };
    if (exp !== 0 && nowSec > exp) return { ok: false, reason: 'expiré' };
    return { ok: true, exp, label };
  } catch { return { ok: false, reason: 'invalide' }; }
}

module.exports = { keygen, issue, verify };

if (require.main === module) {
  const [cmd, ...rest] = process.argv.slice(2);
  const opt = {};
  for (let i = 0; i < rest.length; i++) if (rest[i].startsWith('--')) opt[rest[i].slice(2)] = rest[++i];
  try {
    if (cmd === 'keygen') {
      const { priv, spki } = keygen(rest[0] || '.');
      console.log(`Clé privée : ${priv}  (GARDE-LA SECRÈTE, ne la mets jamais dans l'appli)`);
      console.log(`Clé publique à coller dans ACTIVATION_PUBLIC_KEY (app/build.gradle.kts) :\n${spki}`);
    } else if (cmd === 'issue') {
      const pem = fs.readFileSync(opt.key || 'seller-private.pem', 'utf8');
      console.log(issue({ privatePem: pem, device: opt.device, days: opt.days === undefined ? 30 : Number(opt.days), label: opt.label }));
    } else if (cmd === 'verify') {
      const pub = fs.readFileSync(opt.pub || 'seller-public.b64', 'utf8').trim();
      console.log(JSON.stringify(verify({ code: opt.code, device: opt.device, publicB64: pub })));
    } else {
      console.log('Usage : keygen | issue --device ID [--days N] [--label X] | verify --code C --device ID');
      process.exit(1);
    }
  } catch (e) { console.error('Erreur :', e.message); process.exit(1); }
}
