const assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path');
const { keygen, issue, verify } = require('./activation');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsv-'));
const { spki } = keygen(dir);
const pem = fs.readFileSync(path.join(dir, 'seller-private.pem'), 'utf8');
const dev = 'A1B2-C3D4-E5F6-0718-9ABC', now = Math.floor(Date.now() / 1000);

const code = issue({ privatePem: pem, device: dev, days: 30, label: 'Marie|test' });
assert.deepEqual(verify({ code, device: dev, publicB64: spki }).ok, true);
assert.equal(verify({ code, device: dev.toLowerCase(), publicB64: spki }).ok, true);        // casse ignorée
assert.equal(verify({ code, device: 'FFFF-FFFF-FFFF-FFFF-FFFF', publicB64: spki }).reason, 'autre téléphone');
assert.equal(verify({ code, device: dev, publicB64: spki, nowSec: now + 31 * 86400 }).reason, 'expiré');
assert.equal(verify({ code: issue({ privatePem: pem, device: dev, days: 0 }), device: dev, publicB64: spki, nowSec: now + 9e8 }).ok, true); // illimité
const [p, s] = code.split('.');
const forged = Buffer.from(Buffer.from(p, 'base64url').toString().replace(/\|\d+\|/, '|0|')).toString('base64url') + '.' + s;
assert.equal(verify({ code: forged, device: dev, publicB64: spki }).reason, 'signature');   // expiration falsifiée
const other = keygen(fs.mkdtempSync(path.join(os.tmpdir(), 'dsv-')));
assert.equal(verify({ code, device: dev, publicB64: other.spki }).reason, 'signature');     // mauvaise clé
assert.throws(() => issue({ privatePem: pem, device: 'xyz' }));
console.log('OK : émission, vérification, expiration, falsification, autre téléphone, autre clé');
