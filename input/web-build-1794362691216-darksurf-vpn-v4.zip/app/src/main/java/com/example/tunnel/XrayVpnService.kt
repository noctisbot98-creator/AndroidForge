package com.example.tunnel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import org.json.JSONArray
import org.json.JSONObject

/**
 * Tunnel : VpnService Android + noyau Xray (bibliothèque libv2ray de AndroidLibXrayLite).
 * Le noyau lit directement l'interface TUN (descripteur de fichier) : pas de pont tun2socks à part.
 * L'appli elle-même est exclue du tunnel (API, mises à jour) : aucune boucle, aucun quota consommé par elle.
 */
class XrayVpnService : VpnService() {
    private var pfd: ParcelFileDescriptor? = null
    private var core: CoreController? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopTunnel(); return START_NOT_STICKY }
        val profile = intent?.getStringExtra(EXTRA_PROFILE)?.let { runCatching { Profile.fromJson(JSONObject(it)) }.getOrNull() }
        if (profile == null) { fail("bad_profile"); return START_NOT_STICKY }
        goForeground()
        Thread { startTunnel(profile) }.start()
        return START_NOT_STICKY       // jamais relancé seul : la session et le forfait se vérifient côté appli
    }

    private fun startTunnel(p: Profile) = synchronized(LOCK) {
        try {
            stopCore()
            Libv2ray.initCoreEnv(filesDir.absolutePath, "")
            // Le noyau ne doit PAS résoudre le nom du serveur lui-même (sa requête DNS passerait dans le tunnel qui n'existe pas encore) :
            // on le résout ici, hors tunnel (l'appli est exclue du VPN), et on lui donne l'adresse IP.
            val ip = java.net.InetAddress.getAllByName(p.address).firstOrNull { it is java.net.Inet4Address }?.hostAddress
                ?: throw IllegalStateException("dns_failed:" + p.address)
            val b = Builder().setSession("DARK_SURF").setMtu(1500)
                .addAddress("10.10.14.2", 30).addRoute("0.0.0.0", 0).addDnsServer(p.dns).setBlocking(false)
            runCatching { b.addDisallowedApplication(packageName) }
            val fd = b.establish() ?: throw IllegalStateException("vpn_denied")
            pfd = fd
            val c = Libv2ray.newCoreController(object : CoreCallbackHandler {
                override fun startup(): Long = 0
                override fun shutdown(): Long = 0
                override fun onEmitStatus(code: Long, msg: String?): Long = 0
            })
            // Android : le noyau lit le descripteur du TUN dans XRAY_TUN_FD (documentation Xray, entrée « tun »).
            runCatching { android.system.Os.setenv("XRAY_TUN_FD", fd.fd.toString(), true) }
            c.startLoop(xrayConfig(p, ip), fd.fd)
            core = c
            error = null; running = true
        } catch (e: Throwable) {
            fail(e.message ?: e.javaClass.simpleName)
        }
    }

    private fun fail(why: String) {
        error = why; running = false
        stopCore()
        stopForegroundCompat(); stopSelf()
    }

    private fun stopCore() {
        runCatching { core?.stopLoop() }; core = null
        runCatching { pfd?.close() }; pfd = null
    }

    private fun stopTunnel() = synchronized(LOCK) {
        running = false
        stopCore()
        stopForegroundCompat(); stopSelf()
    }

    override fun onRevoke() { stopTunnel() }
    override fun onDestroy() { running = false; stopCore(); super.onDestroy() }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "VPN", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH).setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("DARK_SURF").setContentText(Lang.t("Connecté", "Connected"))
            .setContentIntent(open).setOngoing(true).build()
        runCatching {
            if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
            else startForeground(1, n)
        }
    }

    private fun stopForegroundCompat() { runCatching { stopForeground(STOP_FOREGROUND_REMOVE) } }

    companion object {
        const val ACTION_STOP = "com.example.tunnel.STOP"
        const val EXTRA_PROFILE = "profile"
        private const val CH = "vpn"
        private val LOCK = Any()
        @Volatile var running = false
        @Volatile var error: String? = null

        /** Configuration cliente Xray : entrée TUN -> VLESS/WebSocket/TLS vers le serveur. */
        fun xrayConfig(p: Profile, ip: String): String {
            val tls = JSONObject().put("serverName", p.sni).put("fingerprint", "chrome").put("alpn", JSONArray().put("http/1.1"))
            val out = JSONObject().put("tag", "proxy").put("protocol", "vless")
                .put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject()
                    .put("address", ip).put("port", p.port)
                    .put("users", JSONArray().put(JSONObject().put("id", p.uuid).put("encryption", "none"))))))
                .put("streamSettings", JSONObject().put("network", "ws").put("security", "tls")
                    .put("tlsSettings", tls)
                    .put("wsSettings", JSONObject().put("path", p.path).put("headers", JSONObject().put("Host", p.sni)))
                    .put("sockopt", JSONObject().put("tcpNoDelay", true).put("tcpFastOpen", true).put("tcpKeepAliveIdle", 30).put("tcpKeepAliveInterval", 15)))
                .put("mux", JSONObject().put("enabled", false))
            val tun = JSONObject().put("tag", "tun").put("protocol", "tun")
                .put("settings", JSONObject().put("name", "xray0").put("mtu", 1500))
                .put("sniffing", JSONObject().put("enabled", true).put("destOverride", JSONArray().put("http").put("tls")))
            return JSONObject()
                .put("log", JSONObject().put("loglevel", "warning"))
                .put("inbounds", JSONArray().put(tun))
                .put("routing", JSONObject().put("domainStrategy", "AsIs"))
                .put("outbounds", JSONArray().put(out).put(JSONObject().put("tag", "direct").put("protocol", "freedom")))
                .toString()
        }
    }
}
