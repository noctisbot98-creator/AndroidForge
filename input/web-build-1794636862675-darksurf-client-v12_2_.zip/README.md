# DARK_SURF (Android, Kotlin)

Client VPN : code TUN -> identité ECDSA (Android Keystore) -> session signée -> tunnel Xray/VLESS sur WebSocket + TLS.

- `app/` : application (ouvrir ce dossier dans Android Studio, puis éditer `API_BASE` dans `app/build.gradle.kts`).
- `server-mock/` : mock de l'API pour tester (`node server-mock/test.js`).
- `docs/API.md` : contrat client/serveur.
- Le backend attendu expose `POST /api/v1/enroll`, `challenge`, `session`, `status` et `app/android`.
- L’adresse API est configurée sur `https://vpn.zidanexmd.space/api/v1/`. Le serveur doit renvoyer un profil VLESS dont `address`, `sni`, `port` et `path` correspondent à sa configuration Xray/Caddy.
- AndroidForge : `preBuild` télécharge automatiquement `libv2ray.aar` (AndroidLibXrayLite v26.10.31). Aucun pré-build manuel n’est nécessaire.

Le tunnel utilise `com.wireguard.android:tunnel` (WireGuard-go userspace + VpnService).


## Identité visuelle DARK SURF — pétrole profond et turquoise (novembre 2026)

- Identité DARK SURF unifiée : pétrole profond `#071412`, surfaces `#102522`, turquoise `#00D6B8`, cuivre `#E6A45B`, texte `#F1F5F2`.
- Contraste et hiérarchie visuelle harmonisés entre les deux applications.
- Architecture réseau conservée : VPN Xray/VLESS WebSocket + TLS.
- Correctif réseau : prise en charge des routes IPv4/IPv6, MTU 1400 et transmission du descripteur TUN via l'API StartLoop d'AndroidLibXrayLite.
- Version Android portée à 0.3.0 (versionCode 2).
- Cette livraison est un projet Android source pour AndroidForge, pas un APK précompilé.
