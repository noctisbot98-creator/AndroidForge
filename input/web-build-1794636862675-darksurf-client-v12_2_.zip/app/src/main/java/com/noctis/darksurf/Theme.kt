package com.noctis.darksurf

import android.content.res.Resources
import android.graphics.Color
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Identité visuelle DARK_SURF : pétrole profond, turquoise et cuivre. */
object Ds {
    // ---- fonds ----
    val BG = Color.parseColor("#071412")          // pétrole profond
    val BG2 = Color.parseColor("#102522")         // pétrole éclairci
    val SURFACE = Color.parseColor("#102522")     // carte
    val SURFACE2 = Color.parseColor("#173630")    // carte surélevée
    val LINE = Color.parseColor("#28534B")        // filet

    // ---- accents ----
    val ACCENT = Color.parseColor("#00D6B8")      // cyan électrique
    val ACCENT2 = Color.parseColor("#E6A45B")     // indigo
    val WARM = Color.parseColor("#E6A45B")        // corail
    val OK = Color.parseColor("#72D6A3")          // vert de succès
    val ON = Color.parseColor("#00D6B8")          // état connecté
    val WARN = Color.parseColor("#E6A45B")        // ambre

    // ---- texte ----
    val TEXT = Color.parseColor("#F1F5F2")
    val MUTED = Color.parseColor("#91AAA1")
    val DANGER = Color.parseColor("#E6A45B")

    // ---- typographie ----
    val DISPLAY: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    val BLACK: Typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
    val BODY: Typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    val MEDIUM: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    val MONO: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    val SERIF: Typeface = Typeface.create("serif", Typeface.ITALIC)
}

val Int.dp: Int get() = (this * Resources.getSystem().displayMetrics.density).toInt()
val Float.dp: Float get() = this * Resources.getSystem().displayMetrics.density

/** Bilingue FR/EN. */
object Lang {
    @Volatile var fr: Boolean = Locale.getDefault().language == "fr"
    fun t(f: String, e: String) = if (fr) f else e
    fun locale(): Locale = if (fr) Locale.FRANCE else Locale.US
}

fun fmtBytes(b: Long): String {
    val unit = Lang.t("o", "B")
    val v = b.toDouble()
    return when {
        v >= 1e9 -> "%.2f G%s".format(Lang.locale(), v / 1e9, unit)
        v >= 1e6 -> "%.1f M%s".format(Lang.locale(), v / 1e6, unit)
        v >= 1e3 -> "%.0f k%s".format(Lang.locale(), v / 1e3, unit)
        else -> "$b $unit"
    }
}

fun fmtDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

/** Durée lisible : « 2 j 4 h », « 3 h 12 min », « 8 min ». */
fun fmtSpan(seconds: Long): String {
    if (seconds <= 0) return "—"
    val d = seconds / 86400
    val h = (seconds % 86400) / 3600
    val m = (seconds % 3600) / 60
    return when {
        d > 0 -> "$d ${Lang.t("j", "d")} $h h"
        h > 0 -> "$h h $m min"
        else -> "$m min"
    }
}

fun fmtDate(epochMs: Long, pattern: String = "d MMM yyyy"): String =
    SimpleDateFormat(pattern, Lang.locale()).format(Date(epochMs))

/** Qualité de connexion déduite de la latence mesurée (ms). */
enum class Quality(val labelFr: String, val labelEn: String, val color: Int) {
    EXCELLENT("Excellente", "Excellent", Ds.OK),
    GOOD("Bonne", "Good", Ds.ACCENT),
    FAIR("Moyenne", "Fair", Ds.WARN),
    POOR("Faible", "Poor", Ds.DANGER),
    UNKNOWN("—", "—", Ds.MUTED);

    fun label() = if (Lang.fr) labelFr else labelEn

    companion object {
        fun of(ms: Int): Quality = when {
            ms <= 0 -> UNKNOWN
            ms < 80 -> EXCELLENT
            ms < 180 -> GOOD
            ms < 400 -> FAIR
            else -> POOR
        }
    }
}
