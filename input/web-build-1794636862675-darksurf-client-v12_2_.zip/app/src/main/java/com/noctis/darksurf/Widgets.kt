package com.noctis.darksurf

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.drawable.Drawable
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

// ---------- helpers de construction ----------

fun rect(fill: Int, radius: Float = 16f, stroke: Int = 0, strokeW: Int = 1) = GradientDrawable().apply {
    setColor(fill); cornerRadius = radius.dp
    if (stroke != 0) setStroke(strokeW.dp, stroke)
}

/** Panneau : dégradé vertical subtil + filet fin. */
fun glass(radius: Float = 20f, strong: Boolean = false) = GradientDrawable(
    GradientDrawable.Orientation.TOP_BOTTOM,
    intArrayOf(if (strong) Ds.SURFACE2 else Ds.SURFACE, Ds.BG2)
).apply { cornerRadius = radius.dp; setStroke(1.dp, Ds.LINE) }

/** Fond DARK_SURF : abysse, halo cyan en haut à droite, halo indigo en bas à gauche. */
class GlowBackground : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat(); val h = bounds.height().toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, h, Ds.BG, Ds.BG2, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, w, h, p)
        fun glow(cx: Float, cy: Float, r: Float, col: Int, a: Int) {
            p.shader = RadialGradient(cx, cy, r, Color.argb(a, Color.red(col), Color.green(col), Color.blue(col)), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, p)
        }
        glow(w * 0.95f, h * 0.05f, w * 0.75f, Ds.ACCENT, 34)
        glow(w * 0.02f, h * 0.62f, w * 0.70f, Ds.ACCENT2, 30)
        glow(w * 0.85f, h * 0.98f, w * 0.50f, Ds.WARM, 14)
        p.shader = null
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(f: ColorFilter?) {}
    @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.OPAQUE
}

fun gradient(radius: Float = 16f) =
    GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Ds.ACCENT, Ds.ACCENT2)).apply {
        cornerRadius = radius.dp; setStroke(1.dp, Color.argb(120, 0, 214, 184))
    }

fun lin(w: Int = MATCH, h: Int = WRAP, top: Int = 0, weight: Float = 0f) =
    LinearLayout.LayoutParams(w, h, weight).apply { topMargin = top.dp }

fun Context.tv(s: CharSequence, size: Float, color: Int = Ds.TEXT, font: Typeface = Ds.BODY, spacing: Float = 0f) =
    TextView(this).apply {
        text = s; textSize = size; setTextColor(color); typeface = font; letterSpacing = spacing
    }

fun Context.col(pad: Int = 0) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; setPadding(pad.dp, pad.dp, pad.dp, pad.dp)
}

fun Context.row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

fun Context.card() = col().apply {
    background = glass(20f); setPadding(18.dp, 16.dp, 18.dp, 16.dp)
}

fun Context.primaryButton(label: String, onClick: () -> Unit) =
    tv(label.uppercase(), 14f, Color.parseColor("#071412"), Ds.DISPLAY, 0.12f).apply {
        gravity = Gravity.CENTER; background = gradient(14f); minHeight = 52.dp
        setOnClickListener { onClick() }
    }

fun Context.ghostButton(label: String, color: Int = Ds.ACCENT, onClick: () -> Unit) =
    tv(label.uppercase(), 12f, color, Ds.DISPLAY, 0.12f).apply {
        gravity = Gravity.CENTER; background = rect(Color.argb(18, 255, 255, 255), 14f, color, 1); minHeight = 46.dp
        setOnClickListener { onClick() }
    }

/** Petit libellé de section : monospace, espacé, discret. */
fun Context.overline(s: String) = tv(s.uppercase(), 10f, Ds.MUTED, Ds.MONO, 0.20f)

// ---------- logo ----------

/** Logo : anneau dégradé cyan→indigo + deux vagues (la « surf »). */
class LogoView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat()
        val cx = width / 2f; val cy = height / 2f
        p.shader = LinearGradient(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2, Ds.ACCENT, Ds.ACCENT2, Shader.TileMode.CLAMP)
        p.strokeWidth = s * 0.065f
        cv.drawCircle(cx, cy, s * 0.42f, p)
        for ((k, dy) in listOf(-0.10f, 0.12f).withIndex()) {
            val x0 = cx - s * 0.26f; val w = s * 0.52f; val y = cy + s * dy
            val path = Path().apply {
                moveTo(x0, y)
                quadTo(x0 + w * 0.25f, y - s * 0.14f, x0 + w * 0.5f, y)
                quadTo(x0 + w * 0.75f, y + s * 0.14f, x0 + w, y)
            }
            p.strokeWidth = s * (if (k == 0) 0.065f else 0.045f)
            cv.drawPath(path, p)
        }
    }
}

// ---------- bouton de connexion ----------

enum class Orb { IDLE, BUSY, ON }

fun drawPower(cv: Canvas, cx: Float, cy: Float, r: Float, color: Int, stroke: Float) {
    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = stroke; this.color = color
    }
    cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -60f, 300f, false, p)
    cv.drawLine(cx, cy - r * 1.15f, cx, cy - r * 0.1f, p)
}

/** Gros bouton rond animé : halo pulsé (connecté), arc rotatif (en cours), contour (prêt). */
class OrbView(c: Context) : View(c) {
    var state = Orb.IDLE
        set(v) { field = v; invalidate() }
    /** Couleur de l'étape en cours (change à chaque phase de la connexion). */
    var tint: Int = Ds.ACCENT
        set(v) { field = v; invalidate() }

    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (ValueAnimator.areAnimatorsEnabled()) anim.start()
    }

    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat()
        val cx = width / 2f; val cy = height / 2f; val r = s * 0.29f
        p.shader = null

        if (state == Orb.ON) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f.dp; p.color = tint
            for (k in 0..2) {
                val ph = (t + k / 3f) % 1f
                p.alpha = ((1f - ph) * 100).toInt()
                cv.drawCircle(cx, cy, r + ph * s * 0.22f, p)
            }
            p.alpha = 255
        }
        // halo statique
        p.style = Paint.Style.FILL
        p.color = tint
        p.alpha = if (state == Orb.ON) 34 else 46
        cv.drawCircle(cx, cy, r * 1.26f, p)
        p.alpha = 255

        // disque
        if (state == Orb.ON) {
            p.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r, tint, Ds.ACCENT2, Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, r, p)
            p.shader = null
        } else {
            p.color = Color.argb(46, 255, 255, 255)
            cv.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f.dp
            p.color = tint
            cv.drawCircle(cx, cy, r, p)
        }
        if (state == Orb.BUSY) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f.dp; p.strokeCap = Paint.Cap.ROUND; p.color = tint
            cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), t * 360f, 90f, false, p)
        }
        val icon = when (state) { Orb.ON -> Color.parseColor("#071412"); Orb.BUSY -> tint; Orb.IDLE -> tint }
        drawPower(cv, cx, cy, r * 0.38f, icon, 5f.dp)
    }
}

/** Éléments de la carte citation, pour changer sa couleur sans reconstruire l'écran. */
class QuoteViews(val card: FrameLayout, val mark: TextView, val text: TextView, val sig: TextView) {
    fun paint(accent: Int) {
        card.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#102522"), Color.argb(255, (Color.red(accent) / 6) + 10, (Color.green(accent) / 6) + 22, (Color.blue(accent) / 6) + 24))).apply {
            cornerRadius = 26f.dp; setStroke(2.dp, Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
        mark.setTextColor(Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent)))
        sig.setTextColor(accent)
    }
}

/** Carte « citation dark » : guillemet géant, texte serif italique, signature ; sa couleur suit l'état de la connexion. */
fun Context.quoteCard(quote: String, accent: Int = Ds.WARM, bind: (QuoteViews) -> Unit = {}, onClick: () -> Unit): View = FrameLayout(this).apply {
    val mark = TextView(context).apply { text = "”"; textSize = 96f; typeface = Ds.SERIF }
    addView(mark, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply { rightMargin = 18.dp; topMargin = (-14).dp })
    val qt = tv(quote, 19f, Ds.TEXT, Ds.SERIF).apply { setLineSpacing(0f, 1.15f) }
    val sg = tv("— DARK SURF", 12f, accent, Ds.MONO, 0.2f)
    addView(col().apply {
        setPadding(22.dp, 20.dp, 22.dp, 18.dp)
        addView(overline("DARK"), lin())
        addView(qt, lin(MATCH, WRAP, 10))
        addView(sg, lin(WRAP, WRAP, 12))
    })
    val qv = QuoteViews(this, mark, qt, sg); qv.paint(accent); bind(qv)
    setOnClickListener { onClick() }
}

/** Bouton central surélevé de la barre du bas. */
class PowerBadge(c: Context) : View(c) {
    var busy = false
        set(v) { field = v; alpha = if (v) 0.6f else 1f }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f - 2f.dp
        p.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r, Ds.ACCENT, Ds.ACCENT2, Shader.TileMode.CLAMP)
        p.style = Paint.Style.FILL
        cv.drawCircle(cx, cy, r, p)
        p.shader = null
        drawPower(cv, cx, cy, r * 0.36f, Color.parseColor("#071412"), 3.5f.dp)
    }
}

// ---------- icônes de navigation ----------

class IconView(c: Context, private val kind: String) : View(c) {
    var tint = Ds.MUTED
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Ds.DISPLAY }

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat()
        val x = (width - s) / 2; val y = (height - s) / 2
        p.color = tint; p.strokeWidth = s * 0.085f
        fun px(f: Float) = x + f * s
        fun py(f: Float) = y + f * s
        when (kind) {
            "home" -> cv.drawPath(Path().apply {
                moveTo(px(.12f), py(.48f)); lineTo(px(.5f), py(.14f)); lineTo(px(.88f), py(.48f))
                moveTo(px(.22f), py(.42f)); lineTo(px(.22f), py(.86f)); lineTo(px(.78f), py(.86f)); lineTo(px(.78f), py(.42f))
            }, p)
            "activity" -> cv.drawPath(Path().apply {
                moveTo(px(.08f), py(.55f)); lineTo(px(.3f), py(.55f)); lineTo(px(.42f), py(.2f))
                lineTo(px(.6f), py(.85f)); lineTo(px(.72f), py(.45f)); lineTo(px(.92f), py(.45f))
            }, p)
            "settings" -> for ((yy, kx) in listOf(.25f to .3f, .5f to .7f, .75f to .45f)) {
                cv.drawLine(px(.12f), py(yy), px(.88f), py(yy), p)
                cv.drawCircle(px(kx), py(yy), s * 0.085f, p)
            }
            "key" -> {
                cv.drawCircle(px(.3f), py(.62f), s * 0.17f, p)
                cv.drawLine(px(.42f), py(.5f), px(.88f), py(.12f), p)
                cv.drawLine(px(.74f), py(.22f), px(.84f), py(.32f), p)
            }
            "card" -> {
                cv.drawRoundRect(RectF(px(.1f), py(.2f), px(.9f), py(.8f)), s * .1f, s * .1f, p)
                cv.drawLine(px(.1f), py(.42f), px(.9f), py(.42f), p)
                cv.drawLine(px(.22f), py(.64f), px(.4f), py(.64f), p)
            }
            "check" -> {
                cv.drawCircle(px(.5f), py(.5f), s * 0.4f, p)
                cv.drawPath(Path().apply { moveTo(px(.32f), py(.52f)); lineTo(px(.45f), py(.65f)); lineTo(px(.69f), py(.37f)) }, p)
            }
            "globe" -> {
                cv.drawCircle(px(.5f), py(.5f), s * 0.4f, p)
                cv.drawLine(px(.1f), py(.5f), px(.9f), py(.5f), p)
                cv.drawOval(RectF(px(.28f), py(.1f), px(.72f), py(.9f)), p)
            }
            "shield" -> cv.drawPath(Path().apply {
                moveTo(px(.5f), py(.1f)); lineTo(px(.86f), py(.26f)); lineTo(px(.86f), py(.55f))
                quadTo(px(.86f), py(.82f), px(.5f), py(.92f))
                quadTo(px(.14f), py(.82f), px(.14f), py(.55f)); lineTo(px(.14f), py(.26f)); close()
            }, p)
            "clock" -> {
                cv.drawCircle(px(.5f), py(.5f), s * 0.4f, p)
                cv.drawLine(px(.5f), py(.5f), px(.5f), py(.26f), p)
                cv.drawLine(px(.5f), py(.5f), px(.7f), py(.6f), p)
            }
            "server" -> {
                cv.drawRoundRect(RectF(px(.12f), py(.16f), px(.88f), py(.44f)), s * .06f, s * .06f, p)
                cv.drawRoundRect(RectF(px(.12f), py(.56f), px(.88f), py(.84f)), s * .06f, s * .06f, p)
                cv.drawCircle(px(.26f), py(.3f), s * .04f, p)
                cv.drawCircle(px(.26f), py(.7f), s * .04f, p)
            }
            else -> {
                cv.drawCircle(px(.5f), py(.5f), s * 0.4f, p)
                tp.color = tint; tp.textSize = s * 0.55f
                cv.drawText("?", px(.5f), py(.5f) + s * 0.2f, tp)
            }
        }
    }
}

/** Barre de progression dégradée cyan → indigo. */
class BarView(c: Context, frac0: Float) : View(c) {
    var frac = frac0
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val h = height.toFloat(); val rad = h / 2
        p.shader = null; p.color = Color.argb(40, 255, 255, 255)
        cv.drawRoundRect(RectF(0f, 0f, width.toFloat(), h), rad, rad, p)
        val w = width * frac.coerceIn(0f, 1f)
        if (w > 0f) {
            p.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, Ds.ACCENT, Ds.ACCENT2, Shader.TileMode.CLAMP)
            cv.drawRoundRect(RectF(0f, 0f, maxOf(w, h), h), rad, rad, p)
        }
    }
}

/** Courbe de trafic en direct : réception (cyan) et envoi (corail), jusqu'à 60 mesures. */
class ChartView(c: Context) : View(c) {
    var rx: List<Float> = emptyList()
    var tx: List<Float> = emptyList()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.2f.dp; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val grid = Paint().apply { color = Color.argb(34, 140, 170, 230); strokeWidth = 1f; pathEffect = android.graphics.DashPathEffect(floatArrayOf(8f, 10f), 0f) }

    fun set(r: List<Float>, t: List<Float>) { rx = r; tx = t; invalidate() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat() - 4f.dp
        for (i in 0..3) cv.drawLine(0f, h * i / 3f, w, h * i / 3f, grid)
        val max = maxOf(1f, (rx + tx).maxOrNull() ?: 1f) * 1.15f
        fun line(d: List<Float>, col: Int, withFill: Boolean) {
            if (d.size < 2) return
            val path = Path()
            d.forEachIndexed { i, v ->
                val x = w * i / 59f; val y = h - (v / max) * h
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            if (withFill) {
                val area = Path(path).apply { lineTo(w * (d.size - 1) / 59f, h); lineTo(0f, h); close() }
                fill.shader = LinearGradient(0f, 0f, 0f, h, Color.argb(70, Color.red(col), Color.green(col), Color.blue(col)), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                cv.drawPath(area, fill)
            }
            p.color = col; cv.drawPath(path, p)
        }
        line(rx, Ds.ACCENT, true); line(tx, Ds.WARM, false)
    }
}

/** Icône cloche (notifications). */
class BellView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = Ds.TEXT }
    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat(); val x = (width - s) / 2; val y = (height - s) / 2
        p.strokeWidth = s * 0.075f
        val path = Path().apply {
            moveTo(x + s * .2f, y + s * .72f); lineTo(x + s * .8f, y + s * .72f)
            quadTo(x + s * .68f, y + s * .62f, x + s * .68f, y + s * .42f)
            cubicTo(x + s * .68f, y + s * .14f, x + s * .32f, y + s * .14f, x + s * .32f, y + s * .42f)
            quadTo(x + s * .32f, y + s * .62f, x + s * .2f, y + s * .72f)
        }
        cv.drawPath(path, p)
        cv.drawLine(x + s * .42f, y + s * .84f, x + s * .58f, y + s * .84f, p)
    }
}

/** Ligne de réglage : titre, sous-titre, chevron. */
fun Context.settingRow(title: String, sub: String, onClick: () -> Unit) = row().apply {
    background = glass(18f); setPadding(16.dp, 14.dp, 14.dp, 14.dp)
    addView(col().apply {
        addView(tv(title, 15f, Ds.TEXT, Ds.MEDIUM))
        addView(tv(sub, 12f, Ds.MUTED, Ds.BODY), lin(WRAP, WRAP, 2))
    }, lin(0, WRAP, 0, 1f))
    addView(tv("›", 22f, Ds.MUTED, Ds.BODY))
    setOnClickListener { onClick() }
}

fun Context.switchRow(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) = row().apply {
    background = glass(18f); setPadding(16.dp, 12.dp, 12.dp, 12.dp)
    addView(col().apply {
        addView(tv(title, 15f, Ds.TEXT, Ds.MEDIUM))
        addView(tv(sub, 12f, Ds.MUTED, Ds.BODY), lin(WRAP, WRAP, 2))
    }, lin(0, WRAP, 0, 1f))
    addView(android.widget.Switch(context).apply {
        isChecked = on
        setOnCheckedChangeListener { _, v -> onChange(v) }
    })
}

/** Signature de l'auteur : discrète, capitales aérées sur un filet fin. */
fun Context.signature(): View = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
    addView(View(context).apply { setBackgroundColor(Ds.LINE) }, LinearLayout.LayoutParams(36.dp, 1.dp).apply { bottomMargin = 10.dp })
    addView(TextView(context).apply {
        text = "BY NOCTIS"; textSize = 11f; setTextColor(Ds.MUTED); letterSpacing = 0.42f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); gravity = Gravity.CENTER
    })
}

/** Pastille d'état : point coloré + libellé. */
fun Context.pill(label: String, color: Int) = row().apply {
    background = rect(Color.argb(30, Color.red(color), Color.green(color), Color.blue(color)), 20f, Color.argb(90, Color.red(color), Color.green(color), Color.blue(color)), 1)
    setPadding(12.dp, 6.dp, 14.dp, 6.dp)
    addView(View(context).apply { background = rect(color, 8f) }, lin(7.dp, 7.dp))
    addView(tv(label, 11f, color, Ds.MEDIUM, 0.06f), lin(WRAP, WRAP).apply { leftMargin = 7.dp })
}

/** Tuile de statistique : libellé, valeur, unité. */
fun Context.statTile(label: String, value: String, unit: String, accent: Int) = col().apply {
    background = glass(16f); setPadding(14.dp, 12.dp, 14.dp, 12.dp)
    addView(tv(label.uppercase(), 9f, Ds.MUTED, Ds.MONO, 0.14f))
    addView(row().apply {
        addView(tv(value, 20f, Ds.TEXT, Ds.DISPLAY), lin(WRAP, WRAP).apply { rightMargin = 4.dp })
        addView(tv(unit, 10f, accent, Ds.MONO), lin(WRAP, WRAP).apply { bottomMargin = 3.dp })
    }, lin(WRAP, WRAP, 4))
}
