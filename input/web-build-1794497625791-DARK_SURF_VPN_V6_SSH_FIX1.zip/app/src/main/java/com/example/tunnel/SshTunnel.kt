package com.example.tunnel

import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import com.jcraft.jsch.ChannelDirectTCPIP
import com.jcraft.jsch.SocketFactory
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.InetAddress
import java.io.DataInputStream
import java.io.DataOutputStream
import java.util.concurrent.CopyOnWriteArrayList
import java.security.SecureRandom
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/** Client SSH DARK SURF. Le tunnel SSH fournit un SOCKS local consommé par Xray/TUN. */
object SshTunnel {
    private var session: Session? = null
    private var socksServer: ServerSocket? = null
    private val clients = CopyOnWriteArrayList<Socket>()
    private const val SOCKS_PORT = 10808

    @Synchronized fun start(p: SshProfile, mode: String) {
        stop()
        val jsch = JSch()
        val known = "[${p.host}]:${if (mode == "ssh-ws") p.wsPort else if (mode == "ssh-payload") p.payloadPort else p.tcpPort} ${p.hostKey}\n"
        jsch.setKnownHosts(ByteArrayInputStream(known.toByteArray(Charsets.UTF_8)))
        val s = jsch.getSession(p.username, p.host, when (mode) {
            "ssh-ws" -> p.wsPort
            "ssh-payload" -> p.payloadPort
            else -> p.tcpPort
        })
        s.setPassword(p.password)
        s.setConfig("StrictHostKeyChecking", "yes")
        s.setConfig("PreferredAuthentications", "password")
        s.setServerAliveInterval(25_000)
        s.setServerAliveCountMax(3)
        when (mode) {
            "ssh-ws" -> s.setSocketFactory(WebSocketSocketFactory(p.host, p.wsPath))
            "ssh-payload" -> s.setSocketFactory(PayloadSocketFactory(p.host, p.tcpPort))
        }
        s.connect(20_000)
        session = s
        startSocksProxy(s)
    }

    @Synchronized fun stop() {
        runCatching { socksServer?.close() }; socksServer = null
        clients.forEach { runCatching { it.close() } }; clients.clear()
        runCatching { session?.disconnect() }; session = null
    }

    /** SOCKS5 local : chaque requête ouvre un canal SSH direct-tcpip (équivalent ssh -D). */
    private fun startSocksProxy(ssh: Session) {
        val server = ServerSocket()
        server.reuseAddress = true
        server.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), SOCKS_PORT))
        socksServer = server
        Thread({
            while (!server.isClosed && ssh.isConnected) {
                try {
                    val client = server.accept()
                    clients.add(client)
                    Thread({ handleSocksClient(client, ssh) }, "dark-surf-socks-client").apply { isDaemon = true; start() }
                } catch (_: Exception) { if (!server.isClosed) continue else break }
            }
        }, "dark-surf-socks-listener").apply { isDaemon = true; start() }
    }

    private fun handleSocksClient(client: Socket, ssh: Session) {
        var channel: ChannelDirectTCPIP? = null
        try {
            client.soTimeout = 20_000
            val input = DataInputStream(client.getInputStream())
            val output = DataOutputStream(client.getOutputStream())
            if (input.readUnsignedByte() != 5) throw java.io.IOException("socks_version")
            val methods = input.readUnsignedByte(); repeat(methods) { input.readUnsignedByte() }
            output.write(byteArrayOf(5, 0)); output.flush() // no-auth local proxy
            if (input.readUnsignedByte() != 5) throw java.io.IOException("socks_request")
            val command = input.readUnsignedByte(); input.readUnsignedByte() // RSV
            val atyp = input.readUnsignedByte()
            val host = when (atyp) {
                1 -> ByteArray(4).also(input::readFully).joinToString(".") { (it.toInt() and 255).toString() }
                3 -> ByteArray(input.readUnsignedByte()).also(input::readFully).toString(Charsets.UTF_8)
                4 -> ByteArray(16).also(input::readFully).let { InetAddress.getByAddress(it).hostAddress }
                else -> throw java.io.IOException("socks_address_type")
            }
            val port = input.readUnsignedShort()
            if (command != 1) { output.write(byteArrayOf(5, 7, 0, 1, 0, 0, 0, 0, 0, 0)); output.flush(); return }
            val ch = ssh.openChannel("direct-tcpip") as ChannelDirectTCPIP
            ch.setHost(host); ch.setPort(port); ch.setOrgIPAddress("127.0.0.1"); ch.setOrgPort(client.port)
            ch.connect(15_000); channel = ch
            output.write(byteArrayOf(5, 0, 0, 1, 0, 0, 0, 0, 0, 0)); output.flush()
            client.soTimeout = 0
            val upstreamIn = ch.inputStream; val upstreamOut = ch.outputStream
            val toSsh = Thread({ runCatching { client.getInputStream().copyTo(upstreamOut); upstreamOut.flush() } }, "dark-surf-socks-up").apply { isDaemon = true; start() }
            runCatching { upstreamIn.copyTo(client.getOutputStream()); client.getOutputStream().flush() }
            toSsh.interrupt()
        } catch (_: Exception) {
            runCatching { client.getOutputStream().write(byteArrayOf(5, 1, 0, 1, 0, 0, 0, 0, 0, 0)) }
        } finally {
            runCatching { channel?.disconnect() }; clients.remove(client); runCatching { client.close() }
        }
    }

    fun socksConfig(dns: String): String = org.json.JSONObject()
        .put("log", org.json.JSONObject().put("loglevel", "warning"))
        .put("inbounds", org.json.JSONArray().put(org.json.JSONObject().put("tag", "tun").put("protocol", "tun")
            .put("settings", org.json.JSONObject().put("name", "xray0").put("mtu", 1400))))
        .put("dns", org.json.JSONObject().put("servers", org.json.JSONArray().put("https://$dns/dns-query")).put("tag", "proxy"))
        .put("outbounds", org.json.JSONArray()
            .put(org.json.JSONObject().put("tag", "proxy").put("protocol", "socks")
                .put("settings", org.json.JSONObject().put("servers", org.json.JSONArray().put(org.json.JSONObject().put("address", "127.0.0.1").put("port", SOCKS_PORT)))))
            .put(org.json.JSONObject().put("tag", "direct").put("protocol", "freedom")))
        .put("routing", org.json.JSONObject().put("domainStrategy", "AsIs")).toString()

    private class PayloadSocketFactory(private val host: String, private val sshPort: Int) : SocketFactory {
        override fun createSocket(hostIgnored: String?, port: Int): Socket {
            val socket = Socket(); socket.connect(InetSocketAddress(host, port), 15_000); socket.soTimeout = 15_000
            val out = socket.getOutputStream()
            out.write("CONNECT $host:$sshPort HTTP/1.1\r\nHost: $host:$sshPort\r\nProxy-Connection: Keep-Alive\r\n\r\n".toByteArray())
            out.flush()
            val input = socket.getInputStream(); val header = ByteArrayOutputStream(); var state = 0
            while (header.size() < 8192 && state < 4) {
                val b = input.read(); if (b < 0) throw java.io.IOException("payload_no_response")
                header.write(b)
                state = when (state) { 0 -> if (b == 13) 1 else 0; 1 -> if (b == 10) 2 else 0; 2 -> if (b == 13) 3 else 0; 3 -> if (b == 10) 4 else 0; else -> state }
            }
            val response = header.toString("UTF-8")
            if (!response.startsWith("HTTP/1.1 200") && !response.startsWith("HTTP/1.0 200")) throw java.io.IOException("payload_rejected")
            socket.soTimeout = 0
            return socket
        }
        override fun getInputStream(socket: Socket) = socket.getInputStream()
        override fun getOutputStream(socket: Socket) = socket.getOutputStream()
    }

    /** RFC6455 binaire sur TLS : flux WebSocket transparent pour la pile SSH de JSch. */
    private class WebSocketSocketFactory(private val host: String, private val path: String) : SocketFactory {
        override fun createSocket(hostIgnored: String?, port: Int): Socket = WsSocket(host, port, path)
        override fun getInputStream(socket: Socket): InputStream = socket.getInputStream()
        override fun getOutputStream(socket: Socket): OutputStream = socket.getOutputStream()
    }

    private class WsSocket(host: String, port: Int, path: String) : Socket() {
        private val tls: SSLSocket = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket() as SSLSocket
        private val source: InputStream
        private val sink: OutputStream
        private val random = SecureRandom()
        private var closed = false
        init {
            tls.connect(InetSocketAddress(host, port), 15_000)
            tls.sslParameters = tls.sslParameters.apply { serverNames = listOf(javax.net.ssl.SNIHostName(host)) }
            tls.soTimeout = 15_000; tls.startHandshake()
            val keyBytes = ByteArray(16).also(random::nextBytes)
            val key = android.util.Base64.encodeToString(keyBytes, android.util.Base64.NO_WRAP)
            val rawOut = tls.outputStream
            rawOut.write("GET $path HTTP/1.1\r\nHost: $host\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: $key\r\nSec-WebSocket-Version: 13\r\n\r\n".toByteArray())
            rawOut.flush()
            val header = ByteArrayOutputStream(); var state = 0
            while (header.size() < 8192 && state < 4) {
                val b = tls.inputStream.read(); if (b < 0) throw java.io.IOException("ws_handshake_eof")
                header.write(b)
                state = when (state) { 0 -> if (b == 13) 1 else 0; 1 -> if (b == 10) 2 else 0; 2 -> if (b == 13) 3 else 0; 3 -> if (b == 10) 4 else 0; else -> state }
            }
            if (!header.toString("UTF-8").startsWith("HTTP/1.1 101")) throw java.io.IOException("ws_upgrade_rejected")
            tls.soTimeout = 0
            source = object : InputStream() {
                private var current = ByteArray(0); private var at = 0
                override fun read(): Int { val one = ByteArray(1); val n = read(one, 0, 1); return if (n < 0) -1 else one[0].toInt() and 255 }
                override fun read(b: ByteArray, off: Int, len: Int): Int {
                    if (len == 0) return 0
                    while (at >= current.size) {
                        val a = tls.inputStream.read(); if (a < 0) return -1
                        val b0 = tls.inputStream.read(); if (b0 < 0) return -1
                        val opcode = a and 15; var size = (b0 and 127).toLong()
                        if (size == 126L) size = ((tls.inputStream.read().toLong() shl 8) or tls.inputStream.read().toLong())
                        else if (size == 127L) { size = 0; repeat(8) { size = (size shl 8) or tls.inputStream.read().toLong() } }
                        if ((b0 and 128) != 0) throw java.io.IOException("masked_server_frame")
                        if (size > 1_048_576) throw java.io.IOException("ws_frame_too_large")
                        val payload = ByteArray(size.toInt()); var pos = 0
                        while (pos < payload.size) { val n = tls.inputStream.read(payload, pos, payload.size - pos); if (n < 0) throw java.io.IOException("ws_frame_eof"); pos += n }
                        when (opcode) {
                            8 -> return -1
                            9 -> { writeFrame(10, payload); continue }
                            10 -> continue
                            2, 0 -> { current = payload; at = 0 }
                            else -> continue
                        }
                    }
                    val n = minOf(len, current.size - at); System.arraycopy(current, at, b, off, n); at += n; return n
                }
            }
            sink = object : OutputStream() {
                override fun write(b: Int) = write(byteArrayOf(b.toByte()), 0, 1)
                override fun write(b: ByteArray, off: Int, len: Int) { var p = off; while (p < off + len) { val n = minOf(16_384, off + len - p); writeFrame(2, b.copyOfRange(p, p + n)); p += n } }
                override fun flush() = tls.outputStream.flush()
            }
        }
        private fun writeFrame(opcode: Int, payload: ByteArray) {
            val out = tls.outputStream; val mask = ByteArray(4).also(random::nextBytes)
            out.write(0x80 or opcode)
            when { payload.size < 126 -> out.write(0x80 or payload.size); payload.size <= 65535 -> { out.write(0x80 or 126); out.write(payload.size ushr 8); out.write(payload.size) }; else -> { out.write(0x80 or 127); for (i in 7 downTo 0) out.write((payload.size.toLong() ushr (8 * i)).toInt()) } }
            out.write(mask); val masked = ByteArray(payload.size) { i -> (payload[i].toInt() xor mask[i % 4].toInt()).toByte() }; out.write(masked); out.flush()
        }
        override fun getInputStream(): InputStream = source
        override fun getOutputStream(): OutputStream = sink
        override fun isConnected(): Boolean = tls.isConnected && !closed
        override fun close() { closed = true; runCatching { tls.close() } }
        override fun setSoTimeout(timeout: Int) { tls.soTimeout = timeout }
        override fun getSoTimeout(): Int = tls.soTimeout
        override fun setTcpNoDelay(on: Boolean) { tls.tcpNoDelay = on }
        override fun getTcpNoDelay(): Boolean = tls.tcpNoDelay
        override fun setKeepAlive(on: Boolean) { tls.keepAlive = on }
        override fun getKeepAlive(): Boolean = tls.keepAlive
    }
}
