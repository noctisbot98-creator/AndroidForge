DARK SURF ADMIN — SOURCE ANDROID V8 / 0.3.0

L'application ADMIN est une variante Android séparée (flavor admin) de la coque WebView DARK SURF.
Elle ouvre le portail V8 en HTTPS. Les écrans de configuration globale (Protocoles VPN) sont servis
par le serveur V8 dans SERVER_V8/src/portal.js : une fois le serveur mis à jour, l'écran apparaît
dans l'application ADMIN après connexion avec le compte administrateur. Le vendeur n'a pas accès
à ces fonctions : le serveur contrôle le rôle côté backend.

Compilation dans Android Studio / AndroidForge :
  ./gradlew assembleAdminRelease

Le projet contient également le flavor sellerRelease pour DARK SURF PRO. Pour compiler les deux :
  ./gradlew assembleAdminRelease assembleSellerRelease

Avant compilation, vérifier dans app/build.gradle.kts :
- PORTAL_URL : URL HTTPS réelle du portail DARK SURF V8 (déjà préremplie avec le domaine de cette installation).
- ACTIVATION_PUBLIC_KEY : remplacer REPLACE_WITH_PUBLIC_KEY_B64 par la clé publique produite par tools/activation.js.
- SUPPORT_WHATSAPP : numéro de support au format international sans +.

Version Android : versionCode 2, versionName 0.3.0.
L'application ADMIN possède son identifiant de package distinct via le suffixe .admin et ses ressources d'icône dédiées.
Aucun APK n'est fourni : ce dossier contient les sources à compiler dans AndroidForge/Android Studio.
