plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.seller"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.seller"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.3.0"

        // ---- À RENSEIGNER ----
        // Adresse HTTPS de TON portail vendeur (l'appli n'autorise que cet hôte).
        buildConfigField("String", "PORTAL_URL", "\"https://15-235-111-58.sslip.io/\"")
        // Clé PUBLIQUE de signature des codes (contenu de seller-public.b64, généré par tools/activation.js keygen).
        buildConfigField("String", "ACTIVATION_PUBLIC_KEY", "\"REPLACE_WITH_PUBLIC_KEY_B64\"")
        // Numéro WhatsApp qui reçoit les demandes d'accès, format international sans + (ex. 2376XXXXXXXX).
        buildConfigField("String", "SUPPORT_WHATSAPP", "\"237621862134\"")
    }

    // Deux applications à partir du même code : vendeur (PRO) et administrateur (ADMIN). Le portail décide de ce que chacun voit
    // selon le compte connecté ; l'APK admin est simplement une installation séparée, à ne donner qu'à toi.
    flavorDimensions += "role"
    productFlavors {
        create("seller") {
            dimension = "role"
            resValue("string", "app_name", "DARK_SURF PRO")
            buildConfigField("String", "BADGE", "\"PRO\"")
        }
        create("admin") {
            dimension = "role"
            applicationIdSuffix = ".admin"
            versionNameSuffix = "-admin"
            resValue("string", "app_name", "DARK_SURF ADMIN")
            buildConfigField("String", "BADGE", "\"ADMIN\"")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    buildFeatures { buildConfig = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
}
