package com.example.seller

import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Environment
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * DARK_SURF PRO / ADMIN — application vendeur et administrateur (même code, deux variantes).
 * Coquille WebView autour de TON portail revendeur, verrouillée par un code d'activation
 * signé et lié au téléphone. Aucun identifiant n'est écrit dans le code : le revendeur saisit
 * son login une fois, il est stocké chiffré (AndroidKeyStore).
 */
class MainActivity : ComponentActivity() {
    private val portalUrl = BuildConfig.PORTAL_URL
    private val portalHost = Uri.parse(BuildConfig.PORTAL_URL).host?.lowercase(Locale.ROOT).orEmpty()

    private lateinit var prefs: SharedPreferences
    private lateinit var vault: SecureStore
    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var progress: ProgressBar
    private lateinit var offlineBanner: TextView
    private lateinit var errorPanel: View
    private lateinit var portalFrame: View
    private lateinit var activationPanel: View
    private lateinit var deviceCode: String

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var lastError = "Aucune erreur enregistrée"
    private var loginAttempts = 0
    private var promptVisible = false
    private var online = true
    private var homeLoaded = false
    private var expiresAt = 0L
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCallback = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("access", Context.MODE_PRIVATE)
        UiPrefs.dark = prefs.getBoolean("dark", true)
        UiPrefs.french = prefs.getBoolean("fr", true)
        vault = SecureStore(this, "portal.bin")
        deviceCode = Activation.deviceCode(this)
        window.setBackgroundDrawable(ColorDrawable(Ds.BG))
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

        root = FrameLayout(this).apply { setBackgroundColor(Ds.BG) }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        setContentView(root)

        portalFrame = buildPortal()
        activationPanel = buildActivationPanel()
        root.addView(portalFrame)
        root.addView(activationPanel)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (portalFrame.visibility == View.VISIBLE && web.canGoBack()) web.goBack()
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })
        registerConnectivity()
        refreshGate(first = true)
    }

    // ------------------------------------------------------------ activation

    /** Revalide le code stocké (signature + téléphone + expiration) à chaque ouverture. */
    private fun refreshGate(first: Boolean = false) {
        // Sans clé de signature configurée, pas de code d'activation : le compte vendeur (identifiant + mot de passe créés par l'admin) suffit.
        if (BuildConfig.ACTIVATION_PUBLIC_KEY.startsWith("REPLACE")) {
            expiresAt = 0
            activationPanel.visibility = View.GONE
            portalFrame.visibility = View.VISIBLE
            if (first || !homeLoaded) loadHome()
            return
        }
        val stored = prefs.getString("signed_activation", null)
        val r = stored?.let { Activation.verify(it, deviceCode) }
        if (r is Activation.Result.Valid) {
            expiresAt = r.expiresAt
            activationPanel.visibility = View.GONE
            portalFrame.visibility = View.VISIBLE
            if (first || !homeLoaded) loadHome()
        } else {
            if (r is Activation.Result.Invalid) prefs.edit().remove("signed_activation").apply()
            activationPanel.visibility = View.VISIBLE
            portalFrame.visibility = View.GONE
        }
    }

    private fun buildActivationPanel(): View {
        val input = EditText(this).apply {
            hint = "Colle ton code d'activation"; setHintTextColor(Ds.MUTED)
            setTextColor(Ds.GREEN); typeface = Ds.MONO; textSize = 13f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            minLines = 3; maxLines = 5; gravity = Gravity.TOP
            background = rect(Ds.SURFACE, 16f, Ds.LINE, 1); setPadding(16.dp, 14.dp, 16.dp, 14.dp)
        }
        val message = tv("", 13f, Ds.DANGER, Ds.BODY).apply { gravity = Gravity.CENTER }

        val content = col(28).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            addView(LogoView(context), lin(84.dp, 84.dp, 24))
            addView(tv("DARK_SURF", 30f, Ds.TEXT, Ds.BLACK, 0.08f), lin(WRAP, WRAP, 12))
            addView(tv(BuildConfig.BADGE, 12f, Ds.BG, Ds.DISPLAY, 0.3f).apply {
                background = gradient(8f); setPadding(12.dp, 3.dp, 12.dp, 3.dp)
            }, lin(WRAP, WRAP, 6))
            addView(tv("Un code d'activation personnel est requis pour utiliser cette application.", 15f, Ds.MUTED, Ds.ACCENT).apply {
                gravity = Gravity.CENTER
            }, lin(MATCH, WRAP, 22))

            addView(overline("Identifiant de ce téléphone"), lin(WRAP, WRAP, 26))
            addView(tv(deviceCode, 18f, Ds.YELLOW, Ds.MONO, 0.06f).apply {
                gravity = Gravity.CENTER; background = rect(Ds.SURFACE2, 14f); setPadding(12.dp, 14.dp, 12.dp, 14.dp)
            }, lin(MATCH, WRAP, 8))
            addView(ghostButton("Copier l'identifiant") { copy("Identifiant", deviceCode) }, lin(MATCH, WRAP, 10))

            addView(input, lin(MATCH, WRAP, 20))
            addView(primaryButton("Activer l'application") {
                val code = input.text.toString().trim()
                if (code.isEmpty()) { message.text = "Saisis ton code d'activation."; return@primaryButton }
                when (val r = Activation.verify(code, deviceCode)) {
                    is Activation.Result.Valid -> {
                        prefs.edit().putString("signed_activation", code).apply()
                        message.text = ""; toast("Activation réussie"); refreshGate(first = true)
                    }
                    is Activation.Result.Invalid -> message.text = r.reason
                }
            }, lin(MATCH, WRAP, 14))
            addView(ghostButton("Demander un accès sur WhatsApp") {
                val text = "Bonjour, je souhaite obtenir un accès DARK_SURF ${BuildConfig.BADGE}. Identifiant de mon téléphone : $deviceCode"
                openExternal(Uri.parse("https://wa.me/${BuildConfig.SUPPORT_WHATSAPP}?text=" + Uri.encode(text)))
            }, lin(MATCH, WRAP, 10))
            addView(message, lin(MATCH, WRAP, 14))
            addView(tv("Un code est lié à cet identifiant. Ne le partage pas.", 12f, Ds.MUTED, Ds.ACCENT).apply {
                gravity = Gravity.CENTER
            }, lin(MATCH, WRAP, 10))
        }
        return android.widget.ScrollView(this).apply { setBackgroundColor(Ds.BG); isFillViewport = true; addView(content) }
    }

    // ---------------------------------------------------------------- portail

    private fun buildPortal(): View {
        web = WebView(this).apply { setBackgroundColor(Ds.BG) }
        configureWebView()

        swipe = SwipeRefreshLayout(this).apply {
            setColorSchemeColors(Ds.GREEN, Ds.YELLOW); setProgressBackgroundColorSchemeColor(Ds.SURFACE2)
            setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }
            setOnRefreshListener { web.reload() }
            addView(web, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(Ds.GREEN); visibility = View.GONE
        }
        offlineBanner = tv("Hors ligne — vérifie ta connexion", 12f, Ds.BG, Ds.DISPLAY, 0.08f).apply {
            gravity = Gravity.CENTER; setBackgroundColor(Ds.YELLOW); setPadding(0, 6.dp, 0, 6.dp); visibility = View.GONE
        }
        errorPanel = col(28).apply {
            gravity = Gravity.CENTER; setBackgroundColor(Ds.BG); visibility = View.GONE
            addView(tv("Portail injoignable", 22f, Ds.TEXT, Ds.DISPLAY))
            addView(tv("Vérifie ta connexion Internet, puis réessaie.", 15f, Ds.MUTED, Ds.ACCENT), lin(WRAP, WRAP, 6))
            addView(primaryButton("Réessayer") { errorPanel.visibility = View.GONE; loadHome() }, lin(220.dp, WRAP, 20))
        }

        val top = row().apply {
            setBackgroundColor(Ds.SURFACE); setPadding(16.dp, 10.dp, 12.dp, 10.dp)
            addView(LogoView(context), lin(30.dp, 30.dp))
            addView(tv("DARK_SURF", 16f, Ds.TEXT, Ds.BLACK, 0.1f), lin(WRAP, WRAP).apply { leftMargin = 10.dp })
            addView(tv(BuildConfig.BADGE, 10f, Ds.BG, Ds.DISPLAY, 0.2f).apply {
                background = gradient(8f); setPadding(8.dp, 2.dp, 8.dp, 2.dp)
            }, lin(WRAP, WRAP).apply { leftMargin = 8.dp })
            addView(View(context), lin(0, 1, 0, 1f))
            addView(tv(if (UiPrefs.french) "OUTILS" else "TOOLS", 12f, Ds.GREEN, Ds.DISPLAY, 0.14f).apply {
                background = rect(0, 12f, Ds.GREEN, 1); setPadding(14.dp, 8.dp, 14.dp, 8.dp)
                setOnClickListener { showTools() }
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(top, lin())
            addView(offlineBanner, lin())
            addView(progress, lin(MATCH, 3.dp))
            addView(FrameLayout(context).apply {
                addView(swipe, FrameLayout.LayoutParams(MATCH, MATCH))
                addView(errorPanel, FrameLayout.LayoutParams(MATCH, MATCH))
            }, lin(MATCH, 0, 0, 1f))
        }
    }

    private fun configureWebView() {
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            safeBrowsingEnabled = true
            builtInZoomControls = false; displayZoomControls = false; setSupportZoom(false)
            useWideViewPort = true; loadWithOverviewMode = true
        }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(web, false) }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                return when {
                    isInternal(u) -> false                                  // reste dans l'appli
                    u.scheme in setOf("https", "http", "mailto", "tel") -> { openExternal(u); true }
                    else -> true                                            // javascript:, file:, intent: … bloqués
                }
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) { errorPanel.visibility = View.GONE }

            override fun onPageFinished(view: WebView, url: String) {
                swipe.isRefreshing = false
                if (isInternal(Uri.parse(url))) maybeAutoLogin()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (!request.isForMainFrame) return
                lastError = "Erreur réseau : ${error.description} (${error.errorCode})"
                swipe.isRefreshing = false
                errorPanel.visibility = View.VISIBLE
            }

            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                handler.cancel()                                           // jamais de « continuer quand même »
                lastError = "Certificat du portail refusé (code ${error.primaryError})"
                errorPanel.visibility = View.VISIBLE
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }

            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try { filePicker.launch(params.createIntent()); true } catch (e: ActivityNotFoundException) {
                    fileCallback = null; cb.onReceiveValue(null); toast("Aucun sélecteur de fichiers disponible"); false
                }
            }
        }

        web.setDownloadListener { url, ua, cd, mime, _ -> startDownload(url, ua, cd, mime) }
    }

    private fun isInternal(u: Uri) = u.scheme == "https" && u.host?.lowercase(Locale.ROOT) == portalHost

    private fun loadHome() {
        if (portalHost.isEmpty() || !portalUrl.startsWith("https://")) {
            lastError = "PORTAL_URL doit être une adresse HTTPS valide"; errorPanel.visibility = View.VISIBLE; return
        }
        homeLoaded = true
        web.loadUrl(portalUrl)
    }

    // ------------------------------------------------------ connexion revendeur

    /** Si la page affiche le formulaire de connexion (#login, #password, #form), le remplit. */
    private fun maybeAutoLogin() {
        web.evaluateJavascript(
            "(function(){return !!(document.getElementById('login')&&document.getElementById('password')&&document.getElementById('form'))})()"
        ) { r ->
            if (r != "true") { loginAttempts = 0; return@evaluateJavascript }   // déjà connecté
            val c = readCredentials()
            when {
                c == null -> promptCredentials()
                loginAttempts >= 2 -> {                                           // évite les boucles / blocages de compte
                    lastError = "Connexion automatique refusée 2 fois : vérifie l'identifiant (Outils)"
                }
                else -> {
                    loginAttempts++
                    val js = "(function(u,p){var l=document.getElementById('login'),w=document.getElementById('password'),f=document.getElementById('form');" +
                        "var s=function(e,v){Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(e,v);" +
                        "e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));};" +
                        "s(l,u);s(w,p);if(f.requestSubmit){f.requestSubmit()}else{f.submit()}})(" +
                        JSONObject.quote(c.first) + "," + JSONObject.quote(c.second) + ")"
                    web.evaluateJavascript(js, null)
                }
            }
        }
    }

    private fun readCredentials(): Pair<String, String>? = vault.read()?.let {
        runCatching { JSONObject(it).let { j -> j.getString("l") to j.getString("p") } }.getOrNull()
    }?.takeIf { it.first.isNotBlank() && it.second.isNotBlank() }

    private fun promptCredentials() {
        if (promptVisible) return
        promptVisible = true
        val login = EditText(this).apply { hint = "Identifiant"; setSingleLine(true) }
        val pass = EditText(this).apply {
            hint = "Mot de passe"; setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val box = col(20).apply { addView(login); addView(pass) }
        val dialog = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Connexion")
            .setMessage("Enregistré chiffré sur ce téléphone, jamais dans l'application.")
            .setView(box)
            .setNegativeButton("Plus tard", null)
            .setPositiveButton("Enregistrer", null)
            .create()
        dialog.setOnDismissListener { promptVisible = false }
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val l = login.text.toString().trim(); val p = pass.text.toString()
                if (l.isEmpty() || p.isEmpty()) { toast("Renseigne les deux champs"); return@setOnClickListener }
                vault.write(JSONObject().put("l", l).put("p", p).toString())
                loginAttempts = 0; dialog.dismiss(); web.reload()
            }
        }
        dialog.show()
    }

    // ----------------------------------------------------------------- outils

    private fun showTools() {
        val items = arrayOf(
            if (UiPrefs.french) "Préférences (thème / langue)" else "Preferences (theme / language)",
            if (UiPrefs.french) "Actualiser" else "Refresh",
            if (UiPrefs.french) "Accueil du portail" else "Portal home",
            if (UiPrefs.french) "Copier mon identifiant" else "Copy my device ID",
            if (UiPrefs.french) "Diagnostic" else "Diagnostics",
            if (UiPrefs.french) "Changer l'identifiant" else "Change login",
            if (UiPrefs.french) "Se déconnecter du portail" else "Sign out of portal",
        )
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setTitle("Outils").setItems(items) { _, i ->
            when (i) {
                0 -> showPreferences()
                1 -> web.reload()
                2 -> loadHome()
                3 -> copy(if (UiPrefs.french) "Identifiant" else "Device ID", deviceCode)
                4 -> showDiagnostics()
                5 -> { vault.clear(); loginAttempts = 0; promptCredentials() }
                6 -> {
                    CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush()
                    web.clearCache(true); loginAttempts = 0; loadHome()
                }
            }
        }.show()
    }

    private fun showPreferences() {
        val choices = arrayOf(
            if (UiPrefs.french) "Mode sombre" else "Dark mode",
            if (UiPrefs.french) "Mode clair" else "Light mode",
            "Français", "English"
        )
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(if (UiPrefs.french) "Préférences" else "Preferences")
            .setItems(choices) { _, which ->
                when (which) {
                    0, 1 -> { UiPrefs.dark = which == 0; prefs.edit().putBoolean("dark", UiPrefs.dark).apply(); recreate() }
                    2, 3 -> {
                        UiPrefs.french = which == 2
                        prefs.edit().putBoolean("fr", UiPrefs.french).apply()
                        // Le portail doit lui-même prendre en charge ?lang=fr/en pour traduire son contenu.
                        web.evaluateJavascript("try{localStorage.setItem('darksurf-language','${if (UiPrefs.french) "fr" else "en"}')}catch(e){}", null)
                        web.reload()
                    }
                }
            }.show()
    }

    private fun showDiagnostics() {
        val exp = if (expiresAt == 0L) "illimitée" else SimpleDateFormat("d MMM yyyy", Locale.FRANCE).format(Date(expiresAt * 1000))
        val msg = "Version : ${BuildConfig.VERSION_NAME}\nIdentifiant : $deviceCode\nActivation : $exp\n" +
            "Réseau : ${if (online) "en ligne" else "hors ligne"}\nPage : ${web.url ?: "—"}\n" +
            "Identifiant : ${if (readCredentials() != null) "enregistré" else "absent"}\nDernière erreur : $lastError"
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setTitle("Diagnostic").setMessage(msg)
            .setPositiveButton("Copier") { _, _ -> copy("Diagnostic", msg) }.setNegativeButton("Fermer", null).show()
    }

    // ---------------------------------------------------------------- système

    private fun registerConnectivity() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        online = cm.activeNetwork != null
        offlineBanner.visibility = if (online) View.GONE else View.VISIBLE
        netCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { runOnUiThread { online = true; offlineBanner.visibility = View.GONE } }
            override fun onLost(network: Network) { runOnUiThread { online = false; offlineBanner.visibility = View.VISIBLE } }
        }
        cm.registerDefaultNetworkCallback(netCallback!!)
    }

    private fun startDownload(url: String, ua: String?, cd: String?, mime: String?) {
        val uri = Uri.parse(url)
        if (!isInternal(uri)) { toast("Téléchargement refusé (hôte non autorisé)"); return }
        val name = URLUtil.guessFileName(url, cd, mime)
        val req = DownloadManager.Request(uri)
            .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
            .addRequestHeader("User-Agent", ua ?: "")
            .setTitle(name)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
        if (!mime.isNullOrBlank()) req.setMimeType(mime)
        (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
        toast("Téléchargement : $name")
    }

    private fun openExternal(uri: Uri) {
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (e: ActivityNotFoundException) { toast("Aucune application pour ouvrir ce lien") }
    }

    private fun copy(label: String, text: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, text))
        toast("Copié")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onResume() { super.onResume(); web.onResume(); if (::activationPanel.isInitialized) refreshGate() }
    override fun onPause() { web.onPause(); super.onPause() }

    override fun onDestroy() {
        netCallback?.let { runCatching { (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) } }
        fileCallback?.onReceiveValue(null)
        web.destroy()
        super.onDestroy()
    }
}
