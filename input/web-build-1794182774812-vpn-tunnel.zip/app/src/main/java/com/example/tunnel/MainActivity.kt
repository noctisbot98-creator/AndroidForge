package com.example.tunnel

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.ColorDrawable
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Conn { IDLE, CONNECTING, CONNECTED, DISCONNECTING }

/**
 * DARK_SURF — même charpente que Geny : barre du bas à 5 emplacements
 * (Accueil · Activité · bouton central · Réglages · Aide), gros bouton de connexion,
 * carte de forfait, FR/EN. Habillage propre : vert/jaune sur fond sombre.
 */
class MainActivity : ComponentActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var tm: TunnelManager
    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout

    private var tab = 0                 // 0 accueil · 1 activité · 2 réglages · 3 aide
    private var conn = Conn.IDLE
    private var error: String? = null
    private var rx = 0L
    private var tx = 0L
    private var prefillCode = ""
    private var update: UpdateInfo? = null
    private var updateMsg: String? = null
    private var updateStatus: String? = null
    private var updating = false

    // vues mises à jour chaque seconde
    private var timerTv: TextView? = null
    private var rxTv: TextView? = null
    private var txTv: TextView? = null

    private val ticker = object : Runnable {
        override fun run() { tick(); handler.postDelayed(this, 1000) }
    }

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun askNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 && !Notifier.canNotify(this) && !prefs.getBoolean("notif_asked", false)) {
            prefs.edit().putBoolean("notif_asked", true).apply()
            notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) doConnect() else { error = t("Autorisation VPN refusée.", "VPN permission denied."); render() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tm = TunnelManager.get(this)
        prefs = getSharedPreferences("ui", Context.MODE_PRIVATE)
        if (prefs.contains("fr")) Lang.fr = prefs.getBoolean("fr", Lang.fr)
        window.setBackgroundDrawable(ColorDrawable(Ds.BG))

        root = FrameLayout(this).apply { setBackgroundColor(Ds.BG); clipChildren = false }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        setContentView(root)

        handleIntent(intent)
        if (tm.isConnected()) conn = Conn.CONNECTED
        tm.onPlanChanged = { runOnUiThread { if (tab == 0 && tm.isEnrolled()) render() } }
        render()
        if (!prefs.getBoolean("rules", false)) showRules()
        askNotificationPermission()
        checkUpdate(manual = false)
    }

    override fun onResume() { super.onResume(); handler.post(ticker) }
    override fun onPause() { handler.removeCallbacks(ticker); super.onPause() }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
        render()
    }

    private fun handleIntent(i: Intent?) { i?.data?.getQueryParameter("code")?.let { prefillCode = it } }

    private fun t(f: String, e: String) = Lang.t(f, e)

    // ------------------------------------------------------------------ rendu

    private fun render() {
        root.removeAllViews()
        timerTv = null; rxTv = null; txTv = null
        if (!tm.isEnrolled()) { root.addView(activationScreen()); return }

        val page = when (tab) { 0 -> homeScreen(); 1 -> activityScreen(); 2 -> settingsScreen(); else -> helpScreen() }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(page) }
        root.addView(col().apply {
            clipChildren = false
            addView(scroll, lin(MATCH, 0, weight = 1f))
            addView(bottomNav())
        })
    }

    private fun tick() {
        if (!tm.isEnrolled()) return
        if (conn == Conn.CONNECTED && !tm.isConnected()) {          // coupé par le système
            conn = Conn.IDLE
            error = when (tm.lastStop) {
                "expired" -> t("Votre forfait a expiré : le VPN s'est arrêté.", "Your plan has expired: the VPN stopped.")
                "quota_exceeded" -> t("Données épuisées : le VPN s'est arrêté.", "Data used up: the VPN stopped.")
                "revoked", "disabled" -> t("Cette clé n'est plus valable.", "This key is no longer valid.")
                else -> t("Connexion interrompue.", "Connection interrupted.")
            }
            render(); return
        }
        if (conn != Conn.CONNECTED) return
        tm.connectedAt.takeIf { it > 0 }?.let { timerTv?.text = fmtDuration(System.currentTimeMillis() - it) }
        scope.launch {
            val (r, x) = tm.stats(); rx = r; tx = x
            rxTv?.text = fmtBytes(r); txTv?.text = fmtBytes(x)
        }
    }

    // ------------------------------------------------------------ activation

    private fun activationScreen(): View {
        var busy = false
        val status = tv(error ?: "", 13f, Ds.DANGER, Ds.BODY).apply { gravity = Gravity.CENTER }
        val input = EditText(this).apply {
            hint = "TUN-••••••••••••••••••••••••••••••••"; setHintTextColor(Ds.MUTED)
            setText(prefillCode); setTextColor(Ds.GREEN); typeface = Ds.MONO; textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true); gravity = Gravity.CENTER
            background = rect(Ds.SURFACE, 16f, Ds.LINE, 1); setPadding(16.dp, 16.dp, 16.dp, 16.dp)
        }
        val button = primaryButton(t("Activer", "Activate")) {
            if (busy) return@primaryButton
            busy = true; status.setTextColor(Ds.MUTED); status.text = t("Activation…", "Activating…")
            scope.launch {
                try {
                    tm.activate(input.text.toString()); error = null; prefillCode = ""; busy = false; render()
                } catch (e: CancellationException) { throw e
                } catch (e: ApiException) {
                    busy = false; status.setTextColor(Ds.DANGER); status.text = apiMessage(e)
                } catch (e: Exception) {
                    busy = false; status.setTextColor(Ds.DANGER)
                    status.text = t("Activation impossible : ", "Could not activate: ") + (e.message ?: "")
                }
            }
        }
        return col(28).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            addView(View(context), lin(MATCH, 40.dp))
            addView(LogoView(context), lin(96.dp, 96.dp))
            addView(tv("DARK_SURF", 34f, Ds.TEXT, Ds.BLACK, 0.08f), lin(WRAP, WRAP, 14))
            addView(tv(t("Surfe dans l'ombre.", "Surf in the dark."), 16f, Ds.YELLOW, Ds.ACCENT), lin(WRAP, WRAP, 4))
            addView(overline(t("Code d'activation", "Activation code")), lin(WRAP, WRAP, 44))
            addView(input, lin(MATCH, WRAP, 10))
            addView(button, lin(MATCH, WRAP, 16))
            addView(status, lin(MATCH, WRAP, 14))
        }
    }

    // ----------------------------------------------------------------- accueil

    private fun orbState() = when (conn) { Conn.CONNECTED -> Orb.ON; Conn.IDLE -> Orb.IDLE; else -> Orb.BUSY }

    private fun homeScreen(): View = col(20).apply {
        gravity = Gravity.CENTER_HORIZONTAL
        addView(topBar(), lin())
        update?.let { addView(updateCard(it), lin(MATCH, WRAP, 12)) }

        addView(OrbView(context).apply { state = orbState(); setOnClickListener { toggle() } }, lin(260.dp, 260.dp, 6))

        val title = when (conn) {
            Conn.IDLE -> t("Prêt à se connecter", "Ready to connect")
            Conn.CONNECTING -> t("Connexion en cours", "Connecting")
            Conn.CONNECTED -> t("Vous êtes connecté", "You are connected")
            Conn.DISCONNECTING -> t("Déconnexion", "Disconnecting")
        }
        val sub = when (conn) {
            Conn.IDLE -> t("Un geste pour activer votre forfait.", "One tap to activate your plan.")
            Conn.CONNECTING -> t("Nous préparons votre connexion…", "We are preparing your connection…")
            Conn.CONNECTED -> t("Votre forfait est actif.", "Your plan is active.")
            Conn.DISCONNECTING -> t("À bientôt.", "See you soon.")
        }
        addView(tv(title, 28f, Ds.TEXT, Ds.DISPLAY, 0.04f), lin(WRAP, WRAP, 0))
        addView(tv(sub, 16f, Ds.MUTED, Ds.ACCENT), lin(WRAP, WRAP, 4))
        error?.let { addView(tv(it, 13f, Ds.DANGER, Ds.BODY).apply { gravity = Gravity.CENTER }, lin(MATCH, WRAP, 10)) }

        if (conn == Conn.CONNECTED) {
            val since = tm.connectedAt
            if (since > 0) {
                val timer = tv(fmtDuration(System.currentTimeMillis() - since), 24f, Ds.YELLOW, Ds.MONO, 0.1f)
                timerTv = timer
                addView(timer, lin(WRAP, WRAP, 14))
            }
            val stats = row()
            rxTv = tv(fmtBytes(rx), 18f, Ds.GREEN, Ds.MONO)
            txTv = tv(fmtBytes(tx), 18f, Ds.YELLOW, Ds.MONO)
            stats.addView(statCard("↓ " + t("Reçu", "Down"), rxTv!!), lin(0, WRAP, 0, 1f))
            stats.addView(View(context), lin(12.dp, 1))
            stats.addView(statCard("↑ " + t("Envoyé", "Up"), txTv!!), lin(0, WRAP, 0, 1f))
            addView(stats, lin(MATCH, WRAP, 16))
        }
        addView(planCard(), lin(MATCH, WRAP, 16))
    }

    private fun topBar() = row().apply {
        addView(LogoView(context), lin(34.dp, 34.dp))
        addView(tv("DARK_SURF", 20f, Ds.TEXT, Ds.BLACK, 0.1f), lin(WRAP, WRAP).apply { leftMargin = 10.dp })
    }

    private fun statCard(label: String, value: TextView) = card().apply {
        addView(overline(label))
        addView(value, lin(WRAP, WRAP, 6))
    }

    private fun planCard(): View = card().apply {
        val plan = tm.plan()
        addView(overline(t("Forfait", "Plan")))
        if (plan == null) {
            addView(tv(t("Connectez-vous pour afficher votre forfait.", "Connect to see your plan."), 14f, Ds.MUTED), lin(WRAP, WRAP, 8))
            return@apply
        }
        addView(tv(plan.name, 22f, Ds.TEXT, Ds.DISPLAY), lin(WRAP, WRAP, 6))
        val q = plan.quotaBytes
        if (q == null) {
            addView(tv(t("Illimité", "Unlimited"), 15f, Ds.GREEN, Ds.MONO), lin(WRAP, WRAP, 10))
        } else {
            val used = if (conn == Conn.CONNECTED) tm.liveUsed(plan, rx + tx) else plan.usedBytes
            addView(BarView(context, used.toFloat() / q), lin(MATCH, 8.dp, 12))
            addView(
                tv(t("${fmtBytes((q - used).coerceAtLeast(0))} restants sur ${fmtBytes(q)}",
                    "${fmtBytes((q - used).coerceAtLeast(0))} left of ${fmtBytes(q)}"), 14f, Ds.TEXT, Ds.MONO),
                lin(WRAP, WRAP, 10)
            )
        }
        if (plan.expiresAt > 0)
            addView(tv(t("Expire le ", "Expires ") + fmtDate(plan.expiresAt * 1000), 14f, Ds.MUTED, Ds.ACCENT), lin(WRAP, WRAP, 6))
    }

    // ---------------------------------------------------------------- activité

    private fun activityScreen(): View = col(20).apply {
        addView(tv(t("Activité", "Activity"), 30f, Ds.TEXT, Ds.DISPLAY, 0.04f))
        addView(tv(t("Vos dernières sessions.", "Your latest sessions."), 15f, Ds.MUTED, Ds.ACCENT), lin(WRAP, WRAP, 2))
        val h = tm.history()
        if (h.isEmpty()) {
            addView(card().apply {
                addView(tv(t("Aucune session pour le moment.", "No sessions yet."), 15f, Ds.MUTED))
            }, lin(MATCH, WRAP, 20))
        }
        h.forEach { e ->
            addView(card().apply {
                addView(row().apply {
                    addView(tv(fmtDate(e.start, "d MMM · HH:mm"), 15f, Ds.TEXT, Ds.DISPLAY), lin(0, WRAP, 0, 1f))
                    addView(tv(fmtDuration(e.end - e.start), 15f, Ds.YELLOW, Ds.MONO))
                })
                addView(row().apply {
                    addView(tv("↓ ${fmtBytes(e.rx)}", 13f, Ds.GREEN, Ds.MONO), lin(0, WRAP, 0, 1f))
                    addView(tv("↑ ${fmtBytes(e.tx)}", 13f, Ds.YELLOW, Ds.MONO))
                }, lin(MATCH, WRAP, 8))
            }, lin(MATCH, WRAP, 12))
        }
    }

    // ---------------------------------------------------------------- réglages

    private fun settingsScreen(): View = col(20).apply {
        addView(tv(t("Réglages", "Settings"), 30f, Ds.TEXT, Ds.DISPLAY, 0.04f))

        addView(overline(t("Langue", "Language")), lin(WRAP, WRAP, 24))
        addView(row().apply {
            listOf(true to "Français", false to "English").forEach { (fr, name) ->
                val on = Lang.fr == fr
                addView(tv(name.uppercase(), 13f, if (on) Ds.BG else Ds.MUTED, Ds.DISPLAY, 0.12f).apply {
                    gravity = Gravity.CENTER; minHeight = 44.dp
                    background = if (on) gradient(14f) else rect(0, 14f, Ds.LINE, 1)
                    setOnClickListener { Lang.fr = fr; prefs.edit().putBoolean("fr", fr).apply(); render() }
                }, lin(0, WRAP, 0, 1f).apply { rightMargin = 8.dp })
            }
        }, lin(MATCH, WRAP, 10))

        addView(overline(t("Appareil", "Device")), lin(WRAP, WRAP, 28))
        addView(card().apply {
            addView(tv(tm.deviceId()?.take(13)?.plus("…") ?: "—", 15f, Ds.GREEN, Ds.MONO))
            addView(tv(t("Identité protégée dans le coffre-fort Android.", "Identity protected by the Android keystore."), 13f, Ds.MUTED, Ds.ACCENT), lin(WRAP, WRAP, 6))
        }, lin(MATCH, WRAP, 10))
        addView(ghostButton(t("Réinitialiser cet appareil", "Reset this device"), Ds.DANGER) {
            AlertDialog.Builder(context, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(t("Réinitialiser ?", "Reset?"))
                .setMessage(t("Le code d'activation sera à ressaisir.", "You will need to enter your activation code again."))
                .setNegativeButton(t("Annuler", "Cancel"), null)
                .setPositiveButton(t("Réinitialiser", "Reset")) { _, _ ->
                    scope.launch { tm.reset(); conn = Conn.IDLE; tab = 0; error = null; render() }
                }.show()
        }, lin(MATCH, WRAP, 12))

        addView(overline(t("Application", "App")), lin(WRAP, WRAP, 28))
        addView(card().apply {
            addView(tv("v${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})", 15f, Ds.GREEN, Ds.MONO))
            updateMsg?.let { addView(tv(it, 13f, Ds.MUTED, Ds.ACCENT), lin(WRAP, WRAP, 6)) }
        }, lin(MATCH, WRAP, 10))
        addView(ghostButton(t("Vérifier les mises à jour", "Check for updates")) { checkUpdate(manual = true) }, lin(MATCH, WRAP, 12))

        addView(tv("DARK_SURF v${BuildConfig.VERSION_NAME}", 12f, Ds.MUTED, Ds.MONO).apply { gravity = Gravity.CENTER }, lin(MATCH, WRAP, 32))
    }

    // -------------------------------------------------------------------- aide

    private fun helpScreen(): View = col(20).apply {
        addView(tv(t("Aide", "Help"), 30f, Ds.TEXT, Ds.DISPLAY, 0.04f))
        addView(tv(t("Les réponses rapides.", "Quick answers."), 15f, Ds.MUTED, Ds.ACCENT), lin(WRAP, WRAP, 2))
        listOf(
            t("Comment activer mon forfait ?", "How do I activate my plan?") to
                t("Saisissez votre code TUN-… ou ouvrez le lien d'activation reçu.", "Enter your TUN-… code or open the activation link you received."),
            t("La connexion échoue.", "The connection fails.") to
                t("Vérifiez votre accès Internet, puis réessayez. Si le message parle d'interception, changez de réseau Wi-Fi.", "Check your Internet access and try again. If the message mentions interception, switch Wi-Fi network."),
            t("Limite d'appareils atteinte.", "Device limit reached.") to
                t("Ce code est déjà utilisé sur le nombre maximal d'appareils. Contactez le support.", "This code is already in use on the maximum number of devices. Contact support."),
            t("Mon forfait est épuisé.", "My plan is used up.") to
                t("Demandez à votre vendeur de recharger votre clé (la même), puis appuyez sur le bouton pour vous reconnecter.", "Ask your seller to top up your key (the same one), then tap the button to reconnect."),
        ).forEach { (q, a) ->
            addView(card().apply {
                addView(tv(q, 16f, Ds.TEXT, Ds.DISPLAY))
                addView(tv(a, 14f, Ds.MUTED, Ds.BODY), lin(WRAP, WRAP, 6))
            }, lin(MATCH, WRAP, 12))
        }
    }

    // --------------------------------------------------------------- navigation

    private fun bottomNav(): View {
        val bar = row().apply {
            setBackgroundColor(Ds.SURFACE); clipChildren = false; clipToPadding = false
            setPadding(0, 6.dp, 0, 6.dp)
        }
        val items = listOf(
            Triple("home", t("Accueil", "Home"), 0), Triple("activity", t("Activité", "Activity"), 1),
            Triple("", "", -1),
            Triple("settings", t("Réglages", "Settings"), 2), Triple("help", t("Aide", "Help"), 3),
        )
        items.forEach { (kind, label, idx) ->
            if (idx == -1) { bar.addView(centerButton(), lin(0, 58.dp, 0, 1f)); return@forEach }
            val sel = tab == idx
            bar.addView(col().apply {
                gravity = Gravity.CENTER
                val icon = IconView(context, kind).apply { tint = if (sel) Ds.GREEN else Ds.MUTED }
                addView(FrameLayout(context).apply {
                    if (sel) background = rect(Ds.SURFACE2, 14f)
                    addView(icon, FrameLayout.LayoutParams(22.dp, 22.dp, Gravity.CENTER))
                }, lin(54.dp, 30.dp))
                addView(tv(label, 11f, if (sel) Ds.TEXT else Ds.MUTED, Ds.DISPLAY, 0.04f), lin(WRAP, WRAP, 3))
                setOnClickListener { tab = idx; render() }
            }, lin(0, 58.dp, 0, 1f))
        }
        return bar
    }

    private fun centerButton(): View = col().apply {
        gravity = Gravity.CENTER_HORIZONTAL; clipChildren = false
        val badge = PowerBadge(context).apply { busy = conn == Conn.CONNECTING || conn == Conn.DISCONNECTING }
        addView(FrameLayout(context).apply {
            translationY = -14f.dp; clipChildren = false
            addView(badge, FrameLayout.LayoutParams(50.dp, 50.dp, Gravity.CENTER))
        }, lin(64.dp, 32.dp))
        addView(
            tv(if (conn == Conn.CONNECTED) t("Couper", "Stop") else t("Connexion", "Connect"), 11f, Ds.TEXT, Ds.DISPLAY, 0.04f).apply {
                gravity = Gravity.CENTER
            }, lin(WRAP, WRAP, 3)
        )
        setOnClickListener { toggle() }
    }

    // ------------------------------------------------------------- connexion

    private fun toggle() {
        when (conn) {
            Conn.IDLE -> {
                if (update?.required == true) {
                    error = t("Une mise à jour obligatoire est disponible.", "A required update is available."); render(); return
                }
                val i = VpnService.prepare(this); if (i != null) vpnPermission.launch(i) else doConnect()
            }
            Conn.CONNECTED -> doDisconnect()
            else -> Unit
        }
    }

    private fun doConnect() {
        conn = Conn.CONNECTING; error = null; render()
        scope.launch {
            try {
                tm.connect(); conn = Conn.CONNECTED; rx = 0; tx = 0
            } catch (e: CancellationException) { throw e
            } catch (e: ApiException) { conn = Conn.IDLE; error = apiMessage(e)
            } catch (e: Exception) { conn = Conn.IDLE; error = t("Connexion impossible : ", "Could not connect: ") + (e.message ?: "") }
            render()
        }
    }

    private fun doDisconnect() {
        conn = Conn.DISCONNECTING; render()
        scope.launch {
            runCatching { tm.disconnect() }
            conn = Conn.IDLE; render()
        }
    }

    private fun apiMessage(e: ApiException) = when (e.kind) {
        ApiError.Rejected -> if (e.code == "bad_code_format") t("Ce code n'a pas le bon format.", "This code is not in the right format.")
        else t("Le service a refusé la demande. Mettez l'application à jour.", "The service refused the request. Update the app.")
        ApiError.Unauthorized -> t("Appareil non reconnu. Réinitialisez-le dans les réglages.", "Device not recognised. Reset it in settings.")
        ApiError.Forbidden -> when (e.code) {
            "device_limit" -> t("Limite d'appareils atteinte.", "Device limit reached.")
            "invalid_code" -> t("Code invalide ou déjà utilisé.", "Invalid or already used code.")
            "plan_expired" -> t("Votre forfait a expiré. Demandez à votre vendeur de recharger votre clé.", "Your plan has expired. Ask your seller to top up your key.")
            "quota_exceeded" -> t("Données épuisées. Demandez à votre vendeur de recharger votre clé.", "Data used up. Ask your seller to top up your key.")
            else -> t("Accès refusé.", "Access denied.")
        }
        ApiError.RateLimited -> t("Trop de tentatives. Patientez quelques minutes.", "Too many attempts. Wait a few minutes.")
        ApiError.ServerBusy -> t("Service momentanément indisponible.", "Service temporarily unavailable.")
        ApiError.Unreachable -> t("Service injoignable. Vérifiez votre accès Internet.", "Cannot reach the service. Check your Internet access.")
        ApiError.Intercepted -> t("Connexion interceptée (certificat invalide). Changez de réseau.", "Connection intercepted (invalid certificate). Switch network.")
    }

    // ------------------------------------------------------------ mise à jour

    private fun checkUpdate(manual: Boolean) {
        val last = prefs.getLong("upd_check", 0)
        if (!manual && System.currentTimeMillis() - last < 6 * 3600_000L) return     // au plus toutes les 6 h
        if (manual) { updateMsg = t("Vérification…", "Checking…"); render() }
        scope.launch {
            try {
                val info = withContext(Dispatchers.IO) { Api().checkUpdate(BuildConfig.VERSION_CODE) }
                prefs.edit().putLong("upd_check", System.currentTimeMillis()).apply()
                update = info
                if (manual) updateMsg = if (info == null) t("Vous avez la dernière version.", "You have the latest version.")
                else t("Version ${info.versionName} disponible (page Accueil).", "Version ${info.versionName} available (Home tab).")
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) {
                if (manual) updateMsg = t("Vérification impossible pour le moment.", "Could not check right now.")
            }
            if (tm.isEnrolled()) render()      // ne pas reconstruire l'écran d'activation (saisie en cours)
        }
    }

    private fun updateCard(info: UpdateInfo): View = card().apply {
        background = rect(Ds.SURFACE2, 20f, Ds.YELLOW, 1)
        addView(overline(if (info.required) t("Mise à jour obligatoire", "Required update") else t("Mise à jour disponible", "Update available")))
        addView(tv("DARK_SURF ${info.versionName}", 20f, Ds.TEXT, Ds.DISPLAY), lin(WRAP, WRAP, 6))
        if (info.notes.isNotBlank()) addView(tv(info.notes, 14f, Ds.MUTED, Ds.ACCENT), lin(WRAP, WRAP, 4))
        val status = tv(updateStatus ?: "", 13f, Ds.YELLOW, Ds.MONO)
        addView(status, lin(WRAP, WRAP, 8))
        addView(primaryButton(t("Mettre à jour", "Update")) { startUpdate(info, status) }, lin(MATCH, WRAP, 12))
    }

    private fun startUpdate(info: UpdateInfo, status: TextView) {
        if (updating) return
        if (!Updater.canInstall(this)) {
            updateStatus = t("Autorise l'installation pour DARK_SURF, puis reviens ici.", "Allow installs for DARK_SURF, then come back.")
            status.text = updateStatus
            Updater.requestInstallPermission(this); return
        }
        updating = true
        scope.launch {
            try {
                val apk = withContext(Dispatchers.IO) {
                    Updater.download(this@MainActivity, info) { p ->
                        runOnUiThread { status.text = t("Téléchargement… $p %", "Downloading… $p%") }
                    }
                }
                status.text = t("Prêt à installer.", "Ready to install.")
                Updater.install(this@MainActivity, apk)
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) {
                updateStatus = updateError(e); status.text = updateStatus
            } finally { updating = false }
        }
    }

    private fun updateError(e: Exception) = when ((e as? Updater.UpdateException)?.reason) {
        "bad_checksum" -> t("Fichier corrompu : réessaie.", "Corrupted file: try again.")
        "bad_signature" -> t("Signature invalide : mise à jour refusée.", "Invalid signature: update refused.")
        "untrusted_url" -> t("Adresse de téléchargement non autorisée.", "Download address not allowed.")
        "bad_size" -> t("Fichier de taille inattendue : mise à jour refusée.", "Unexpected file size: update refused.")
        else -> t("Téléchargement impossible. Vérifie ta connexion.", "Download failed. Check your connection.")
    }

    private fun showRules() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(t("Bienvenue sur DARK_SURF", "Welcome to DARK_SURF"))
            .setMessage(
                t(
                    "Avant de commencer, lisez les règles d'utilisation :\n\n• Utilisez le service dans le respect de la loi.\n• Ne partagez pas votre code d'activation.\n• Un code est lié à un nombre limité d'appareils.",
                    "Before you start, please read the rules for using the service:\n\n• Use the service lawfully.\n• Do not share your activation code.\n• A code is tied to a limited number of devices."
                )
            )
            .setCancelable(false)
            .setPositiveButton(t("J'ai compris", "I understand")) { _, _ -> prefs.edit().putBoolean("rules", true).apply() }
            .show()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        tm.listener = null; tm.onPlanChanged = null
        scope.cancel()
        super.onDestroy()
    }
}
