package com.example.tunnel

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.SSLException

/** Erreurs métier, alignées sur docs/API.md. */
enum class ApiError { Rejected, Unauthorized, Forbidden, RateLimited, ServerBusy, Unreachable, Intercepted }

class ApiException(val kind: ApiError, val code: String? = null) : IOException("$kind ${code ?: ""}")

/** Profil WireGuard renvoyé par le serveur (la clé privée reste sur l'appareil). */
data class Profile(
    val address: String,        // ex. "10.8.0.2/32"
    val dns: String,            // ex. "1.1.1.1"
    val mtu: Int,
    val serverPublicKey: String,
    val endpoint: String,       // host:port UDP
    val allowedIps: String,     // ex. "0.0.0.0/0, ::/0"
    val keepalive: Int,
) {
    fun toJson() = JSONObject()
        .put("address", address).put("dns", dns).put("mtu", mtu)
        .put("server_public_key", serverPublicKey).put("endpoint", endpoint)
        .put("allowed_ips", allowedIps).put("keepalive", keepalive)

    companion object {
        fun fromJson(j: JSONObject) = Profile(
            address = j.getString("address"),
            dns = j.getString("dns"),
            mtu = j.optInt("mtu", 1280),
            serverPublicKey = j.getString("server_public_key"),
            endpoint = j.getString("endpoint"),
            allowedIps = j.optString("allowed_ips", "0.0.0.0/0, ::/0"),
            keepalive = j.optInt("keepalive", 25),
        )
    }
}

/** Forfait. quotaBytes == null -> illimité. */
data class Plan(val name: String, val quotaBytes: Long?, val usedBytes: Long, val expiresAt: Long) {
    fun toJson() = JSONObject().put("name", name).put("used_bytes", usedBytes).put("expires_at", expiresAt)
        .also { if (quotaBytes != null) it.put("quota_bytes", quotaBytes) }

    companion object {
        fun fromJson(j: JSONObject) = Plan(
            j.optString("name", "Plan"),
            if (j.isNull("quota_bytes") || !j.has("quota_bytes")) null else j.getLong("quota_bytes"),
            j.optLong("used_bytes"), j.optLong("expires_at"),
        )
    }
}

data class SessionResponse(val token: String, val expiresAt: Long, val profile: Profile, val plan: Plan?)

data class Notice(val id: Int, val title: String, val body: String)

/** État du forfait renvoyé par /status : active | expired | quota_exceeded | revoked | disabled. */
data class StatusResponse(val state: String, val now: Long, val plan: Plan, val notices: List<Notice>)

/** Version plus récente annoncée par le serveur. */
data class UpdateInfo(
    val versionCode: Int, val versionName: String, val url: String, val sha256: String,
    val size: Long, val notes: String, val required: Boolean,
)

class Api(private val base: String = BuildConfig.API_BASE) {

    fun enroll(code: String, wgPublicKey: String, label: String): String {
        val signature = DeviceIdentity.sign("Tunnel/activate/v1\n$code\n$wgPublicKey")
        val r = post(
            "enroll",
            JSONObject().put("code", code).put("signing_key", DeviceIdentity.publicKeyB64())
                .put("wg_key", wgPublicKey).put("label", label).put("signature", signature)
        )
        return r.getString("device_id")
    }

    fun session(deviceId: String, network: String): SessionResponse {
        val ch = post("challenge", JSONObject().put("device_id", deviceId))
        val challenge = ch.getString("challenge")
        val signature = DeviceIdentity.sign(ch.getString("message"))
        val r = post(
            "session",
            JSONObject().put("device_id", deviceId).put("challenge", challenge)
                .put("signature", signature).put("network", network)
        )
        return SessionResponse(
            token = r.getString("token"),
            expiresAt = r.getLong("expires_at"),
            profile = Profile.fromJson(r.getJSONObject("profile")),
            plan = r.optJSONObject("plan")?.let(Plan::fromJson),
        )
    }

    /** État du forfait + annonces, sans toucher au tunnel (même défi signé que la session). */
    fun status(deviceId: String, sinceNotice: Int): StatusResponse {
        val ch = post("challenge", JSONObject().put("device_id", deviceId))
        val signature = DeviceIdentity.sign(ch.getString("message"))
        val r = post(
            "status",
            JSONObject().put("device_id", deviceId).put("challenge", ch.getString("challenge"))
                .put("signature", signature).put("since_notice", sinceNotice)
        )
        val ns = r.optJSONArray("notices")
        val notices = List(ns?.length() ?: 0) { i -> ns!!.getJSONObject(i).let { Notice(it.getInt("id"), it.getString("title"), it.getString("body")) } }
        return StatusResponse(r.getString("state"), r.getLong("now"), Plan.fromJson(r.getJSONObject("plan")), notices.sortedBy { it.id })
    }

    /** null = à jour. */
    fun checkUpdate(currentVersionCode: Int): UpdateInfo? {
        val r = post("app/android", JSONObject().put("version_code", currentVersionCode))
        if (!r.optBoolean("update")) return null
        return UpdateInfo(
            r.getInt("version_code"), r.getString("version_name"), r.getString("url"), r.getString("sha256").lowercase(),
            r.optLong("size"), r.optString("notes"), r.optBoolean("required"),
        )
    }

    private fun post(path: String, body: JSONObject): JSONObject {
        val conn = URL(base + path).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 15_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val status = conn.responseCode
            val text = (if (status < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status in 200..299) return JSONObject(text)
            val code = runCatching { JSONObject(text).optString("error") }.getOrNull()?.ifEmpty { null }
            throw ApiException(
                when (status) {
                    401 -> ApiError.Unauthorized
                    403 -> ApiError.Forbidden
                    429 -> ApiError.RateLimited
                    in 500..599 -> ApiError.ServerBusy
                    else -> ApiError.Rejected
                }, code
            )
        } catch (e: ApiException) {
            throw e
        } catch (e: SSLException) {
            throw ApiException(ApiError.Intercepted)   // certificat invalide / interception TLS
        } catch (e: IOException) {
            throw ApiException(ApiError.Unreachable)
        } finally {
            conn.disconnect()
        }
    }
}
