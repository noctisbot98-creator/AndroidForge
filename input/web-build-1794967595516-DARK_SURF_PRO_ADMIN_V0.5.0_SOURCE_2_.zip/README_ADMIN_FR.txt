DARK SURF ADMIN — SOURCE ANDROID V12 / 0.4.0

L'application ADMIN est une variante Android séparée (flavor admin) de la coque WebView DARK SURF.
Elle ouvre le portail V8 en HTTPS. Les écrans de configuration globale (Protocoles VPN) sont servis
par le serveur V8 dans SERVER_V8/src/portal.js : une fois le serveur mis à jour, l'écran apparaît
dans l'application ADMIN après connexion avec le compte administrateur. Le vendeur n'a pas accès
à ces fonctions : le serveur contrôle le rôle côté backend.

Compilation dans Android Studio / AndroidForge :
  ./gradlew assembleAdminRelease

Le projet contient également le flavor sellerRelease pour DARK SURF PRO. Pour compiler les deux :
  ./gradlew assembleAdminRelease assembleSellerRelease

Avant compilation, vérifier dans app/build.gradle.kts :
- PORTAL_URL : URL HTTPS réelle du portail DARK SURF V8 (déjà préremplie avec le domaine de cette installation).
- ACTIVATION_PUBLIC_KEY : déjà renseignée (clé publique de seller-private.pem).
- SUPPORT_WHATSAPP : numéro de support au format international sans +.

Version Android : versionCode 4, versionName 0.4.0.
L'application ADMIN possède son identifiant de package distinct via le suffixe .admin et ses ressources d'icône dédiées.
Aucun APK n'est fourni : ce dossier contient les sources à compiler dans AndroidForge/Android Studio.

Mise à jour SSH-WS (portail serveur)
-----------------------------------
La configuration SSH-WS prioritaire est administrée dans le portail Web DARK SURF, page « Protocoles VPN ». L'application Pro Admin ouvre déjà ce portail authentifié : aucune nouvelle saisie de compte ou de clé n'est nécessaire dans l'APK. Le portail serveur mis à jour expose désormais l'IP VPS, le Host HTTP CloudFront, le port 2084, le chemin /ws-ssh et le payload personnalisé.
