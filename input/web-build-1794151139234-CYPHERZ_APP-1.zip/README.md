# Cypher Z — application Android (Flutter)

Assistant IA relié à **votre serveur Cypher Z** (dossier `cypherz-server`, autonome). Fonctions : discussion (IA Groq, Gemini en renfort), analyse de projets
(.zip / .tar.gz), création de projets en archive (.zip / .tar.gz) et génération d'images. Historique local, thème clair/sombre.

## Obtenir l'APK (sans rien installer sur votre PC)
1. Créez un dépôt GitHub (privé ou public) et envoyez-y **tout le contenu** de ce dossier
   (sur github.com : *Add file → Upload files*, glissez les fichiers **y compris le dossier `.github`** ; pensez à afficher les fichiers cachés).
2. Onglet **Actions** → « Build APK » → **Run workflow** (ou il démarre seul au premier envoi).
3. Après 5–10 min : ouvrez l'exécution terminée → section **Artifacts** → téléchargez **ZIDANE-AI-apk** → dézippez → `app-release.apk`.
4. Sur le téléphone : installez l'APK (autorisez « sources inconnues »).

Si l'étape *Analyse* ou *Construire* échoue, ouvrez le journal rouge et envoyez-moi les dernières lignes : je corrige.

## Premier lancement
Créez votre compte (ou connectez-vous) : c'est tout. Il n'y a plus de clé API ni de page API ; le quota de requêtes est celui du compte. L’adresse du serveur est fixée dans `lib/config.dart` (ou `--dart-define=CYPHERZ_SERVER=…`) et n’est jamais affichée.

**Sécurité** : aucune clé Groq/Gemini n'est dans l'application (un APK se décompile en quelques minutes). Elles vivent uniquement sur le serveur.

## Utilisation
- **Auto** : discussion ; si vous écrivez « dessine… » ou « crée un projet … fichiers », l'application bascule toute seule.
- **Image** : décrivez l'image (coût : 2 requêtes). **Projet ZIP** : décrivez le projet, vous recevez une archive (5 requêtes).
- 📎 **Joindre** un `.zip` / `.tar.gz` puis poser une question : analyse du projet (5 requêtes). Les `.rar` et `.7z` ne sont pas lisibles : recompressez en `.zip`.
- Les fichiers produits se partagent/enregistrent avec **Enregistrer / Partager**.

## Remarques
- Le suivi des requêtes utilise le quota de votre compte (chat = 1). Les échecs sont remboursés.
- Signature « debug » : suffisante pour installer l'APK chez vous, pas pour le Play Store.
- Le trafic part en `http://` (sans chiffrement) tant que votre serveur n'a pas de HTTPS.


## Dépannage compilation GitHub Actions
- **`version solving failed` (win32)** : `share_plus` doit rester en `>=10.0.0 <11.0.0` (la 13.x est incompatible avec les anciens plugins).
- **`:file_picker:checkReleaseAarMetadata … compile against version 36`** : `file_picker` (compilé contre Android 34) a été REMPLACÉ par `file_selector` (plugin officiel Flutter) dans `pubspec.yaml` et `lib/screens/chat_screen.dart`. Si tu vois encore `file_picker` dans ton `pubspec.yaml`, remplace-le par celui de ce zip.
- Le workflow garde en plus un correctif Gradle (compileSdk 36 + vérification AAR désactivée) qui échoue vite si absent (`PATCH_OK` / `PATCH_MANQUANT`).

## Parcours et options
- **Compte d'abord** : création de compte ou connexion (e-mail + mot de passe 8 caractères min.), puis directement le chat. Quota épuisé : bouton vers l'administrateur sur WhatsApp.
- L'adresse du serveur n'est plus affichée ni modifiable (elle se règle dans `lib/config.dart`).
- Réglages : requêtes utilisées, style de réponse (court/normal/détaillé), personnalités prêtes à l'emploi, taille du texte.
- Conversations : recherche, renommer, exporter/partager ; messages : copier, partager, régénérer.

## Modifier l'app sans recompiler (panneau admin → onglet « Application »)
Annonce en haut du chat, suggestions d'accueil, personnalités, numéro WhatsApp, texte d'aide, ouverture/fermeture des inscriptions,
et **mises à jour** (dernière version, version minimale obligatoire, lien de l'APK). Les téléphones lisent ces réglages à chaque ouverture.
À chaque nouvel APK : augmentez `buildNumber` dans `lib/config.dart`, puis renseignez « Dernière version » dans le panneau.

## Comptes sans clé / avec clé
- **Sans clé** : l'utilisateur crée son compte puis choisit « Continuer sans clé ». L'IA répond aux questions (texte seulement, quota de messages par jour réglé dans le panneau admin). Pour du code qui utilise les API du site, elle écrit le code avec `VOTRE_CLE_API` et l'invite à contacter l'administrateur.
- **Avec clé** : dès que la clé est saisie (écran de démarrage ou Réglages), l'IA cherche dans le catalogue du site les API utiles à la demande et les intègre au code avec la clé de l'utilisateur (commandes de bot WhatsApp, projets ZIP, etc.). La vraie clé n'est jamais envoyée aux fournisseurs d'IA : elle est ajoutée à la réponse par le serveur.
- Langues : Français / English (Réglages ou écran de connexion).

## Changer l'icône
Remplacez `assets/icon.png` (PNG 1024×1024) et `assets/icon_fg.png` (même motif sur fond transparent, centré, marge d'environ 20 %) puis relancez « Build APK » : l'icône est générée automatiquement.
