import 'package:flutter/material.dart';
import '../config.dart';
import '../i18n.dart';
import '../remote.dart';
import '../storage.dart';
import '../theme.dart';
import '../widgets.dart';
import 'auth_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _name = TextEditingController(text: Store.userName);
  late final TextEditingController _persona = TextEditingController(text: Store.persona);
  String _style = Store.style;
  double _scale = Store.fontScale;

  @override
  void dispose() {
    _name.dispose();
    _persona.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    await Store.setProfile(userName: _name.text, persona: _persona.text);
    await Store.setStyle(_style);
    await Store.setFontScale(_scale);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('Réglages enregistrés', 'Settings saved'))));
    Navigator.of(context).pop();
  }

  Future<void> _clearHistory() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(tr('Effacer l\'historique ?', 'Clear history?')),
        content: Text(tr('Toutes les conversations enregistrées sur ce téléphone seront supprimées.', 'All conversations saved on this phone will be deleted.')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(tr('Annuler', 'Cancel'))),
          TextButton(onPressed: () => Navigator.pop(c, true), child: Text(tr('Effacer', 'Clear'))),
        ],
      ),
    );
    if (ok == true) {
      await Store.clearHistory();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('Historique effacé', 'History cleared'))));
    }
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(tr('Se déconnecter ?', 'Sign out?')),
        content: Text(tr('Votre historique reste sur ce téléphone.', 'Your history stays on this phone.')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(tr('Annuler', 'Cancel'))),
          TextButton(onPressed: () => Navigator.pop(c, true), child: Text(tr('Se déconnecter', 'Sign out'))),
        ],
      ),
    );
    if (ok != true) return;
    await Store.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const AuthScreen()), (r) => false);
  }

  Widget _section(String title) => Padding(
        padding: const EdgeInsets.only(top: 22, bottom: 8, left: 4),
        child: Text(title.toUpperCase(),
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 1.1, color: Pal.muted(context))),
      );

  Widget _swatch(int i) {
    final p = Pal.presets[i];
    final sel = Store.accentIndex == i;
    return GestureDetector(
      onTap: () async {
        await Store.setLook(accent: i);
        if (mounted) setState(() {});
      },
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [p.a, p.b]),
            border: Border.all(color: sel ? Pal.text(context) : Colors.transparent, width: 2.5),
          ),
          child: sel ? const Icon(Icons.check, color: Colors.white, size: 22) : null,
        ),
        const SizedBox(height: 4),
        Text(tr(p.fr, p.en), style: TextStyle(fontSize: 11, color: Pal.muted(context))),
      ]),
    );
  }

  Widget _bgChip(String id, String fr, String en, IconData icon) {
    final sel = Store.bgStyle == id;
    return ChoiceChip(
      selected: sel,
      showCheckmark: false,
      avatar: Icon(icon, size: 16, color: sel ? Colors.white : Pal.muted(context)),
      label: Text(tr(fr, en)),
      labelStyle: TextStyle(color: sel ? Colors.white : Pal.text(context), fontSize: 13),
      selectedColor: Pal.accent,
      onSelected: (_) async {
        await Store.setLook(bgStyle: id);
        if (mounted) setState(() {});
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      appBar: AppBar(title: Text(tr('Réglages', 'Settings'), style: const TextStyle(fontWeight: FontWeight.w700))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
        children: [
          _section(tr('Apparence', 'Appearance')),
          GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tr('Couleur de l\'application', 'App color'), style: TextStyle(fontWeight: FontWeight.w700, color: Pal.text(context))),
              const SizedBox(height: 12),
              Wrap(spacing: 14, runSpacing: 12, children: [for (var i = 0; i < Pal.presets.length; i++) _swatch(i)]),
              const SizedBox(height: 20),
              Text(tr('Fond animé', 'Animated background'), style: TextStyle(fontWeight: FontWeight.w700, color: Pal.text(context))),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 6, children: [
                _bgChip('aurora', 'Aurore', 'Aurora', Icons.blur_on),
                _bgChip('orbs', 'Bulles', 'Bubbles', Icons.bubble_chart_outlined),
                _bgChip('waves', 'Vagues', 'Waves', Icons.waves),
                _bgChip('plain', 'Uni', 'Plain', Icons.crop_square),
              ]),
              const SizedBox(height: 6),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(tr('Animation en mouvement', 'Moving animation')),
                subtitle: Text(tr('Désactivez pour économiser la batterie', 'Turn off to save battery')),
                value: Store.bgAnimated,
                onChanged: (v) async {
                  await Store.setLook(animated: v);
                  if (mounted) setState(() {});
                },
              ),
              Row(children: [
                Icon(Icons.brightness_6_outlined, size: 20, color: Pal.muted(context)),
                Expanded(
                  child: Slider(
                    value: Store.bgIntensity.clamp(0.2, 1.0).toDouble(),
                    min: 0.2,
                    max: 1.0,
                    onChanged: (v) async {
                      await Store.setLook(intensity: v);
                      if (mounted) setState(() {});
                    },
                  ),
                ),
                Text(tr('Intensité', 'Intensity'), style: TextStyle(fontSize: 12, color: Pal.muted(context))),
              ]),
              const SizedBox(height: 8),
              ValueListenableBuilder<ThemeMode>(
                valueListenable: Store.themeMode,
                builder: (context, mode, _) => SizedBox(
                  width: double.infinity,
                  child: SegmentedButton<ThemeMode>(
                    segments: [
                      ButtonSegment(value: ThemeMode.dark, label: Text(tr('Sombre', 'Dark')), icon: const Icon(Icons.dark_mode_outlined)),
                      ButtonSegment(value: ThemeMode.light, label: Text(tr('Clair', 'Light')), icon: const Icon(Icons.light_mode_outlined)),
                      ButtonSegment(value: ThemeMode.system, label: const Text('Auto'), icon: const Icon(Icons.phone_android)),
                    ],
                    selected: {mode},
                    onSelectionChanged: (s) => Store.setTheme(s.first),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(children: [
                const Icon(Icons.text_fields, size: 20),
                Expanded(
                  child: Slider(
                    value: _scale,
                    min: 0.85,
                    max: 1.4,
                    divisions: 11,
                    label: '${(_scale * 100).round()} %',
                    onChanged: (v) => setState(() => _scale = v),
                  ),
                ),
                Text('${(_scale * 100).round()} %'),
              ]),
            ]),
          ),
          _section(tr('Profil', 'Profile')),
          GlassCard(
            child: TextField(controller: _name, decoration: InputDecoration(labelText: tr('Nom affiché', 'Display name'), prefixIcon: const Icon(Icons.person_outline))),
          ),
          _section(tr('Réponses de l\'IA', 'AI answers')),
          GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SizedBox(
                width: double.infinity,
                child: SegmentedButton<String>(
                  segments: [
                    ButtonSegment(value: 'concise', label: Text(tr('Court', 'Short'))),
                    ButtonSegment(value: 'normal', label: const Text('Normal')),
                    ButtonSegment(value: 'detailed', label: Text(tr('Détaillé', 'Detailed'))),
                  ],
                  selected: {_style},
                  onSelectionChanged: (v) => setState(() => _style = v.first),
                ),
              ),
              const SizedBox(height: 16),
              Text(tr('Personnalité', 'Personality'), style: TextStyle(fontWeight: FontWeight.w700, color: Pal.text(context))),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 4, children: [
                for (final e in Remote.personaPresets.entries) ActionChip(label: Text(e.key), onPressed: () => setState(() => _persona.text = e.value)),
              ]),
              const SizedBox(height: 10),
              TextField(
                controller: _persona,
                minLines: 3,
                maxLines: 7,
                decoration: InputDecoration(hintText: tr('Comment l\'assistant doit se comporter…', 'How the assistant should behave…')),
              ),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () => setState(() => _persona.text = Remote.defaultPersona),
                  child: Text(tr('Rétablir par défaut', 'Reset to default')),
                ),
              ),
            ]),
          ),
          _section(tr('Langue', 'Language')),
          const GlassCard(child: Align(alignment: Alignment.centerLeft, child: LangToggle())),
          const SizedBox(height: 22),
          FilledButton(onPressed: _save, child: Text(tr('Enregistrer', 'Save'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
          _section(tr('Données', 'Data')),
          GlassCard(
            padding: EdgeInsets.zero,
            child: Column(children: [
              ListTile(
                leading: const Icon(Icons.info_outline),
                title: Text(tr('À propos', 'About')),
                subtitle: Text('${AppConfig.appName} · build ${AppConfig.buildNumber}'),
                onTap: () => showAboutDialog(
                  context: context,
                  applicationName: AppConfig.appName,
                  applicationVersion: 'build ${AppConfig.buildNumber}',
                  applicationLegalese: tr('Créé par Zidane.', 'Created by Zidane.'),
                ),
              ),
              ListTile(leading: const Icon(Icons.delete_sweep_outlined), title: Text(tr('Effacer l\'historique', 'Clear history')), onTap: _clearHistory),
              ListTile(
                leading: const Icon(Icons.logout, color: Pal.danger),
                title: Text(tr('Se déconnecter', 'Sign out'), style: const TextStyle(color: Pal.danger)),
                onTap: _logout,
              ),
            ]),
          ),
        ],
      ),
    );
  }
}
