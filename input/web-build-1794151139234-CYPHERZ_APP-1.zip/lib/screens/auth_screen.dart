import '../i18n.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../api.dart';
import '../config.dart';
import '../remote.dart';
import '../storage.dart';
import '../theme.dart';
import '../widgets.dart';
import 'chat_screen.dart';

/// Connexion ou création de compte (sans clé API : elle est demandée ensuite).
class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _mail = TextEditingController();
  final _user = TextEditingController();
  final _pass = TextEditingController();
  final _pass2 = TextEditingController();
  bool _register = false;
  bool _hide = true;
  bool _busy = false;
  String? _error;
  String? _info;

  @override
  void dispose() {
    _mail.dispose();
    _user.dispose();
    _pass.dispose();
    _pass2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final mail = _mail.text.trim();
    final pass = _pass.text;
    final name = _user.text.trim();
    setState(() {
      _error = null;
      _info = null;
    });
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(mail)) {
      setState(() => _error = tr('Adresse e-mail invalide.', 'Invalid e-mail address.'));
      return;
    }
    if (_register) {
      if (!RegExp(r'^[A-Za-z0-9_.\-]{3,20}$').hasMatch(name)) {
        setState(() => _error = tr('Nom d\'utilisateur : 3 à 20 caractères (lettres, chiffres, _ . -).', 'Username: 3 to 20 characters (letters, digits, _ . -).'));
        return;
      }
      if (pass.length < 8) {
        setState(() => _error = tr('Le mot de passe doit contenir au moins 8 caractères.', 'The password must contain at least 8 characters.'));
        return;
      }
      if (pass != _pass2.text) {
        setState(() => _error = tr('Les deux mots de passe ne sont pas identiques.', 'The two passwords do not match.'));
        return;
      }
    } else if (pass.isEmpty) {
      setState(() => _error = tr('Saisissez votre mot de passe.', 'Enter your password.'));
      return;
    }

    setState(() => _busy = true);
    try {
      final base = AppConfig.defaultBaseUrl;
      final body = {
        'mail': mail,
        'password': base64.encode(utf8.encode(pass)),
        if (_register) 'username': name,
      };
      final res = await http
          .post(Uri.parse('$base/api/manageusers/${_register ? 'register' : 'login'}'),
              headers: {'Content-Type': 'application/json'}, body: jsonEncode(body))
          .timeout(const Duration(seconds: 30));
      Map<String, dynamic> json = {};
      try {
        final d = jsonDecode(utf8.decode(res.bodyBytes));
        if (d is Map<String, dynamic>) json = d;
      } catch (_) {}
      final msg = json['message']?.toString();
      if (json['status'] != true) {
        setState(() => _error = msg ?? tr('Erreur (${res.statusCode}). Réessayez.', 'Error (${res.statusCode}). Please try again.'));
        return;
      }
      if (_register) {
        // Compte créé : on passe en mode connexion (e-mail éventuellement à confirmer).
        setState(() {
          _register = false;
          _pass2.clear();
          _info = '${msg ?? tr('Compte créé.', 'Account created.')} Connectez-vous maintenant.';
        });
        return;
      }
      await Store.setAccount(mail);
      await Store.setToken(json['token']?.toString() ?? '');
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const ChatScreen()),
        (r) => false,
      );
    } catch (e) {
      setState(() => _error = e.toString().contains('TimeoutException')
          ? tr('Le serveur met trop de temps à répondre. Réessayez.', 'The server is taking too long to respond. Please try again.')
          : tr('Connexion impossible. Vérifiez votre internet puis réessayez.', 'Cannot connect. Check your internet and try again.'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// Connexion avec Google : le site de l'API gère Google, l'application récupère ensuite la session (code de jumelage).
  Future<void> _google() async {
    setState(() {
      _busy = true;
      _error = null;
      _info = null;
    });
    try {
      final base = '${ZidaneApi.normalizeBase(Store.baseUrl)}/api/manageusers/app-link';
      final start = jsonDecode((await http.post(Uri.parse('$base/start')).timeout(const Duration(seconds: 20))).body) as Map<String, dynamic>;
      final code = (start['code'] ?? '').toString();
      if (code.isEmpty) throw Exception('no code');
      final page = Uri.parse(AppConfig.siteLogin).replace(queryParameters: {'from': 'app', 'next': '/app-link.html?code=$code'});
      await openUrl(context, page.toString());
      if (mounted) setState(() => _info = tr('Terminez la connexion Google dans le navigateur, puis revenez ici…', 'Finish the Google sign-in in the browser, then come back here…'));
      final end = DateTime.now().add(const Duration(minutes: 5));
      while (mounted && DateTime.now().isBefore(end)) {
        await Future.delayed(const Duration(seconds: 2));
        final r = await http.get(Uri.parse('$base/poll').replace(queryParameters: {'code': code})).timeout(const Duration(seconds: 20));
        if (r.statusCode == 404) break;
        final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        if (j['status'] == true && j['pending'] == false && (j['token'] ?? '').toString().isNotEmpty) {
          await Store.setAccount((j['mail'] ?? '').toString());
          await Store.setToken(j['token'].toString());
          if (!mounted) return;
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const ChatScreen()),
            (r) => false,
          );
          return;
        }
      }
      if (mounted) setState(() {
        _info = null;
        _error = tr('Connexion Google non terminée. Réessayez.', 'Google sign-in not completed. Please try again.');
      });
    } catch (e) {
      if (mounted) setState(() {
        _info = null;
        _error = tr('Connexion impossible. Vérifiez votre internet puis réessayez.', 'Cannot connect. Check your internet and try again.');
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  InputDecoration _dec(String label, IconData icon, {Widget? suffix}) =>
      InputDecoration(labelText: label, prefixIcon: Icon(icon), suffixIcon: suffix);

  @override
  Widget build(BuildContext context) {
    final eye = IconButton(
      icon: Icon(_hide ? Icons.visibility_outlined : Icons.visibility_off_outlined),
      onPressed: () => setState(() => _hide = !_hide),
    );
    return AppScaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: GlassCard(
                padding: const EdgeInsets.fromLTRB(22, 22, 22, 18),
                radius: 24,
                child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Align(alignment: Alignment.centerRight, child: LangToggle()),
                  const SizedBox(height: 10),
                  const Center(child: BrandMark(size: 72, glow: true)),
                  const SizedBox(height: 18),
                  Text(AppConfig.appName,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Pal.text(context))),
                  const SizedBox(height: 4),
                  Text(_register ? tr('Créer votre compte', 'Create your account') : Remote.tagline,
                      textAlign: TextAlign.center, style: TextStyle(color: Pal.muted(context), fontSize: 15)),
                  const SizedBox(height: 28),
                  TextField(
                    controller: _mail,
                    keyboardType: TextInputType.emailAddress,
                    autocorrect: false,
                    decoration: _dec(tr('Adresse e-mail', 'E-mail address'), Icons.mail_outline),
                  ),
                  if (_register) ...[
                    const SizedBox(height: 12),
                    TextField(controller: _user, autocorrect: false, decoration: _dec(tr('Nom d\'utilisateur', 'Username'), Icons.person_outline)),
                  ],
                  const SizedBox(height: 12),
                  TextField(
                    controller: _pass,
                    obscureText: _hide,
                    autocorrect: false,
                    enableSuggestions: false,
                    decoration: _dec(tr('Mot de passe', 'Password'), Icons.lock_outline, suffix: eye),
                  ),
                  if (_register) ...[
                    const SizedBox(height: 12),
                    TextField(
                      controller: _pass2,
                      obscureText: _hide,
                      autocorrect: false,
                      enableSuggestions: false,
                      decoration: _dec(tr('Confirmer le mot de passe', 'Confirm password'), Icons.lock_outline),
                    ),
                  ],
                  if (_info != null) ...[
                    const SizedBox(height: 12),
                    Text(_info!, style: TextStyle(color: Pal.accent2)),
                  ],
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Text(_error!, style: const TextStyle(color: Pal.danger)),
                  ],
                  const SizedBox(height: 20),
                  FilledButton(
                    onPressed: _busy ? null : _submit,
                    child: _busy
                        ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5))
                        : Text(_register ? tr('Créer mon compte', 'Create my account') : tr('Se connecter', 'Sign in'),
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: _busy ? null : _google,
                    icon: const Icon(Icons.account_circle_outlined, size: 20),
                    label: Text(tr('Continuer avec Google', 'Continue with Google')),
                  ),
                  const SizedBox(height: 6),
                  if (Remote.signupEnabled || _register)
                  TextButton(
                    onPressed: _busy
                        ? null
                        : () => setState(() {
                              _register = !_register;
                              _error = null;
                              _info = null;
                            }),
                    child: Text(_register ? tr('J\'ai déjà un compte : me connecter', 'I already have an account: sign in') : tr('Pas de compte ? Créer un compte', 'No account? Create one')),
                  ),
                ],
              ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
