import 'package:flutter/material.dart';
import '../account.dart';
import '../config.dart';
import '../i18n.dart';
import '../storage.dart';
import '../theme.dart';
import '../widgets.dart';
import 'auth_screen.dart';
import 'settings_screen.dart';

/// Mon compte : identité, requêtes, clé API, accès aux réglages.
class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  @override
  void initState() {
    super.initState();
    Account.refresh();
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(tr('Se déconnecter ?', 'Sign out?')),
        content: Text(tr('Votre historique reste sur ce téléphone.', 'Your history stays on this phone.')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(tr('Annuler', 'Cancel'))),
          TextButton(onPressed: () => Navigator.pop(c, true), child: Text(tr('Se déconnecter', 'Sign out'))),
        ],
      ),
    );
    if (ok != true) return;
    await Store.logout();
    Account.info.value = null;
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const AuthScreen()), (r) => false);
  }

  Widget _tile(BuildContext context, IconData icon, String title, String? sub, VoidCallback onTap, {Color? color}) {
    return GlassCard(
      onTap: onTap,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      child: Row(children: [
        Icon(icon, color: color ?? Pal.accent2),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15.5, color: color ?? Pal.text(context))),
            if (sub != null) Text(sub, style: TextStyle(color: Pal.muted(context), fontSize: 12.5)),
          ]),
        ),
        Icon(Icons.chevron_right, color: Pal.muted(context)),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      appBar: AppBar(title: Text(tr('Mon compte', 'My account'), style: const TextStyle(fontWeight: FontWeight.w700))),
      body: ValueListenableBuilder<AccountInfo?>(
        valueListenable: Account.info,
        builder: (context, a, _) {
          final name = (a != null && a.username.isNotEmpty) ? a.username : (Store.userName.isNotEmpty ? Store.userName : Store.account.split('@').first);
          final mail = (a != null && a.mail.isNotEmpty) ? a.mail : Store.account;
          final initial = name.isEmpty ? 'Z' : name.substring(0, 1).toUpperCase();
          return RefreshIndicator(
            onRefresh: () async {
              await Account.refresh();
            },
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
              children: [
                GlassCard(
                  padding: const EdgeInsets.all(18),
                  child: Row(children: [
                    Container(
                      width: 62,
                      height: 62,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(gradient: Pal.gradient, shape: BoxShape.circle),
                      child: Text(initial, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Colors.white)),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: Pal.text(context))),
                        const SizedBox(height: 2),
                        Text(mail, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Pal.muted(context), fontSize: 13.5)),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(color: Pal.accent.withAlpha(45), borderRadius: BorderRadius.circular(12)),
                          child: Text(a != null && a.premium ? 'Premium' : tr('Offre gratuite', 'Free plan'),
                              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Pal.accent)),
                        ),
                      ]),
                    ),
                  ]),
                ),
                const SizedBox(height: 14),
                const UsageCard(),
                const SizedBox(height: 14),
                _tile(context, Icons.chat_rounded, tr('Obtenir plus de requêtes', 'Get more requests'), tr('Contacter Zidane sur WhatsApp', 'Contact Zidane on WhatsApp'),
                    () => contactAdmin(context),
                    color: const Color(0xFF16A34A)),
                const SizedBox(height: 10),
                _tile(context, Icons.tune_rounded, tr('Réglages', 'Settings'), tr('Apparence, fond animé, langue, IA', 'Appearance, animated background, language, AI'),
                    () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen()))),
                const SizedBox(height: 10),
                _tile(context, Icons.logout, tr('Se déconnecter', 'Sign out'), null, _logout, color: Pal.danger),
                const SizedBox(height: 22),
                Center(child: Text('${AppConfig.appName} · build ${AppConfig.buildNumber}', style: TextStyle(color: Pal.muted(context), fontSize: 12))),
              ],
            ),
          );
        },
      ),
    );
  }
}
