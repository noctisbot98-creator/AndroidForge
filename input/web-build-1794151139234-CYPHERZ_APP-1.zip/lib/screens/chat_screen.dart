import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:share_plus/share_plus.dart';
import '../account.dart';
import '../ai_api.dart';
import '../api.dart';
import '../banners.dart';
import '../config.dart';
import '../i18n.dart';
import '../models.dart';
import '../remote.dart';
import '../storage.dart';
import '../theme.dart';
import '../widgets.dart';
import 'account_screen.dart';
import 'settings_screen.dart';

/// Raccourci de l'écran d'accueil et de la barre sous le champ de saisie.
class _Shortcut {
  final IconData icon;
  final String fr;
  final String en;
  final String preFr; // début de message pré-rempli
  final String preEn;
  final String mode; // auto | image | archive
  const _Shortcut(this.icon, this.fr, this.en, {this.preFr = '', this.preEn = '', this.mode = 'auto'});
}

const _shortcuts = <_Shortcut>[
  _Shortcut(Icons.image_outlined, 'Créer une image', 'Create an image', mode: 'image'),
  _Shortcut(Icons.code_rounded, 'Écrire du code', 'Write code', preFr: 'Écris le code de : ', preEn: 'Write the code for: '),
  _Shortcut(Icons.folder_zip_outlined, 'Projet ZIP', 'ZIP project', mode: 'archive'),
  _Shortcut(Icons.edit_note_rounded, 'Rédiger', 'Write', preFr: 'Rédige un texte professionnel sur : ', preEn: 'Write a professional text about: '),
  _Shortcut(Icons.translate_rounded, 'Traduire', 'Translate', preFr: 'Traduis en anglais : ', preEn: 'Translate into French: '),
  _Shortcut(Icons.spellcheck_rounded, 'Corriger', 'Fix text', preFr: 'Corrige ce texte : ', preEn: 'Correct this text: '),
  _Shortcut(Icons.summarize_outlined, 'Résumer', 'Summarize', preFr: 'Résume ce texte : ', preEn: 'Summarize this text: '),
  _Shortcut(Icons.lightbulb_outline, 'Idées', 'Ideas', preFr: 'Donne-moi 5 idées pour : ', preEn: 'Give me 5 ideas for: '),
  _Shortcut(Icons.school_outlined, 'Expliquer', 'Explain', preFr: 'Explique-moi simplement : ', preEn: 'Explain simply: '),
];

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _input = TextEditingController();
  final FocusNode _focus = FocusNode();
  final ScrollController _scroll = ScrollController();
  late List<Conversation> _all;
  late Conversation _conv;
  bool _busy = false;
  String _mode = 'auto'; // auto | image | archive
  AttachedFile? _attach;
  JobInfo? _prog;
  _Pending? _last;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _all = Store.loadConversations();
    _conv = Conversation.create();
    Account.refresh();
  }

  @override
  void dispose() {
    _input.dispose();
    _focus.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      _scroll.animateTo(_scroll.position.maxScrollExtent + 120, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    });
  }

  Future<void> _persist() async {
    _conv.updated = DateTime.now();
    if (_conv.messages.isNotEmpty && !_all.any((c) => c.id == _conv.id)) _all.insert(0, _conv);
    await Store.saveConversations(_all);
  }

  String _shorten(String s) {
    final t = s.trim().replaceAll(RegExp(r'\s+'), ' ');
    return t.length <= 40 ? t : '${t.substring(0, 40)}…';
  }

  void _useShortcut(_Shortcut s) {
    if (_busy) return;
    setState(() {
      if (s.mode != 'auto') _mode = s.mode;
      final pre = tr(s.preFr, s.preEn);
      if (pre.isNotEmpty) {
        _mode = 'auto';
        _input.text = pre;
        _input.selection = TextSelection.collapsed(offset: pre.length);
      }
    });
    _focus.requestFocus();
  }

  Future<void> _pick() async {
    if (_busy) return;
    // file_selector (équipe Flutter) à la place de file_picker (incompatible avec la compilation Android).
    const group = XTypeGroup(
      label: 'Archives',
      extensions: ['zip', 'tar', 'gz', 'tgz'],
      mimeTypes: [
        'application/zip',
        'application/x-zip-compressed',
        'application/x-tar',
        'application/gzip',
        'application/x-gzip',
        'application/x-compressed-tar',
        'application/octet-stream',
      ],
    );
    XFile? x;
    try {
      x = await openFile(acceptedTypeGroups: const [group]);
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('Impossible d\'ouvrir le sélecteur de fichiers.', 'Cannot open the file picker.'))));
      return;
    }
    if (x == null || !mounted) return;
    String? err;
    Uint8List? bytes;
    try {
      final len = await x.length();
      if (len > 30 * 1024 * 1024) {
        err = tr('Archive trop grosse (30 Mo maximum).', 'Archive too large (30 MB maximum).');
      } else {
        bytes = await x.readAsBytes();
      }
    } catch (_) {
      err = tr('Impossible de lire ce fichier.', 'Cannot read this file.');
    }
    if (err != null || bytes == null) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err ?? tr('Impossible de lire ce fichier.', 'Cannot read this file.'))));
      return;
    }
    setState(() => _attach = AttachedFile(x!.name, bytes!));
  }

  Future<void> _send([String? preset]) async {
    final text = (preset ?? _input.text).trim();
    final att = _attach;
    if ((text.isEmpty && att == null) || _busy) return;
    _input.clear();
    final shown = att == null ? text : '📎 ${att.name}${text.isEmpty ? '' : '\n$text'}';
    final pending = _Pending(text, att, _mode);
    setState(() {
      _conv.messages.add(ChatMessage(role: 'user', text: shown));
      if (_conv.messages.length == 1) _conv.title = _shorten(att == null ? text : att.name);
      _busy = true;
      _attach = null;
      _prog = null;
      _mode = 'auto';
    });
    _scrollDown();
    await _persist();
    await _ask(pending);
  }

  Future<void> _ask(_Pending p) async {
    _last = p;
    final sw = Stopwatch()..start();
    try {
      final api = AiApi(baseUrl: Store.baseUrl);
      AiReply r;
      if (p.attach != null) {
        r = await api.project(p.attach!.bytes, p.text);
      } else if (p.mode == 'image') {
        r = await api.image(p.text);
      } else if (p.mode == 'archive') {
        r = await api.generate(p.text);
      } else {
        final prev = _conv.messages.length > 1 ? _conv.messages.sublist(0, _conv.messages.length - 1) : <ChatMessage>[];
        r = await api.chat(
          text: p.text,
          history: ZidaneApi.buildHistory(prev),
          persona: Store.effectivePersona,
          name: Store.userName,
          mode: p.mode,
        );
      }
      if (r.type == 'job' && r.jobId != null) {
        final job = await api.waitJob(r.jobId!, onProgress: (j) {
          if (mounted) setState(() => _prog = j);
        });
        String? path;
        if (job.fileName != null) path = await api.download(job.id, job.fileName!);
        final kind = path == null ? 'text' : (job.fileMime ?? '').startsWith('image/') ? 'image' : 'archive';
        _conv.messages.add(ChatMessage(
          role: 'assistant',
          text: job.answer,
          kind: kind,
          filePath: path,
          fileName: job.fileName,
          fileSize: job.fileSize,
          ms: sw.elapsedMilliseconds,
        ));
      } else {
        _conv.messages.add(ChatMessage(role: 'assistant', text: r.text, ms: sw.elapsedMilliseconds));
      }
    } on ApiException catch (e) {
      _conv.messages.add(ChatMessage(role: 'assistant', text: e.message, error: true, quota: e.quota));
    } catch (_) {
      _conv.messages.add(ChatMessage(role: 'assistant', text: tr('Une erreur inattendue est survenue. Réessayez.', 'An unexpected error occurred. Please try again.'), error: true));
    }
    if (mounted) {
      setState(() {
        _busy = false;
        _prog = null;
      });
    }
    _scrollDown();
    await _persist();
    Account.refresh();
  }

  Future<void> _retry(ChatMessage failed) async {
    final p = _last;
    if (_busy || p == null) return;
    setState(() {
      _conv.messages.remove(failed);
      _busy = true;
      _prog = null;
    });
    await _ask(p);
  }

  Future<void> _regenerate() async {
    final p = _last;
    if (_busy || p == null || _conv.messages.isEmpty || _conv.messages.last.isUser) return;
    setState(() {
      _conv.messages.removeLast();
      _busy = true;
      _prog = null;
    });
    await _ask(p);
  }

  Future<void> _rename(Conversation c) async {
    final ctl = TextEditingController(text: c.title);
    final v = await showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(tr('Renommer', 'Rename')),
        content: TextField(controller: ctl, autofocus: true, maxLength: 60),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: Text(tr('Annuler', 'Cancel'))),
          TextButton(onPressed: () => Navigator.pop(d, ctl.text.trim()), child: const Text('OK')),
        ],
      ),
    );
    if (v != null && v.isNotEmpty) {
      setState(() => c.title = v);
      await Store.saveConversations(_all);
    }
  }

  Future<void> _export(Conversation c) async {
    final b = StringBuffer('${c.title}\n\n');
    for (final m in c.messages) {
      b.writeln('${m.isUser ? tr('Moi', 'Me') : AppConfig.appName} :\n${m.text}\n');
    }
    await Share.share(b.toString(), subject: c.title);
  }

  void _newChat() {
    if (_busy) return;
    setState(() {
      _conv = Conversation.create();
      _mode = 'auto';
      _attach = null;
    });
  }

  void _open(Conversation c) {
    if (_busy) return;
    setState(() => _conv = c);
    Navigator.of(context).pop();
    _scrollDown();
  }

  Future<void> _delete(Conversation c) async {
    setState(() {
      _all.removeWhere((x) => x.id == c.id);
      if (_conv.id == c.id) _conv = Conversation.create();
    });
    await Store.saveConversations(_all);
  }

  Future<void> _go(Widget page, {bool closeDrawer = false}) async {
    if (closeDrawer) Navigator.of(context).pop();
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
    if (!mounted) return;
    setState(() => _all = Store.loadConversations());
    Account.refresh();
  }

  @override
  Widget build(BuildContext context) {
    final empty = _conv.messages.isEmpty;
    return AppScaffold(
      appBar: AppBar(
        title: Text(empty ? AppConfig.appName : _conv.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 19)),
        actions: [
          UsageChip(onTap: () => _go(const AccountScreen())),
          IconButton(tooltip: tr('Nouvelle conversation', 'New conversation'), icon: const Icon(Icons.add_comment_outlined), onPressed: _newChat),
        ],
      ),
      drawer: _buildDrawer(context),
      body: Column(children: [
        const RemoteBanners(),
        Expanded(child: empty ? _welcome(context) : _messages(context)),
        _composer(context),
      ]),
    );
  }

  String _greeting() {
    final h = DateTime.now().hour;
    final name = Store.userName.trim();
    final base = h >= 5 && h < 18 ? tr('Bonjour', 'Good morning') : tr('Bonsoir', 'Good evening');
    return name.isEmpty ? base : '$base, $name';
  }

  Widget _welcome(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final cardW = (w - 32 - 10) / 2;
    final sugg = Remote.suggestions.take(3).toList();
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const BrandMark(size: 76, glow: true),
          const SizedBox(height: 18),
          Text(_greeting(), textAlign: TextAlign.center, style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: Pal.text(context))),
          const SizedBox(height: 6),
          Text(tr('Que veux-tu faire aujourd\'hui ?', 'What would you like to do today?'), style: TextStyle(color: Pal.muted(context), fontSize: 16)),
          const SizedBox(height: 24),
          Wrap(spacing: 10, runSpacing: 10, children: [
            for (final s in _shortcuts)
              SizedBox(
                width: cardW,
                child: GlassCard(
                  onTap: () => _useShortcut(s),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
                  child: Row(children: [
                    Icon(s.icon, size: 22, color: Pal.accent),
                    const SizedBox(width: 10),
                    Expanded(child: Text(tr(s.fr, s.en), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w600, color: Pal.text(context)))),
                  ]),
                ),
              ),
          ]),
          if (sugg.isNotEmpty) ...[
            const SizedBox(height: 18),
            for (final s in sugg)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: GlassCard(
                  onTap: () => _send(s),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  radius: 14,
                  child: Row(children: [
                    Icon(Icons.auto_awesome, size: 17, color: Pal.accent2),
                    const SizedBox(width: 10),
                    Expanded(child: Text(s, style: TextStyle(color: Pal.text(context), fontSize: 14))),
                  ]),
                ),
              ),
          ],
        ]),
      ),
    );
  }

  Widget _messages(BuildContext context) {
    final count = _conv.messages.length + (_busy ? 1 : 0);
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      itemCount: count,
      itemBuilder: (context, i) {
        if (i >= _conv.messages.length) return _Thinking(job: _prog);
        final m = _conv.messages[i];
        final isLast = i == _conv.messages.length - 1 && !_busy;
        return _Bubble(
          message: m,
          onRetry: m.error ? () => _retry(m) : null,
          onRegenerate: (isLast && !m.isUser && !m.error && m.kind == 'text' && _last != null) ? _regenerate : null,
        );
      },
    );
  }

  Widget _shortcutChip(BuildContext context, _Shortcut s) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: GestureDetector(
        onTap: _busy ? null : () => _useShortcut(s),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(color: Pal.surface(context), borderRadius: BorderRadius.circular(18), border: Border.all(color: Pal.border(context))),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(s.icon, size: 16, color: Pal.accent),
            const SizedBox(width: 6),
            Text(tr(s.fr, s.en), style: TextStyle(fontSize: 13, color: Pal.text(context))),
          ]),
        ),
      ),
    );
  }

  void _attachMenu() {
    if (_busy) return;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Pal.solid(context),
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.folder_zip_outlined),
            title: Text(tr('Joindre un projet (.zip, .tar.gz)', 'Attach a project (.zip, .tar.gz)')),
            subtitle: Text(tr('L\'IA l\'analyse et répond à tes questions', 'The AI analyses it and answers your questions')),
            onTap: () {
              Navigator.pop(c);
              _pick();
            },
          ),
          ListTile(
            leading: const Icon(Icons.image_outlined),
            title: Text(tr('Créer une image', 'Create an image')),
            onTap: () {
              Navigator.pop(c);
              setState(() => _mode = 'image');
              _focus.requestFocus();
            },
          ),
          ListTile(
            leading: const Icon(Icons.auto_awesome),
            title: Text(tr('Générer un projet ZIP', 'Generate a ZIP project')),
            onTap: () {
              Navigator.pop(c);
              setState(() => _mode = 'archive');
              _focus.requestFocus();
            },
          ),
        ]),
      ),
    );
  }

  Widget _composer(BuildContext context) {
    final hint = _attach != null
        ? tr('Question sur ce projet (facultatif)…', 'Question about this project (optional)…')
        : _mode == 'image'
            ? tr('Décris l\'image à créer…', 'Describe the image to create…')
            : _mode == 'archive'
                ? tr('Décris le projet à générer (ZIP)…', 'Describe the project to generate (ZIP)…')
                : tr('Écris ton message…', 'Type your message…');
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 4, 10, 8),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(
            height: 36,
            child: ListView(scrollDirection: Axis.horizontal, children: [for (final s in _shortcuts) _shortcutChip(context, s)]),
          ),
          const SizedBox(height: 8),
          if (_mode != 'auto' || _attach != null)
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Wrap(spacing: 8, children: [
                  if (_mode != 'auto')
                    InputChip(
                      avatar: Icon(_mode == 'image' ? Icons.image_outlined : Icons.folder_zip_outlined, size: 18),
                      label: Text(_mode == 'image' ? tr('Mode image', 'Image mode') : tr('Mode projet ZIP', 'ZIP project mode')),
                      onDeleted: _busy ? null : () => setState(() => _mode = 'auto'),
                    ),
                  if (_attach != null)
                    InputChip(
                      avatar: const Icon(Icons.folder_zip, size: 18),
                      label: Text('${_attach!.name} · ${(_attach!.size / 1024).round()} Ko'),
                      onDeleted: _busy ? null : () => setState(() => _attach = null),
                    ),
                ]),
              ),
            ),
          Container(
            padding: const EdgeInsets.fromLTRB(4, 4, 6, 4),
            decoration: BoxDecoration(
              color: Pal.surface(context),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: Pal.border(context)),
            ),
            child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              IconButton(tooltip: tr('Ajouter', 'Add'), icon: const Icon(Icons.add_circle_outline_rounded), onPressed: _busy ? null : _attachMenu),
              Expanded(
                child: TextField(
                  controller: _input,
                  focusNode: _focus,
                  minLines: 1,
                  maxLines: 6,
                  textInputAction: TextInputAction.newline,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: InputDecoration(
                    hintText: hint,
                    filled: false,
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 13),
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: GestureDetector(
                  onTap: _busy ? null : () => _send(),
                  child: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(gradient: _busy ? null : Pal.gradient, color: _busy ? Pal.surfaceHi(context) : null, shape: BoxShape.circle),
                    child: _busy
                        ? const Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(strokeWidth: 2.2))
                        : const Icon(Icons.arrow_upward_rounded, color: Colors.white),
                  ),
                ),
              ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _buildDrawer(BuildContext context) {
    final shown = _query.isEmpty
        ? _all
        : _all.where((c) => c.title.toLowerCase().contains(_query) || c.messages.any((m) => m.text.toLowerCase().contains(_query))).toList();
    return Drawer(
      child: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Row(children: [
              const BrandMark(size: 38),
              const SizedBox(width: 10),
              Text(AppConfig.appName, style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: Pal.text(context))),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
            child: GestureDetector(
              onTap: () => _go(const AccountScreen(), closeDrawer: true),
              child: const UsageCard(compact: true),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            child: FilledButton.icon(
              onPressed: () {
                Navigator.of(context).pop();
                _newChat();
              },
              icon: const Icon(Icons.add),
              label: Text(tr('Nouvelle conversation', 'New conversation')),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 6),
            child: TextField(
              onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
              decoration: InputDecoration(hintText: tr('Rechercher une conversation', 'Search conversations'), prefixIcon: const Icon(Icons.search), isDense: true),
            ),
          ),
          Expanded(
            child: _all.isEmpty
                ? Center(child: Text(tr('Aucun historique', 'No history'), style: TextStyle(color: Pal.muted(context))))
                : ListView.builder(
                    itemCount: shown.length,
                    itemBuilder: (context, i) {
                      final c = shown[i];
                      final selected = c.id == _conv.id;
                      return ListTile(
                        selected: selected,
                        selectedTileColor: Pal.surfaceHi(context),
                        leading: const Icon(Icons.chat_bubble_outline, size: 20),
                        title: Text(c.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                        trailing: PopupMenuButton<String>(
                          icon: const Icon(Icons.more_vert, size: 20),
                          onSelected: (v) {
                            if (v == 'rename') _rename(c);
                            if (v == 'export') _export(c);
                            if (v == 'delete') _delete(c);
                          },
                          itemBuilder: (_) => [
                            PopupMenuItem(value: 'rename', child: Text(tr('Renommer', 'Rename'))),
                            PopupMenuItem(value: 'export', child: Text(tr('Exporter / partager', 'Export / share'))),
                            PopupMenuItem(value: 'delete', child: Text(tr('Supprimer', 'Delete'))),
                          ],
                        ),
                        onTap: () => _open(c),
                      );
                    },
                  ),
          ),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.account_circle_outlined), title: Text(tr('Mon compte', 'My account')), onTap: () => _go(const AccountScreen(), closeDrawer: true)),
          ListTile(leading: const Icon(Icons.tune_rounded), title: Text(tr('Réglages', 'Settings')), onTap: () => _go(const SettingsScreen(), closeDrawer: true)),
        ]),
      ),
    );
  }
}

/// Un message : bulle colorée à droite pour l'utilisateur ; carte + logo à gauche pour l'IA, avec heure et durée de réponse.
class _Bubble extends StatelessWidget {
  final ChatMessage message;
  final VoidCallback? onRetry;
  final VoidCallback? onRegenerate;
  const _Bubble({required this.message, this.onRetry, this.onRegenerate});

  @override
  Widget build(BuildContext context) {
    final user = message.isUser;
    final dark = Pal.isDark(context);
    final fs = 15.5 * Store.fontScale;
    final errBg = dark ? const Color(0xFF3B1420) : const Color(0xFFFFE4E8);
    final errFg = dark ? const Color(0xFFFDA4AF) : const Color(0xFF9F1239);
    final fg = user ? Colors.white : (message.error ? errFg : Pal.text(context));
    final timeStyle = TextStyle(fontSize: 11.5, color: Pal.muted(context));

    if (user) {
      return Align(
        alignment: Alignment.centerRight,
        child: Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
          margin: const EdgeInsets.only(top: 8, bottom: 6, left: 40),
          child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Container(
              padding: const EdgeInsets.fromLTRB(14, 11, 14, 11),
              decoration: BoxDecoration(
                gradient: Pal.gradient,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(5),
                ),
              ),
              child: SelectableText(message.text, style: TextStyle(color: Colors.white, fontSize: fs, height: 1.4)),
            ),
            const SizedBox(height: 3),
            Text(fmtTime(message.time), style: timeStyle),
          ]),
        ),
      );
    }

    Widget content;
    if (message.error) {
      content = SelectableText(message.text, style: TextStyle(color: errFg, fontSize: fs, height: 1.4));
    } else {
      content = MarkdownBody(
        data: message.text,
        selectable: true,
        styleSheet: MarkdownStyleSheet(
          p: TextStyle(color: fg, fontSize: fs, height: 1.45),
          code: TextStyle(fontFamily: 'monospace', fontSize: 13.5, color: Pal.accent2, backgroundColor: Pal.surfaceHi(context)),
          codeblockDecoration: BoxDecoration(color: dark ? const Color(0xFF060A14) : const Color(0xFFE6ECF6), borderRadius: BorderRadius.circular(10)),
          codeblockPadding: const EdgeInsets.all(12),
          listBullet: TextStyle(color: fg),
          h1: TextStyle(color: fg, fontSize: 21, fontWeight: FontWeight.w800),
          h2: TextStyle(color: fg, fontSize: 18, fontWeight: FontWeight.w700),
          h3: TextStyle(color: fg, fontSize: 16, fontWeight: FontWeight.w700),
          strong: TextStyle(color: fg, fontWeight: FontWeight.w700),
          blockquoteDecoration: BoxDecoration(border: Border(left: BorderSide(color: Pal.accent2, width: 3))),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(top: 6, bottom: 8, right: 6),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Padding(padding: EdgeInsets.only(top: 2), child: BrandMark(size: 30)),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(AppConfig.appName, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: Pal.muted(context))),
            const SizedBox(height: 4),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
              decoration: BoxDecoration(
                color: message.error ? errBg : Pal.surface(context),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Pal.border(context)),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (message.kind == 'image' && message.filePath != null) _ImageView(path: message.filePath!),
                content,
                if (message.kind != 'text' && message.filePath != null) _FileActions(message: message),
                if (message.error) ...[
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, runSpacing: 4, children: [
                    if (onRetry != null)
                      OutlinedButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh, size: 16), label: Text(tr('Réessayer', 'Retry'))),
                    if (message.quota)
                      FilledButton.icon(
                        style: FilledButton.styleFrom(minimumSize: const Size(0, 38), backgroundColor: const Color(0xFF16A34A)),
                        onPressed: () => contactAdmin(context),
                        icon: const Icon(Icons.chat, size: 16),
                        label: Text(tr('Obtenir plus de requêtes', 'Get more requests')),
                      ),
                  ]),
                ],
              ]),
            ),
            const SizedBox(height: 5),
            Wrap(spacing: 14, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
              Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.schedule, size: 13, color: Pal.muted(context)),
                const SizedBox(width: 4),
                Text(message.ms > 0 && !message.error ? '${fmtTime(message.time)} · ${fmtDur(message.ms)}' : fmtTime(message.time), style: timeStyle),
              ]),
              if (!message.error) ...[
                _MiniAction(
                  icon: Icons.copy_rounded,
                  label: tr('Copier', 'Copy'),
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: message.text));
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('Copié', 'Copied')), duration: const Duration(seconds: 1)));
                  },
                ),
                _MiniAction(icon: Icons.share_outlined, label: tr('Partager', 'Share'), onTap: () => Share.share(message.text)),
                if (onRegenerate != null) _MiniAction(icon: Icons.refresh, label: tr('Régénérer', 'Regenerate'), onTap: onRegenerate!),
              ],
            ]),
          ]),
        ),
      ]),
    );
  }
}

class _MiniAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _MiniAction({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 14, color: Pal.muted(context)),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(fontSize: 12, color: Pal.muted(context))),
      ]),
    );
  }
}

/// « Cypher Z réfléchit… » avec le compteur de secondes en direct (et la progression des tâches longues).
class _Thinking extends StatefulWidget {
  final JobInfo? job;
  const _Thinking({this.job});

  @override
  State<_Thinking> createState() => _ThinkingState();
}

class _ThinkingState extends State<_Thinking> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat();
  final DateTime _start = DateTime.now();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final job = widget.job;
    return Padding(
      padding: const EdgeInsets.only(top: 6, bottom: 8),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Padding(padding: EdgeInsets.only(top: 2), child: BrandMark(size: 30)),
        const SizedBox(width: 10),
        Expanded(
          child: Align(
            alignment: Alignment.centerLeft,
            child: Container(
              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
              decoration: BoxDecoration(color: Pal.surface(context), borderRadius: BorderRadius.circular(18), border: Border.all(color: Pal.border(context))),
              child: AnimatedBuilder(
                animation: _c,
                builder: (context, _) {
                  final secs = DateTime.now().difference(_start).inSeconds;
                  return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(mainAxisSize: MainAxisSize.min, children: [
                      for (var i = 0; i < 3; i++)
                        Container(
                          width: 8,
                          height: 8,
                          margin: const EdgeInsets.only(right: 5),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Pal.accent.withAlpha((90 + 165 * (0.5 + 0.5 * math.sin(_c.value * 2 * math.pi - i * 0.9))).round().clamp(0, 255)),
                          ),
                        ),
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(
                          job == null ? tr('${AppConfig.appName} réfléchit…', '${AppConfig.appName} is thinking…') : (job.label.isEmpty ? tr('Travail en cours…', 'Working…') : job.label),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: Pal.text(context), fontSize: 14),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text('$secs s', style: TextStyle(color: Pal.muted(context), fontSize: 12.5, fontWeight: FontWeight.w700)),
                    ]),
                    if (job != null) ...[
                      const SizedBox(height: 10),
                      LinearProgressIndicator(value: job.fraction == 0 ? null : job.fraction, minHeight: 6, borderRadius: BorderRadius.circular(6)),
                    ],
                  ]);
                },
              ),
            ),
          ),
        ),
      ]),
    );
  }
}

/// Fichier choisi par l'utilisateur (nom + contenu en mémoire).
class AttachedFile {
  final String name;
  final Uint8List bytes;
  AttachedFile(this.name, this.bytes);
  int get size => bytes.length;
}

class _Pending {
  final String text;
  final AttachedFile? attach;
  final String mode;
  _Pending(this.text, this.attach, this.mode);
}

class _ImageView extends StatelessWidget {
  final String path;
  const _ImageView({required this.path});

  @override
  Widget build(BuildContext context) {
    final f = File(path);
    if (!f.existsSync()) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(tr('Image supprimée de ce téléphone.', 'Image deleted from this phone.'), style: TextStyle(color: Pal.muted(context), fontSize: 13)),
      );
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GestureDetector(
        onTap: () => showDialog<void>(
          context: context,
          builder: (_) => Dialog(
            insetPadding: const EdgeInsets.all(12),
            child: InteractiveViewer(child: Image.file(f)),
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.file(f, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Text(tr('Image illisible.', 'Unreadable image.'))),
        ),
      ),
    );
  }
}

class _FileActions extends StatelessWidget {
  final ChatMessage message;
  const _FileActions({required this.message});

  @override
  Widget build(BuildContext context) {
    final path = message.filePath!;
    final isArchive = message.kind == 'archive';
    final kb = message.fileSize > 0 ? ' · ${(message.fileSize / 1024).toStringAsFixed(message.fileSize > 102400 ? 0 : 1)} Ko' : '';
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (isArchive)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(children: [
              Icon(Icons.folder_zip, size: 20, color: Pal.accent2),
              const SizedBox(width: 8),
              Expanded(child: Text('${message.fileName ?? 'archive'}$kb', style: TextStyle(color: Pal.text(context), fontWeight: FontWeight.w600))),
            ]),
          ),
        OutlinedButton.icon(
          onPressed: () async {
            if (!File(path).existsSync()) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('Fichier introuvable sur ce téléphone.', 'File not found on this phone.'))));
              return;
            }
            await Share.shareXFiles([XFile(path)], text: message.fileName);
          },
          icon: const Icon(Icons.ios_share, size: 18),
          label: Text(tr('Enregistrer / Partager', 'Save / Share')),
        ),
      ]),
    );
  }
}
