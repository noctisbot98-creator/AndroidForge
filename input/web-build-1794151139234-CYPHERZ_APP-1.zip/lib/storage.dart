import 'dart:convert';
import 'package:flutter/material.dart';
import 'remote.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'config.dart';
import 'models.dart';

/// Stockage local (sur le téléphone) : réglages + historique des conversations.
class Store {
  static late SharedPreferences _p;
  static final ValueNotifier<ThemeMode> themeMode = ValueNotifier(ThemeMode.dark);
  /// Incrémenté à chaque changement d'apparence : l'application reconstruit son thème.
  static final ValueNotifier<int> look = ValueNotifier(0);
  static const _maxConversations = 60;
  static const _maxMessages = 300;

  static Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    themeMode.value = _parseTheme(_p.getString('theme'));
  }

  static ThemeMode _parseTheme(String? v) {
    switch (v) {
      case 'light':
        return ThemeMode.light;
      case 'system':
        return ThemeMode.system;
      default:
        return ThemeMode.dark;
    }
  }

  static String get baseUrl => AppConfig.defaultBaseUrl; // jamais modifiable ni affichée
  static String get account => _p.getString('account') ?? '';
  static bool get loggedIn => account.isNotEmpty;
  static String get userName => _p.getString('userName') ?? '';
  static String? raw(String k) => _p.getString(k);
  static Future<void> setRaw(String k, String v) async => _p.setString(k, v);
  static String get token => _p.getString('token') ?? '';
  /// Le choix du moteur d'IA est automatique (le serveur décide) : rien n'est exposé à l'utilisateur.
  static String get engine => 'auto';
  // ── Apparence ──
  static int get accentIndex => _p.getInt('accent') ?? 0;
  static String get bgStyle => _p.getString('bgStyle') ?? 'aurora'; // aurora | orbs | waves | plain
  static bool get bgAnimated => _p.getBool('bgAnim') ?? true;
  static double get bgIntensity => _p.getDouble('bgInt') ?? 0.8;
  static Future<void> setLook({int? accent, String? bgStyle, bool? animated, double? intensity}) async {
    if (accent != null) await _p.setInt('accent', accent);
    if (bgStyle != null) await _p.setString('bgStyle', bgStyle);
    if (animated != null) await _p.setBool('bgAnim', animated);
    if (intensity != null) await _p.setDouble('bgInt', intensity);
    look.value++;
  }
  static String get style => _p.getString('style') ?? 'normal';
  static double get fontScale => _p.getDouble('fontScale') ?? 1.0;
  static Future<void> setToken(String t) async => _p.setString('token', t);
  static Future<void> setStyle(String v) async => _p.setString('style', v);
  static Future<void> setFontScale(double v) async => _p.setDouble('fontScale', v);
  /// Personnalité + style de réponse choisi.
  static String get effectivePersona => persona + (AppConfig.styleHints[style] ?? '');
  static String get persona => _p.getString('persona') ?? Remote.defaultPersona;

  static Future<void> setAccount(String mail) async => _p.setString('account', mail.trim());

  static Future<void> setProfile({String? userName, String? persona}) async {
    if (userName != null) await _p.setString('userName', userName.trim());
    if (persona != null) await _p.setString('persona', persona.trim());
  }

  static Future<void> setTheme(ThemeMode mode) async {
    themeMode.value = mode;
    await _p.setString('theme', mode == ThemeMode.light ? 'light' : mode == ThemeMode.system ? 'system' : 'dark');
  }

  static List<Conversation> loadConversations() {
    try {
      final raw = _p.getString('conversations');
      if (raw == null || raw.isEmpty) return <Conversation>[];
      final list = jsonDecode(raw) as List;
      final convs = list
          .whereType<Map>()
          .map((m) => Conversation.fromJson(Map<String, dynamic>.from(m)))
          .toList();
      convs.sort((a, b) => b.updated.compareTo(a.updated));
      return convs;
    } catch (_) {
      return <Conversation>[]; // données corrompues : on repart de zéro plutôt que de planter
    }
  }

  static Future<void> saveConversations(List<Conversation> all) async {
    final keep = all.where((c) => c.messages.isNotEmpty).toList()
      ..sort((a, b) => b.updated.compareTo(a.updated));
    final trimmed = keep.take(_maxConversations).map((c) {
      final msgs = c.messages.length > _maxMessages
          ? c.messages.sublist(c.messages.length - _maxMessages)
          : c.messages;
      return Conversation(id: c.id, title: c.title, updated: c.updated, messages: msgs);
    }).toList();
    await _p.setString('conversations', jsonEncode(trimmed.map((c) => c.toJson()).toList()));
  }

  static Future<void> clearHistory() async => _p.remove('conversations');

  static Future<void> logout() async {
    await _p.remove('account');
    await _p.remove('token');
    await _p.remove('accountCache');
  }
}
