import 'i18n.dart';
import 'package:flutter/material.dart';
import 'config.dart';
import 'remote.dart';
import 'theme.dart';
import 'widgets.dart';

/// Annonce de l'administrateur + alerte de nouvelle version (affichées en haut du chat).
class RemoteBanners extends StatelessWidget {
  const RemoteBanners({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: Remote.changed,
      builder: (context, _, __) {
        final items = <Widget>[];
        final a = Remote.announcement;
        if (a.isNotEmpty && a != Remote.dismissedAnnouncement) {
          items.add(_bar(context, Icons.campaign_outlined, a, const Color(0xFF0E7490), onClose: Remote.dismissAnnouncement));
        }
        if (Remote.canUpdate && Remote.apkUrl.isNotEmpty) {
          items.add(_bar(
            context,
            Icons.system_update_alt,
            Remote.updateMessage.isEmpty ? tr('Une nouvelle version de ${AppConfig.appName} est disponible.', 'A new version of ${AppConfig.appName} is available.') : Remote.updateMessage,
            const Color(0xFF4F46E5),
            action: tr('Télécharger', 'Download'),
            onAction: () => openUrl(context, Remote.apkUrl),
          ));
        }
        if (items.isEmpty) return const SizedBox.shrink();
        return Column(children: items);
      },
    );
  }

  Widget _bar(BuildContext context, IconData icon, String text, Color color,
      {VoidCallback? onClose, String? action, VoidCallback? onAction}) {
    return Container(
      width: double.infinity,
      color: color,
      padding: const EdgeInsets.fromLTRB(14, 8, 6, 8),
      child: Row(children: [
        Icon(icon, color: Colors.white, size: 20),
        const SizedBox(width: 10),
        Expanded(child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 13.5))),
        if (action != null)
          TextButton(
            onPressed: onAction,
            child: Text(action, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
          ),
        if (onClose != null)
          IconButton(icon: const Icon(Icons.close, color: Colors.white, size: 18), onPressed: onClose),
      ]),
    );
  }
}

/// Mise à jour obligatoire : bloque l'application tant que la nouvelle version n'est pas installée.
class UpdateScreen extends StatelessWidget {
  const UpdateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const BrandMark(size: 72),
              const SizedBox(height: 20),
              Text(tr('Mise à jour requise', 'Update required'),
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Pal.text(context))),
              const SizedBox(height: 10),
              Text(
                Remote.updateMessage.isEmpty
                    ? tr('Une nouvelle version de ${AppConfig.appName} est nécessaire pour continuer.', 'A new version of ${AppConfig.appName} is required to continue.')
                    : Remote.updateMessage,
                textAlign: TextAlign.center,
                style: TextStyle(color: Pal.muted(context), fontSize: 15),
              ),
              const SizedBox(height: 24),
              if (Remote.apkUrl.isNotEmpty)
                FilledButton.icon(
                  onPressed: () => openUrl(context, Remote.apkUrl),
                  icon: const Icon(Icons.download),
                  label: Text(tr('Télécharger la mise à jour', 'Download the update')),
                )
              else
                OutlinedButton.icon(
                  onPressed: () => contactAdmin(context),
                  icon: const Icon(Icons.chat_outlined),
                  label: Text(tr('Contacter l\'administrateur', 'Contact the administrator')),
                ),
            ]),
          ),
        ),
      ),
    );
  }
}
