class ChatMessage {
  final String role; // 'user' ou 'assistant'
  String text;
  final DateTime time;
  bool error;
  bool quota; // erreur de quota : proposer de contacter l'administrateur
  String kind; // 'text' | 'image' | 'archive'
  String? filePath; // fichier téléchargé sur le téléphone (image ou archive)
  String? fileName;
  int fileSize;
  List<String> models; // conservé pour compatibilité (jamais affiché)
  int ms; // durée de la réponse en millisecondes (0 = inconnue)

  ChatMessage({
    required this.role,
    required this.text,
    DateTime? time,
    this.error = false,
    this.quota = false,
    this.kind = 'text',
    this.filePath,
    this.fileName,
    this.fileSize = 0,
    this.models = const [],
    this.ms = 0,
  }) : time = time ?? DateTime.now();

  bool get isUser => role == 'user';

  Map<String, dynamic> toJson() => {
        'role': role,
        'text': text,
        'time': time.toIso8601String(),
        'error': error,
        'quota': quota,
        'kind': kind,
        'filePath': filePath,
        'fileName': fileName,
        'fileSize': fileSize,
        'models': models,
        'ms': ms,
      };

  factory ChatMessage.fromJson(Map<String, dynamic> j) => ChatMessage(
        role: (j['role'] as String?) ?? 'assistant',
        text: (j['text'] as String?) ?? '',
        time: DateTime.tryParse((j['time'] as String?) ?? ''),
        error: j['error'] == true,
        quota: j['quota'] == true,
        kind: (j['kind'] as String?) ?? 'text',
        filePath: j['filePath'] as String?,
        fileName: j['fileName'] as String?,
        fileSize: (j['fileSize'] as num?)?.toInt() ?? 0,
        models: ((j['models'] as List?) ?? const []).map((e) => e.toString()).toList(),
        ms: (j['ms'] as num?)?.toInt() ?? 0,
      );
}

class Conversation {
  final String id;
  String title;
  DateTime updated;
  final List<ChatMessage> messages;

  Conversation({
    required this.id,
    this.title = 'Nouvelle conversation',
    DateTime? updated,
    List<ChatMessage>? messages,
  })  : updated = updated ?? DateTime.now(),
        messages = messages ?? <ChatMessage>[];

  factory Conversation.create() =>
      Conversation(id: DateTime.now().microsecondsSinceEpoch.toString());

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'updated': updated.toIso8601String(),
        'messages': messages.map((m) => m.toJson()).toList(),
      };

  factory Conversation.fromJson(Map<String, dynamic> j) => Conversation(
        id: (j['id'] as String?) ?? DateTime.now().microsecondsSinceEpoch.toString(),
        title: (j['title'] as String?) ?? 'Conversation',
        updated: DateTime.tryParse((j['updated'] as String?) ?? ''),
        messages: ((j['messages'] as List?) ?? const [])
            .whereType<Map>()
            .map((m) => ChatMessage.fromJson(Map<String, dynamic>.from(m)))
            .toList(),
      );
}
