import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'storage.dart';

/// Langue de l'application : 'fr' ou 'en' (par défaut celle du téléphone).
class Lang {
  static final ValueNotifier<String> code = ValueNotifier('fr');

  static void init() {
    final saved = Store.raw('lang');
    if (saved == 'fr' || saved == 'en') {
      code.value = saved!;
    } else {
      final dev = WidgetsBinding.instance.platformDispatcher.locale.languageCode;
      code.value = dev == 'fr' ? 'fr' : 'en';
    }
  }

  static Future<void> set(String c) async {
    await Store.setRaw('lang', c);
    code.value = c;
  }

  static bool get en => code.value == 'en';
}

/// Texte traduit : `tr('Bonjour', 'Hello')`.
String tr(String fr, String en) => Lang.en ? en : fr;
