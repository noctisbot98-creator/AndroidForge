import 'package:flutter/material.dart';
import 'storage.dart';

/// Couleur d'accentuation proposée dans Réglages > Apparence.
class AccentPreset {
  final String fr;
  final String en;
  final Color a;
  final Color b;
  const AccentPreset(this.fr, this.en, this.a, this.b);
}

/// Palette professionnelle : la couleur d'accent est choisie par l'utilisateur (Réglages).
class Pal {
  static const presets = <AccentPreset>[
    AccentPreset('Indigo', 'Indigo', Color(0xFF6366F1), Color(0xFF14B8A6)),
    AccentPreset('Violet', 'Violet', Color(0xFF8B5CF6), Color(0xFFEC4899)),
    AccentPreset('Océan', 'Ocean', Color(0xFF3B82F6), Color(0xFF06B6D4)),
    AccentPreset('Émeraude', 'Emerald', Color(0xFF10B981), Color(0xFF84CC16)),
    AccentPreset('Orange', 'Orange', Color(0xFFF97316), Color(0xFFFBBF24)),
    AccentPreset('Rose', 'Pink', Color(0xFFEC4899), Color(0xFFA78BFA)),
    AccentPreset('Rubis', 'Ruby', Color(0xFFEF4444), Color(0xFFF59E0B)),
    AccentPreset('Or', 'Gold', Color(0xFFEAB308), Color(0xFFF97316)),
  ];

  static AccentPreset get preset {
    var i = Store.accentIndex;
    if (i < 0 || i >= presets.length) i = 0;
    return presets[i];
  }

  static Color get accent => preset.a;
  static Color get accent2 => preset.b;
  static Color get indigo => accent; // anciens noms
  static Color get teal => accent2;
  static Color get accentDeep => Color.lerp(accent, Colors.black, 0.28) ?? accent;
  static const danger = Color(0xFFF43F5E);
  static const ok = Color(0xFF22C55E);

  static LinearGradient get gradient => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [accent, accentDeep],
      );

  static bool isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;
  static Color bg(BuildContext c) => isDark(c) ? const Color(0xFF070B16) : const Color(0xFFF1F5F9);
  /// Cartes « verre » : légèrement transparentes pour laisser voir le fond animé.
  static Color surface(BuildContext c) => isDark(c) ? const Color(0xFF0F172A).withAlpha(188) : Colors.white.withAlpha(214);
  static Color surfaceHi(BuildContext c) => isDark(c) ? const Color(0xFF1B2745).withAlpha(210) : const Color(0xFFE6ECF6).withAlpha(230);
  static Color solid(BuildContext c) => isDark(c) ? const Color(0xFF0D1426) : Colors.white;
  static Color border(BuildContext c) => isDark(c) ? const Color(0xFF3B4C7A).withAlpha(120) : const Color(0xFFC9D3E4);
  static Color text(BuildContext c) => isDark(c) ? const Color(0xFFF1F5F9) : const Color(0xFF0F172A);
  static Color muted(BuildContext c) => isDark(c) ? const Color(0xFF9AA8C0) : const Color(0xFF64748B);
}

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final scheme = ColorScheme(
    brightness: b,
    primary: Pal.accent,
    onPrimary: Colors.white,
    secondary: Pal.accent2,
    onSecondary: Colors.white,
    error: Pal.danger,
    onError: Colors.white,
    surface: dark ? const Color(0xFF0F172A) : Colors.white,
    onSurface: dark ? const Color(0xFFF1F5F9) : const Color(0xFF0F172A),
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: Colors.transparent,
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.transparent,
      foregroundColor: dark ? const Color(0xFFF1F5F9) : const Color(0xFF0F172A),
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
    ),
    drawerTheme: DrawerThemeData(backgroundColor: dark ? const Color(0xFF0B1120) : Colors.white),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: dark ? const Color(0xFF18243E).withAlpha(200) : const Color(0xFFE8EDF5),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: Pal.accent,
        foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}
