import 'remote.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'api.dart';
import 'config.dart';
import 'i18n.dart';
import 'storage.dart';

/// Réponse de `/api/ai/chat`, `/image`, `/generate` ou `/project`.
class AiReply {
  final String type; // 'text' ou 'job'
  final String text;
  final List<String> models;
  final String? jobId;
  final String? kind; // 'image' | 'archive' | 'project'
  final String? note;
  AiReply({required this.type, this.text = '', this.models = const [], this.jobId, this.kind, this.note});
}

class JobInfo {
  final String id;
  final String kind;
  final String state; // running | done | error
  final int done;
  final int total;
  final String label;
  final String answer;
  final String error;
  final String? fileName;
  final String? fileMime;
  final int fileSize;
  JobInfo({
    required this.id,
    required this.kind,
    required this.state,
    this.done = 0,
    this.total = 1,
    this.label = '',
    this.answer = '',
    this.error = '',
    this.fileName,
    this.fileMime,
    this.fileSize = 0,
  });

  double get fraction => total <= 0 ? 0 : (done / total).clamp(0.0, 1.0).toDouble();

  factory JobInfo.fromJson(Map<String, dynamic> j) {
    final p = (j['progress'] is Map) ? Map<String, dynamic>.from(j['progress'] as Map) : <String, dynamic>{};
    final f = (j['file'] is Map) ? Map<String, dynamic>.from(j['file'] as Map) : null;
    return JobInfo(
      id: (j['id'] ?? '').toString(),
      kind: (j['kind'] ?? '').toString(),
      state: (j['state'] ?? 'running').toString(),
      done: (p['done'] as num?)?.toInt() ?? 0,
      total: (p['total'] as num?)?.toInt() ?? 1,
      label: (p['label'] ?? '').toString(),
      answer: (j['answer'] ?? '').toString(),
      error: (j['error'] ?? '').toString(),
      fileName: f?['name']?.toString(),
      fileMime: f?['mime']?.toString(),
      fileSize: (f?['size'] as num?)?.toInt() ?? 0,
    );
  }
}

/// Client des routes IA du serveur Cypher Z (`/api/ai/...`). Authentifié par la session du compte : aucune clé n'est stockée dans l'application.
class AiApi {
  final String baseUrl;
  AiApi({required this.baseUrl});

  Map<String, String> _h([Map<String, String>? extra]) => {'Authorization': 'Bearer ${Store.token}', ...?extra};

  Uri _uri(String path, [Map<String, String>? q]) =>
      Uri.parse('${ZidaneApi.normalizeBase(baseUrl)}/api/ai$path').replace(queryParameters: q);

  Map<String, dynamic> _decode(http.Response res) {
    Map<String, dynamic>? json;
    try {
      final d = jsonDecode(utf8.decode(res.bodyBytes));
      if (d is Map<String, dynamic>) json = d;
    } catch (_) {}
    final msg = (json?['message'] ?? json?['error'])?.toString();
    final quota = res.statusCode == 429 && (msg?.contains(Remote.adminWhatsapp) ?? false);
    if (res.statusCode == 401) throw ApiException(msg ?? tr('Session expirée. Reconnectez-vous.', 'Session expired. Please sign in again.'), auth: true);
    if (res.statusCode == 403) throw ApiException(msg ?? tr('Accès refusé pour ce compte.', 'Access denied for this account.'));
    if (quota) throw ApiException(msg!, quota: true);
    if (res.statusCode == 404 && json == null) throw ApiException(tr('Fonction indisponible sur ce serveur.', 'Feature unavailable on this server.'));
    if (json == null) throw ApiException(tr('Erreur du serveur (${res.statusCode}). Réessayez dans un instant.', 'Server error (${res.statusCode}). Please try again shortly.'));
    if (json['status'] != true) throw ApiException(msg ?? tr('Erreur (${res.statusCode}).', 'Error (${res.statusCode}).'));
    return json;
  }

  Future<http.Response> _send(Future<http.Response> Function() f, {int seconds = 90}) async {
    try {
      return await f().timeout(Duration(seconds: seconds));
    } on TimeoutException {
      throw ApiException(tr('Le serveur met trop de temps à répondre. Réessayez.', 'The server is taking too long to respond. Please try again.'));
    } on SocketException {
      throw ApiException(tr('Connexion impossible. Vérifiez votre internet puis réessayez.', 'Cannot connect. Check your internet and try again.'));
    } on http.ClientException {
      throw ApiException(tr('Connexion impossible. Vérifiez votre internet puis réessayez.', 'Cannot connect. Check your internet and try again.'));
    }
  }

  AiReply _reply(Map<String, dynamic> j) => AiReply(
        type: (j['type'] ?? 'text').toString(),
        text: (j['resultado'] ?? '').toString().trim(),
        models: ((j['models'] as List?) ?? const []).map((e) => e.toString()).toList(),
        jobId: j['jobId']?.toString(),
        kind: j['kind']?.toString(),
        note: j['note']?.toString(),
      );

  Future<AiReply> chat({required String text, required String history, required String persona, required String name, String mode = 'auto'}) async {
    final res = await _send(() => http.post(_uri('/chat'),
        headers: _h({'Content-Type': 'application/json'}),
        body: jsonEncode({'text': text, 'history': history, 'persona': persona, 'name': name, 'mode': mode, 'engine': Store.engine, 'lang': Lang.code.value})));
    return _reply(_decode(res));
  }

  Future<AiReply> image(String prompt) async {
    final res = await _send(() => http.post(_uri('/image'), headers: _h({'Content-Type': 'application/json'}), body: jsonEncode({'prompt': prompt})));
    return _reply(_decode(res));
  }

  Future<AiReply> generate(String request, {String format = 'zip'}) async {
    final res = await _send(() => http.post(_uri('/generate'), headers: _h({'Content-Type': 'application/json'}), body: jsonEncode({'request': request, 'format': format, 'lang': Lang.code.value})));
    return _reply(_decode(res));
  }

  Future<AiReply> project(Uint8List bytes, String question) async {
    final res = await _send(
        () => http.post(_uri('/project', {'question': question}), headers: _h({'Content-Type': 'application/octet-stream'}), body: bytes),
        seconds: 300);
    return _reply(_decode(res));
  }

  Future<JobInfo> job(String id) async {
    final res = await _send(() => http.get(_uri('/job/$id'), headers: _h()), seconds: 30);
    final j = _decode(res);
    return JobInfo.fromJson(Map<String, dynamic>.from(j['job'] as Map));
  }

  /// Attend la fin d'une tâche (sondage toutes les 2 s, jusqu'à 10 min).
  Future<JobInfo> waitJob(String id, {void Function(JobInfo)? onProgress}) async {
    final end = DateTime.now().add(const Duration(minutes: 10));
    var failures = 0;
    while (DateTime.now().isBefore(end)) {
      try {
        final j = await job(id);
        failures = 0;
        onProgress?.call(j);
        if (j.state == 'done') return j;
        if (j.state == 'error') throw ApiException(j.error.isEmpty ? tr('La tâche a échoué.', 'The task failed.') : j.error);
      } on ApiException {
        rethrow;
      } catch (_) {
        if (++failures >= 5) throw ApiException(tr('Connexion perdue pendant la tâche.', 'Connection lost during the task.'));
      }
      await Future<void>.delayed(const Duration(seconds: 2));
    }
    throw ApiException(tr('La tâche prend trop de temps. Réessayez avec un projet plus petit.', 'The task is taking too long. Try a smaller project.'));
  }

  /// Télécharge le fichier d'une tâche dans le dossier privé de l'application et renvoie son chemin.
  Future<String> download(String id, String fileName) async {
    final res = await _send(() => http.get(_uri('/download/$id'), headers: _h()), seconds: 120);
    if (res.statusCode != 200) {
      _decode(res);
      throw ApiException(tr('Téléchargement impossible (${res.statusCode}).', 'Download failed (${res.statusCode}).'));
    }
    final dir = await getApplicationDocumentsDirectory();
    final out = Directory('${dir.path}/zidane_ai');
    if (!await out.exists()) await out.create(recursive: true);
    final safe = fileName.replaceAll(RegExp(r'[^\w.\- ]'), '_');
    final file = File('${out.path}/${DateTime.now().millisecondsSinceEpoch}_$safe');
    await file.writeAsBytes(res.bodyBytes);
    return file.path;
  }
}
