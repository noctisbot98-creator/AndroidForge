import 'i18n.dart';
import 'remote.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'models.dart';

class ApiException implements Exception {
  final String message;
  final bool quota;
  final bool auth; // session expirée : il faut se reconnecter
  ApiException(this.message, {this.quota = false, this.auth = false});
  @override
  String toString() => message;
}

/// Outils communs (adresse du serveur, historique de conversation envoyé à chaque question).
class ZidaneApi {
  static const _maxTranscriptChars = 1800;
  static const _maxPersonaChars = 700;

  static String normalizeBase(String raw) {
    var u = raw.trim();
    if (u.isEmpty) u = AppConfig.defaultBaseUrl;
    if (!u.startsWith('http://') && !u.startsWith('https://')) u = 'http://$u';
    while (u.endsWith('/')) {
      u = u.substring(0, u.length - 1);
    }
    return u;
  }

  /// Texte envoyé : la question seule, ou un historique récent + consigne si la conversation a déjà des échanges.
  static String buildText(List<ChatMessage> history) {
    final msgs = history.where((m) => !m.error && m.text.trim().isNotEmpty).toList();
    if (msgs.isEmpty) return '';
    if (msgs.length == 1) return msgs.last.text.trim();
    final lines = <String>[];
    var total = 0;
    for (var i = msgs.length - 1; i >= 0; i--) {
      final m = msgs[i];
      var t = m.text.trim().replaceAll(RegExp(r'\s+'), ' ');
      if (t.length > 700) t = '${t.substring(0, 700)}…';
      final line = '${m.isUser ? 'Utilisateur' : 'Assistant'} : $t';
      if (total + line.length > _maxTranscriptChars && lines.isNotEmpty) break;
      total += line.length;
      lines.insert(0, line);
    }
    return 'Conversation en cours :\n${lines.join('\n')}\n\nRéponds uniquement au dernier message de l\'utilisateur.';
  }

  /// Historique récent (sans le dernier message) sous forme de lignes « Utilisateur : … / Assistant : … ».
  static String buildHistory(List<ChatMessage> previous, {int maxChars = 1800}) {
    final lines = <String>[];
    var total = 0;
    final msgs = previous.where((m) => !m.error && m.text.trim().isNotEmpty).toList();
    for (var i = msgs.length - 1; i >= 0; i--) {
      final m = msgs[i];
      var t = m.text.trim().replaceAll(RegExp(r'\s+'), ' ');
      if (t.length > 600) t = '${t.substring(0, 600)}…';
      final line = '${m.isUser ? 'Utilisateur' : 'Assistant'} : $t';
      if (total + line.length > maxChars && lines.isNotEmpty) break;
      total += line.length;
      lines.insert(0, line);
    }
    return lines.join('\n');
  }
}
