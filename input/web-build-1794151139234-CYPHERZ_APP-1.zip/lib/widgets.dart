import 'i18n.dart';
import 'package:flutter/material.dart';
import 'remote.dart';
import 'package:url_launcher/url_launcher.dart';
import 'config.dart';
import 'theme.dart';
import 'account.dart';
import 'background.dart';

/// Logo de l'application, avec un halo de la couleur choisie.
class BrandMark extends StatelessWidget {
  final double size;
  final bool glow;
  const BrandMark({super.key, this.size = 40, this.glow = false});

  @override
  Widget build(BuildContext context) {
    final img = SizedBox(
      width: size,
      height: size,
      child: ClipOval(child: Image.asset('assets/icon.png', width: size, height: size, fit: BoxFit.cover, filterQuality: FilterQuality.medium)),
    );
    if (!glow) return img;
    return Container(
      decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [BoxShadow(color: Pal.accent.withAlpha(120), blurRadius: size * 0.5, spreadRadius: size * 0.04)]),
      child: img,
    );
  }
}

/// Page avec le fond animé derrière (à utiliser à la place de Scaffold).
class AppScaffold extends StatelessWidget {
  final PreferredSizeWidget? appBar;
  final Widget body;
  final Widget? drawer;
  const AppScaffold({super.key, this.appBar, required this.body, this.drawer});

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const Positioned.fill(child: AppBackground()),
        Scaffold(backgroundColor: Colors.transparent, appBar: appBar, drawer: drawer, body: body),
      ],
    );
  }
}

/// Carte « verre » (semi-transparente) pour garder le texte lisible sur le fond animé.
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final VoidCallback? onTap;
  const GlassCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.radius = 18, this.onTap});

  @override
  Widget build(BuildContext context) {
    final box = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: Pal.surface(context),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: Pal.border(context)),
      ),
      child: child,
    );
    if (onTap == null) return box;
    return GestureDetector(behavior: HitTestBehavior.opaque, onTap: onTap, child: box);
  }
}

/// Heure d'un message : 09:05.
String fmtTime(DateTime t) => '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

/// Durée d'une réponse : 3,2 s  /  1 min 05 s.
String fmtDur(int ms) {
  if (ms < 1000) return '${ms < 0 ? 0 : ms} ms';
  if (ms < 60000) {
    final v = (ms / 1000).toStringAsFixed(1);
    return '${Lang.en ? v : v.replaceAll('.', ',')} s';
  }
  final m = ms ~/ 60000;
  final sec = ((ms % 60000) ~/ 1000).toString().padLeft(2, '0');
  return '$m min $sec s';
}

/// Compteur de requêtes toujours visible (barre du haut du chat). Toucher = ouvrir le compte.
class UsageChip extends StatelessWidget {
  final VoidCallback onTap;
  const UsageChip({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AccountInfo?>(
      valueListenable: Account.info,
      builder: (context, a, _) {
        final color = a == null ? Pal.muted(context) : (a.remaining <= 0 ? Pal.danger : (a.low ? const Color(0xFFF59E0B) : Pal.accent2));
        final label = a == null ? '…' : (a.unlimited ? '∞' : '${a.remaining}');
        return GestureDetector(
          onTap: onTap,
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
            padding: const EdgeInsets.symmetric(horizontal: 11),
            decoration: BoxDecoration(
              color: Pal.surface(context),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: color.withAlpha(150)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.bolt_rounded, size: 16, color: color),
              const SizedBox(width: 3),
              Text(label, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: Pal.text(context))),
              const SizedBox(width: 4),
              Text(tr('requêtes', 'requests'), style: TextStyle(fontSize: 11.5, color: Pal.muted(context))),
            ]),
          ),
        );
      },
    );
  }
}

/// Grande carte « Requêtes » (compte, page API, menu).
class UsageCard extends StatelessWidget {
  final bool compact;
  const UsageCard({super.key, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AccountInfo?>(
      valueListenable: Account.info,
      builder: (context, a, _) {
        final used = a?.used ?? 0;
        final lim = a?.limit ?? 0;
        final color = a == null ? Pal.accent : (a.remaining <= 0 ? Pal.danger : (a.low ? const Color(0xFFF59E0B) : Pal.accent));
        return GlassCard(
          padding: EdgeInsets.all(compact ? 12 : 18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(Icons.bolt_rounded, color: color, size: compact ? 18 : 22),
              const SizedBox(width: 6),
              Text(tr('Requêtes', 'Requests'), style: TextStyle(color: Pal.muted(context), fontWeight: FontWeight.w700, fontSize: compact ? 12.5 : 13.5)),
              const Spacer(),
              if (a != null && a.premium)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: Pal.accent.withAlpha(50), borderRadius: BorderRadius.circular(10)),
                  child: Text('PREMIUM', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: Pal.accent)),
                ),
            ]),
            SizedBox(height: compact ? 6 : 10),
            if (a == null)
              Text(tr('Chargement…', 'Loading…'), style: TextStyle(color: Pal.muted(context)))
            else ...[
              Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(a.unlimited ? '∞' : '${a.remaining}',
                    style: TextStyle(fontSize: compact ? 26 : 38, fontWeight: FontWeight.w800, color: Pal.text(context), height: 1.0)),
                const SizedBox(width: 8),
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(a.unlimited ? tr('illimité · $used utilisées', 'unlimited · $used used') : tr('restantes sur $lim', 'left of $lim'),
                      style: TextStyle(color: Pal.muted(context), fontSize: compact ? 12 : 14)),
                ),
              ]),
              if (!a.unlimited) ...[
                SizedBox(height: compact ? 8 : 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: a.fraction,
                    minHeight: compact ? 6 : 9,
                    backgroundColor: Pal.surfaceHi(context),
                    valueColor: AlwaysStoppedAnimation<Color>(color),
                  ),
                ),
                if (!compact) ...[
                  const SizedBox(height: 8),
                  Text(tr('$used utilisées', '$used used'), style: TextStyle(color: Pal.muted(context), fontSize: 12.5)),
                ],
              ],
            ],
          ]),
        );
      },
    );
  }
}

Future<void> contactAdmin(BuildContext context) async {
  final uri = Uri.parse('https://wa.me/${Remote.adminWhatsapp}');
  final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
  if (!ok && context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(tr('Impossible d\'ouvrir WhatsApp. Numéro : ${Remote.adminWhatsappDisplay}', 'Cannot open WhatsApp. Number: ${Remote.adminWhatsappDisplay}'))),
    );
  }
}

Future<void> openUrl(BuildContext context, String url) async {
  final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  if (!ok && context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('Impossible d\'ouvrir $url', 'Cannot open $url'))));
  }
}

/// Bascule Français / English.
class LangToggle extends StatelessWidget {
  const LangToggle({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: Lang.code,
      builder: (context, c, _) => SegmentedButton<String>(
        showSelectedIcon: false,
        style: const ButtonStyle(visualDensity: VisualDensity.compact),
        segments: const [
          ButtonSegment(value: 'fr', label: Text('Français')),
          ButtonSegment(value: 'en', label: Text('English')),
        ],
        selected: {c},
        onSelectionChanged: (s) => Lang.set(s.first),
      ),
    );
  }
}
