import 'package:flutter/material.dart';
import 'account.dart';
import 'config.dart';
import 'screens/chat_screen.dart';
import 'screens/auth_screen.dart';
import 'banners.dart';
import 'i18n.dart';
import 'remote.dart';
import 'storage.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Store.init();
  Lang.init();
  await Remote.init();
  Account.loadCache();
  if (Store.loggedIn) Account.refresh();
  runApp(const ZidaneApp());
}

class ZidaneApp extends StatelessWidget {
  const ZidaneApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: Lang.code,
      builder: (context, lang, _) => ValueListenableBuilder<int>(
      valueListenable: Store.look,
      builder: (context, _, __) => ValueListenableBuilder<ThemeMode>(
      valueListenable: Store.themeMode,
      builder: (context, mode, _) => MaterialApp(
        key: ValueKey(lang),
        title: AppConfig.appName,
        debugShowCheckedModeBanner: false,
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        themeMode: mode,
        home: ValueListenableBuilder<int>(
          valueListenable: Remote.changed,
          builder: (context, _, __) => Remote.mustUpdate
              ? const UpdateScreen()
              : !Store.loggedIn
                  ? const AuthScreen()
                  : const ChatScreen(),
        ),
      ),
      ),
      ),
    );
  }
}
