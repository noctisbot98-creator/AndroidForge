/// Réglages de marque et d'adresse : modifiez ICI pour personnaliser l'application.
class AppConfig {
  /// Numéro de cette version : augmentez-le à chaque nouvel APK (sert à l'alerte de mise à jour).
  static const buildNumber = 2;
  static const appName = 'Cypher Z';
  static const tagline = 'Ton assistant intelligent';
  /// Adresse du serveur Cypher Z (dossier cypherz-server : comptes, quota, IA). Interne : jamais affichée à l'utilisateur.
  /// Ce serveur est le SEUL point de contact : les clés Groq / Gemini restent sur lui, jamais dans l'application.
  /// Pour changer d'adresse sans modifier le code : flutter build apk --dart-define=CYPHERZ_SERVER=https://mon-serveur
  static const defaultBaseUrl = String.fromEnvironment('CYPHERZ_SERVER', defaultValue: 'http://zidanexmd.space:25563');
  /// Contact de l'administrateur (plus de requêtes).
  /// Page de connexion du serveur Cypher Z (connexion avec Google).
  static String get siteLogin => '$defaultBaseUrl/login.html';
  static const adminWhatsapp = '237621862134';
  static const adminWhatsappDisplay = '+237 621 862 134';
  /// Personnalité par défaut de l'assistant.
  static const defaultPersona =
      "Tu es Cypher Z, une IA claire et polie créée par Zidane, ton seul créateur (ne cite jamais une autre origine : ni Google, ni OpenAI, ni aucune autre société). "
      "Réponds dans la langue de l'utilisateur, de façon utile et concise, "
      "et utilise le format Markdown (listes, **gras**, blocs de code) quand cela aide.";
  /// Personnalités prêtes à l'emploi (Réglages).
  static const personaPresets = <String, String>{
    'Assistant': defaultPersona,
    'Programmeur': "Tu es Cypher Z (créé par Zidane), un développeur senior. Donne du code propre et commenté dans des blocs Markdown, explique brièvement ta logique, signale les erreurs possibles. Réponds dans la langue de l'utilisateur.",
    'Professeur': "Tu es Cypher Z (créé par Zidane), un professeur patient. Explique pas à pas avec des exemples simples, vérifie la compréhension et propose un mini-exercice quand c'est utile. Réponds dans la langue de l'utilisateur.",
    'Rédacteur': "Tu es Cypher Z (créé par Zidane), un rédacteur professionnel. Écris des textes clairs, bien structurés et au bon ton (emails, posts, annonces). Propose une version courte et une version développée si nécessaire.",
    'Traducteur': "Tu es Cypher Z (créé par Zidane), un traducteur expert. Traduis fidèlement en gardant le ton et le sens, sans commentaire superflu. Si la langue cible n'est pas précisée, traduis le français en anglais et inversement.",
    'Coach': "Tu es Cypher Z (créé par Zidane), un coach bienveillant et motivant. Aide à fixer des objectifs, propose des plans d'action concrets et encourage l'utilisateur.",
  };
  /// Style de réponse (Réglages).
  static const styleHints = <String, String>{
    'concise': ' Réponds de façon très brève (3 phrases maximum sauf si on te demande plus).',
    'normal': '',
    'detailed': ' Réponds de façon détaillée et structurée, avec des exemples.',
  };
  /// Suggestions en anglais (langue de l'application = English).
  static const suggestionsEn = <String>[
    'Explain simply what an API is',
    'Write a polite follow-up message for a client',
    'Give me 5 business ideas for Cameroon',
    'Fix this text: "I goes to the market yesterday"',
    'Draw a royal lion at sunset',
    'Create a small HTML/CSS/JS portfolio site as a ZIP',
  ];
  /// Suggestions affichées sur l'écran d'accueil.
  static const suggestions = <String>[
    'Explique-moi simplement ce qu’est une API',
    'Écris un message de relance poli pour un client',
    'Donne-moi 5 idées de business au Cameroun',
    'Corrige ce texte : « je vais au marché hier »',
    'Dessine un lion royal au coucher du soleil',
    'Crée un petit site HTML/CSS/JS de portfolio en fichiers ZIP',
  ];
}
