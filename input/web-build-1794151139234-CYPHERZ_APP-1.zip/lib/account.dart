import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'storage.dart';

/// Compte de l'utilisateur : nom, e-mail et nombre de requêtes.
class AccountInfo {
  final String username;
  final String mail;
  final int used;
  final int limit;
  final bool premium;
  const AccountInfo({required this.username, required this.mail, required this.used, required this.limit, required this.premium});

  bool get unlimited => limit >= 100000;
  int get remaining => unlimited ? 1000000 : (limit - used < 0 ? 0 : limit - used);
  double get fraction => (unlimited || limit <= 0) ? 0.0 : (used / limit).clamp(0.0, 1.0).toDouble();
  bool get low => !unlimited && limit > 0 && remaining <= (limit * 0.15).ceil();

  Map<String, dynamic> toJson() => {'username': username, 'mail': mail, 'used': used, 'limit': limit, 'premium': premium};

  factory AccountInfo.fromJson(Map<String, dynamic> j) => AccountInfo(
        username: (j['username'] ?? '').toString(),
        mail: (j['mail'] ?? '').toString(),
        used: (j['used'] as num?)?.toInt() ?? 0,
        limit: (j['limit'] as num?)?.toInt() ?? 0,
        premium: j['premium'] == true,
      );
}

class Account {
  static final ValueNotifier<AccountInfo?> info = ValueNotifier<AccountInfo?>(null);

  /// Dernière copie connue (affichage immédiat au lancement).
  static void loadCache() {
    try {
      final raw = Store.raw('accountCache');
      if (raw == null || raw.isEmpty) return;
      final d = jsonDecode(raw);
      if (d is Map) info.value = AccountInfo.fromJson(Map<String, dynamic>.from(d));
    } catch (_) {}
  }

  /// Relit le compte sur le serveur (silencieux en cas d'échec).
  static Future<AccountInfo?> refresh() async {
    if (Store.token.isEmpty) return info.value;
    try {
      final r = await http
          .get(Uri.parse('${AppConfig.defaultBaseUrl}/api/manageusers/user'), headers: {'Authorization': 'Bearer ${Store.token}'})
          .timeout(const Duration(seconds: 15));
      final j = jsonDecode(utf8.decode(r.bodyBytes));
      if (j is Map && j['status'] == true) {
        final u = j['user'] is Map ? Map<String, dynamic>.from(j['user'] as Map) : <String, dynamic>{};
        final ai = AccountInfo(
          username: (u['username'] ?? '').toString(),
          mail: (u['mail'] ?? Store.account).toString(),
          used: (u['uses'] as num?)?.toInt() ?? 0,
          limit: (j['CurrentLimit'] as num?)?.toInt() ?? 0,
          premium: u['isPremium'] == true,
        );
        info.value = ai;
        await Store.setRaw('accountCache', jsonEncode(ai.toJson()));
      }
    } catch (_) {}
    return info.value;
  }
}
