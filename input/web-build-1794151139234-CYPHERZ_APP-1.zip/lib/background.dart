import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'storage.dart';
import 'theme.dart';

final DateTime _t0 = DateTime.now();

/// Secondes écoulées depuis le lancement : toutes les pages lisent la même horloge, l'animation est donc continue d'un écran à l'autre.
double _clock() => DateTime.now().difference(_t0).inMilliseconds / 1000.0;

/// Fond animé (comme une vidéo en boucle) : aurore, bulles, vagues ou uni. Réglable dans Réglages > Apparence.
class AppBackground extends StatefulWidget {
  const AppBackground({super.key});

  @override
  State<AppBackground> createState() => _AppBackgroundState();
}

class _AppBackgroundState extends State<AppBackground> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 30));

  @override
  void initState() {
    super.initState();
    _sync();
    Store.look.addListener(_onLook);
  }

  void _onLook() {
    _sync();
    if (mounted) setState(() {});
  }

  void _sync() {
    final run = Store.bgAnimated && Store.bgStyle != 'plain';
    if (run) {
      if (!_c.isAnimating) _c.repeat();
    } else {
      _c.stop();
    }
  }

  @override
  void dispose() {
    Store.look.removeListener(_onLook);
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final style = Store.bgStyle;
    final k = Store.bgIntensity;
    final a = Pal.accent;
    final b = Pal.accent2;
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) => CustomPaint(
          size: Size.infinite,
          painter: _BgPainter(t: _clock(), style: style, a: a, b: b, k: k, dark: dark),
        ),
      ),
    );
  }
}

double _fr(double x) {
  final v = math.sin(x) * 43758.5453;
  return v - v.floorToDouble();
}

class _BgPainter extends CustomPainter {
  final double t;
  final String style;
  final Color a;
  final Color b;
  final double k;
  final bool dark;
  _BgPainter({required this.t, required this.style, required this.a, required this.b, required this.k, required this.dark});

  void _orb(Canvas canvas, double cx, double cy, double r, Color col, double al) {
    final rect = Rect.fromCircle(center: Offset(cx, cy), radius: r);
    final alpha = (255 * al).round().clamp(0, 255);
    final p = Paint()
      ..shader = RadialGradient(colors: [col.withAlpha(alpha), col.withAlpha(0)]).createShader(rect);
    canvas.drawCircle(Offset(cx, cy), r, p);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final base = dark ? const Color(0xFF070B16) : const Color(0xFFF1F5F9);
    canvas.drawRect(Offset.zero & size, Paint()..color = base);
    if (style == 'plain') return;
    final w = size.width;
    final h = size.height;
    if (w <= 0 || h <= 0) return;
    final al = (dark ? 0.50 : 0.30) * k;
    final s = t / 11.0;
    final mid = Color.lerp(a, b, 0.5) ?? a;

    if (style == 'orbs') {
      _orb(canvas, w * (0.25 + 0.2 * math.sin(s * 0.7)), h * (0.2 + 0.1 * math.cos(s * 0.5)), w * 0.8, a, al * 0.8);
      _orb(canvas, w * (0.8 + 0.1 * math.cos(s * 0.6)), h * (0.75 + 0.1 * math.sin(s * 0.8)), w * 0.8, b, al * 0.8);
      for (var i = 0; i < 16; i++) {
        final sp = 0.012 + 0.02 * _fr(i * 7.13);
        final r = 5 + 26 * _fr(i * 3.71);
        final x = w * _fr(i * 12.9898) + math.sin(t * 0.4 + i) * 14;
        final travel = h + 2 * r;
        final y = h + r - ((t * sp + _fr(i * 5.31)) % 1.0) * travel;
        final col = i.isEven ? a : b;
        _orb(canvas, x, y, r * 1.6, col, al * 1.1);
      }
      return;
    }

    if (style == 'waves') {
      _orb(canvas, w * (0.5 + 0.25 * math.sin(s * 0.5)), h * 0.12, w * 0.9, a, al * 0.7);
      for (var layer = 0; layer < 3; layer++) {
        final path = Path()..moveTo(0, h);
        final baseY = h * (0.58 + 0.12 * layer);
        final amp = h * (0.035 + 0.01 * layer);
        final freq = 1.0 + layer * 0.55;
        final speed = 0.45 + layer * 0.22;
        final dir = layer.isEven ? 1.0 : -1.0;
        for (double x = 0; x <= w + 8; x += 8) {
          final y = baseY + math.sin(x / w * 2 * math.pi * freq + dir * t * speed) * amp;
          path.lineTo(x, y);
        }
        path.lineTo(w, h);
        path.close();
        final col = layer == 1 ? b : (layer == 0 ? a : mid);
        final rect = Rect.fromLTWH(0, baseY - amp, w, h - baseY + amp);
        final alpha = (255 * al * (0.9 - layer * 0.18)).round().clamp(0, 255);
        final p = Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [col.withAlpha(alpha), col.withAlpha(0)],
          ).createShader(rect);
        canvas.drawPath(path, p);
      }
      return;
    }

    // aurora (par défaut)
    _orb(canvas, w * (0.2 + 0.25 * math.sin(s * 0.9)), h * (0.18 + 0.12 * math.cos(s * 0.7)), w * 0.95, a, al);
    _orb(canvas, w * (0.85 + 0.15 * math.cos(s * 0.6)), h * (0.45 + 0.2 * math.sin(s * 0.8 + 1)), w * 0.9, b, al * 0.9);
    _orb(canvas, w * (0.3 + 0.3 * math.sin(s * 0.5 + 2)), h * (0.85 + 0.1 * math.cos(s * 0.9)), w * 1.0, mid, al * 0.85);
    _orb(canvas, w * (0.7 + 0.2 * math.cos(s * 0.7 + 3)), h * (0.1 + 0.1 * math.sin(s)), w * 0.6, b, al * 0.6);
  }

  @override
  bool shouldRepaint(covariant _BgPainter old) => true;
}
