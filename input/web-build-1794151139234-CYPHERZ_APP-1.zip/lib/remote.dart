import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'i18n.dart';
import 'storage.dart';

/// Réglages lus sur le serveur (modifiables depuis le panneau admin, sans recompiler l'APK).
/// Valeur absente ou vide = valeur intégrée dans [AppConfig].
class Remote {
  static final ValueNotifier<int> changed = ValueNotifier(0);
  static Map<String, dynamic> _c = {};
  static String dismissedAnnouncement = '';

  static String _s(String k) => (_c[k] ?? '').toString().trim();
  static int _i(String k) => (_c[k] is num) ? (_c[k] as num).toInt() : int.tryParse(_s(k)) ?? 0;

  static String get tagline => _s('tagline').isEmpty ? tr(AppConfig.tagline, 'Your smart assistant') : _s('tagline');
  static String get announcement => _s('announcement');
  static String get defaultPersona => _s('defaultPersona').isEmpty ? AppConfig.defaultPersona : _s('defaultPersona');
  static String get adminWhatsapp => _s('adminWhatsapp').isEmpty ? AppConfig.adminWhatsapp : _s('adminWhatsapp');
  static String get adminWhatsappDisplay =>
      _s('adminWhatsappDisplay').isEmpty ? AppConfig.adminWhatsappDisplay : _s('adminWhatsappDisplay');
  static String get keyHelp => _s('keyHelp');
  static bool get signupEnabled => _c['signupEnabled'] != false;
  static int get latestVersion => _i('latestVersion');
  static int get minVersion => _i('minVersion');
  static String get apkUrl => _s('apkUrl');
  static String get updateMessage => _s('updateMessage');
  static bool get mustUpdate => minVersion > AppConfig.buildNumber;
  static bool get canUpdate => latestVersion > AppConfig.buildNumber;

  static List<String> get suggestions {
    final l = _c['suggestions'];
    if (l is List) {
      final r = l.map((e) => e.toString().trim()).where((e) => e.isNotEmpty).toList();
      if (r.isNotEmpty) return r;
    }
    return Lang.en ? AppConfig.suggestionsEn : AppConfig.suggestions;
  }

  static Map<String, String> get personaPresets {
    final m = _c['personas'];
    if (m is Map) {
      final r = <String, String>{};
      m.forEach((k, v) {
        if (k.toString().trim().isNotEmpty && v.toString().trim().isNotEmpty) r[k.toString()] = v.toString();
      });
      if (r.isNotEmpty) return r;
    }
    return AppConfig.personaPresets;
  }

  /// Charge la copie gardée sur le téléphone, puis tente de la rafraîchir (silencieux en cas d'échec).
  static Future<void> init() async {
    try {
      final raw = Store.raw('remoteConfig');
      if (raw != null && raw.isNotEmpty) {
        final d = jsonDecode(raw);
        if (d is Map<String, dynamic>) _c = d;
      }
    } catch (_) {}
    dismissedAnnouncement = Store.raw('dismissedAnnouncement') ?? '';
    changed.value++;
    refresh();
  }

  static Future<void> refresh() async {
    try {
      final r = await http.get(Uri.parse('${AppConfig.defaultBaseUrl}/api/app-config')).timeout(const Duration(seconds: 8));
      if (r.statusCode != 200) return;
      final d = jsonDecode(utf8.decode(r.bodyBytes));
      if (d is Map && d['config'] is Map) {
        _c = Map<String, dynamic>.from(d['config'] as Map);
        await Store.setRaw('remoteConfig', jsonEncode(_c));
        changed.value++;
      }
    } catch (_) {}
  }

  static Future<void> dismissAnnouncement() async {
    dismissedAnnouncement = announcement;
    await Store.setRaw('dismissedAnnouncement', dismissedAnnouncement);
    changed.value++;
  }
}
