package com.example.tunnel

import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import com.jcraft.jsch.ChannelDirectTCPIP
import com.jcraft.jsch.SocketFactory
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.InetAddress
import java.io.DataInputStream
import java.io.DataOutputStream
import java.util.concurrent.CopyOnWriteArrayList
import java.security.SecureRandom
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/** Client SSH DARK SURF. Le tunnel SSH fournit un SOCKS local consommé par Xray/TUN. */
object SshTunnel {
    private var session: Session? = null
    private var socksServer: ServerSocket? = null
    private val clients = CopyOnWriteArrayList<Socket>()
    private const val SOCKS_PORT = 10808

    @Synchronized fun start(p: SshProfile, mode: String) {
        stop()
        val jsch = JSch()
        val known = "[${p.host}]:${if (mode == "ssh-ws") p.wsPort else p.tcpPort} ${p.hostKey}\n"
        jsch.setKnownHosts(ByteArrayInputStream(known.toByteArray(Charsets.UTF_8)))
        val s = jsch.getSession(p.username, p.host, when (mode) {
            "ssh-ws" -> p.wsPort
            else -> p.tcpPort
        })
        s.setPassword(p.password)
        s.setConfig("StrictHostKeyChecking", "yes")
        s.setConfig("PreferredAuthentications", "password")
        s.setServerAliveInterval(25_000)
        s.setServerAliveCountMax(3)
        when (mode) {
            "ssh-ws" -> s.setSocketFactory(WebSocketSocketFactory(
                connectHost = p.host, port = p.wsPort, path = p.wsPath, httpHost = p.wsHost,
                tls = p.wsTls, sni = p.wsSni, payload = p.payload,
            ))
        }
        s.connect(20_000)
        session = s
        startSocksProxy(s)
    }

    @Synchronized fun stop() {
        runCatching { socksServer?.close() }; socksServer = null
        clients.forEach { runCatching { it.close() } }; clients.clear()
        runCatching { session?.disconnect() }; session = null
    }

    /** SOCKS5 local : chaque requête ouvre un canal SSH direct-tcpip (équivalent ssh -D). */
    private fun startSocksProxy(ssh: Session) {
        val server = ServerSocket()
        server.reuseAddress = true
        server.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), SOCKS_PORT))
        socksServer = server
        Thread({
            while (!server.isClosed && ssh.isConnected) {
                try {
                    val client = server.accept()
                    clients.add(client)
                    Thread({ handleSocksClient(client, ssh) }, "dark-surf-socks-client").apply { isDaemon = true; start() }
                } catch (_: Exception) { if (!server.isClosed) continue else break }
            }
        }, "dark-surf-socks-listener").apply { isDaemon = true; start() }
    }

    private fun handleSocksClient(client: Socket, ssh: Session) {
        var channel: ChannelDirectTCPIP? = null
        try {
            client.soTimeout = 20_000
            val input = DataInputStream(client.getInputStream())
            val output = DataOutputStream(client.getOutputStream())
            if (input.readUnsignedByte() != 5) throw java.io.IOException("socks_version")
            val methods = input.readUnsignedByte(); repeat(methods) { input.readUnsignedByte() }
            output.write(byteArrayOf(5, 0)); output.flush() // no-auth local proxy
            if (input.readUnsignedByte() != 5) throw java.io.IOException("socks_request")
            val command = input.readUnsignedByte(); input.readUnsignedByte() // RSV
            val atyp = input.readUnsignedByte()
            val host = when (atyp) {
                1 -> ByteArray(4).also(input::readFully).joinToString(".") { (it.toInt() and 255).toString() }
                3 -> ByteArray(input.readUnsignedByte()).also(input::readFully).toString(Charsets.UTF_8)
                4 -> ByteArray(16).also(input::readFully).let { InetAddress.getByAddress(it).hostAddress }
                else -> throw java.io.IOException("socks_address_type")
            }
            val port = input.readUnsignedShort()
            if (command != 1) { output.write(byteArrayOf(5, 7, 0, 1, 0, 0, 0, 0, 0, 0)); output.flush(); return }
            val ch = ssh.openChannel("direct-tcpip") as ChannelDirectTCPIP
            ch.setHost(host); ch.setPort(port); ch.setOrgIPAddress("127.0.0.1"); ch.setOrgPort(client.port)
            ch.connect(15_000); channel = ch
            output.write(byteArrayOf(5, 0, 0, 1, 0, 0, 0, 0, 0, 0)); output.flush()
            client.soTimeout = 0
            val upstreamIn = ch.inputStream; val upstreamOut = ch.outputStream
            val toSsh = Thread({ runCatching { client.getInputStream().copyTo(upstreamOut); upstreamOut.flush() } }, "dark-surf-socks-up").apply { isDaemon = true; start() }
            runCatching { upstreamIn.copyTo(client.getOutputStream()); client.getOutputStream().flush() }
            toSsh.interrupt()
        } catch (_: Exception) {
            runCatching { client.getOutputStream().write(byteArrayOf(5, 1, 0, 1, 0, 0, 0, 0, 0, 0)) }
        } finally {
            runCatching { channel?.disconnect() }; clients.remove(client); runCatching { client.close() }
        }
    }

    fun socksConfig(dns: String): String = org.json.JSONObject()
        .put("log", org.json.JSONObject().put("loglevel", "warning"))
        .put("inbounds", org.json.JSONArray().put(org.json.JSONObject().put("tag", "tun").put("protocol", "tun")
            .put("settings", org.json.JSONObject().put("mtu", 1400))
            .put("sniffing", org.json.JSONObject().put("enabled", true).put("destOverride", org.json.JSONArray().put("http").put("tls")))))
        .put("dns", org.json.JSONObject().put("servers", org.json.JSONArray().put("https://$dns/dns-query")).put("tag", "proxy"))
        .put("outbounds", org.json.JSONArray()
            .put(org.json.JSONObject().put("tag", "proxy").put("protocol", "socks")
                .put("settings", org.json.JSONObject().put("servers", org.json.JSONArray().put(org.json.JSONObject().put("address", "127.0.0.1").put("port", SOCKS_PORT)))))
            .put(org.json.JSONObject().put("tag", "direct").put("protocol", "freedom")))
        .put("routing", org.json.JSONObject().put("domainStrategy", "AsIs")).toString()

    /** Flux RFC6455 binaire (WS ou WSS) transparent pour JSch. L'IP, le SNI et Host HTTP sont séparés. */
    private class WebSocketSocketFactory(
        private val connectHost: String, private val port: Int, private val path: String,
        private val httpHost: String, private val tls: Boolean, private val sni: String, private val payload: String,
    ) : SocketFactory {
        override fun createSocket(hostIgnored: String?, portIgnored: Int): Socket = WsSocket(connectHost, port, path, httpHost, tls, sni, payload)
        override fun getInputStream(socket: Socket): InputStream = socket.getInputStream()
        override fun getOutputStream(socket: Socket): OutputStream = socket.getOutputStream()
    }

    private class WsSocket(
        connectHost: String, port: Int, path: String, httpHost: String, tlsEnabled: Boolean, sni: String, payload: String,
    ) : Socket() {
        private val transport: Socket = if (tlsEnabled) {
            (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket().also { raw ->
                val ssl = raw as SSLSocket
                ssl.connect(InetSocketAddress(connectHost, port), 15_000)
                ssl.sslParameters = ssl.sslParameters.apply { serverNames = listOf(javax.net.ssl.SNIHostName(sni)) }
                ssl.soTimeout = 15_000; ssl.startHandshake()
            }
        } else Socket().also { it.connect(InetSocketAddress(connectHost, port), 15_000); it.soTimeout = 15_000 }
        private val source: InputStream
        private val sink: OutputStream = transport.getOutputStream()
        private val random = SecureRandom()
        private var closed = false
        init {
            val keyBytes = ByteArray(16).also(random::nextBytes)
            val key = android.util.Base64.encodeToString(keyBytes, android.util.Base64.NO_WRAP)
            val crlf = "\r\n"
            val template = payload.trim().takeIf { it.isNotEmpty() }
                ?: "GET $path HTTP/1.1[crlf]Host: $httpHost[crlf]Upgrade: websocket[crlf][crlf]"
            var request = template.replace("[crlf]", crlf).replace("\\r\\n", crlf).trimEnd('\r', '\n')
            if (!request.startsWith("GET ", ignoreCase = true)) throw java.io.IOException("bad_ws_payload")
            if (!Regex("(?im)^Host:").containsMatchIn(request)) request += crlf + "Host: $httpHost"
            if (!Regex("(?im)^Upgrade:\\s*websocket").containsMatchIn(request)) request += crlf + "Upgrade: websocket"
            if (!Regex("(?im)^Connection:").containsMatchIn(request)) request += crlf + "Connection: Upgrade"
            if (!Regex("(?im)^Sec-WebSocket-Key:").containsMatchIn(request)) request += crlf + "Sec-WebSocket-Key: $key"
            if (!Regex("(?im)^Sec-WebSocket-Version:").containsMatchIn(request)) request += crlf + "Sec-WebSocket-Version: 13"
            sink.write((request + crlf + crlf).toByteArray(Charsets.US_ASCII)); sink.flush()
            val header = ByteArrayOutputStream(); var state = 0
            while (header.size() < 8192 && state < 4) {
                val b = transport.getInputStream().read(); if (b < 0) throw java.io.IOException("ws_handshake_eof")
                header.write(b)
                state = when (state) { 0 -> if (b == 13) 1 else 0; 1 -> if (b == 10) 2 else 0; 2 -> if (b == 13) 3 else 0; 3 -> if (b == 10) 4 else 0; else -> state }
            }
            if (!header.toString("UTF-8").startsWith("HTTP/1.1 101") && !header.toString("UTF-8").startsWith("HTTP/1.0 101"))
                throw java.io.IOException("ws_upgrade_rejected:" + header.toString("UTF-8").lineSequence().firstOrNull().orEmpty())
            transport.soTimeout = 0
            source = object : InputStream() {
                private var current = ByteArray(0); private var at = 0
                override fun read(): Int { val one = ByteArray(1); val n = read(one, 0, 1); return if (n < 0) -1 else one[0].toInt() and 255 }
                override fun read(b: ByteArray, off: Int, len: Int): Int {
                    if (len == 0) return 0
                    while (at >= current.size) {
                        val a = transport.getInputStream().read(); if (a < 0) return -1
                        val b0 = transport.getInputStream().read(); if (b0 < 0) return -1
                        val opcode = a and 15; var size = (b0 and 127).toLong()
                        if (size == 126L) size = ((transport.getInputStream().read().toLong() shl 8) or transport.getInputStream().read().toLong())
                        else if (size == 127L) { size = 0; repeat(8) { size = (size shl 8) or transport.getInputStream().read().toLong() } }
                        if ((b0 and 128) != 0) throw java.io.IOException("masked_server_frame")
                        if (size > 1_048_576) throw java.io.IOException("ws_frame_too_large")
                        val payloadBytes = ByteArray(size.toInt()); var pos = 0
                        while (pos < payloadBytes.size) { val n = transport.getInputStream().read(payloadBytes, pos, payloadBytes.size - pos); if (n < 0) throw java.io.IOException("ws_frame_eof"); pos += n }
                        when (opcode) {
                            8 -> return -1
                            9 -> { writeFrame(10, payloadBytes); continue }
                            10 -> continue
                            2, 0 -> { current = payloadBytes; at = 0 }
                            else -> continue
                        }
                    }
                    val n = minOf(len, current.size - at); System.arraycopy(current, at, b, off, n); at += n; return n
                }
            }
        }
        private fun writeFrame(opcode: Int, data: ByteArray) {
            val mask = ByteArray(4).also(random::nextBytes); val n = data.size
            val header = when { n < 126 -> byteArrayOf((0x80 or opcode).toByte(), (0x80 or n).toByte())
                n <= 65535 -> byteArrayOf((0x80 or opcode).toByte(), 0xFE.toByte(), (n ushr 8).toByte(), n.toByte())
                else -> ByteArray(10).also { it[0] = (0x80 or opcode).toByte(); it[1] = 0xFF.toByte(); for (i in 0..7) it[2+i] = (n.toLong() ushr (56 - i*8)).toByte() } }
            sink.write(header); sink.write(mask); val masked = data.copyOf()
            for (i in masked.indices) masked[i] = (masked[i].toInt() xor mask[i % 4].toInt()).toByte()
            sink.write(masked); sink.flush()
        }
        override fun getInputStream(): InputStream = source
        override fun getOutputStream(): OutputStream = object : OutputStream() {
            override fun write(b: Int) = write(byteArrayOf(b.toByte()), 0, 1)
            override fun write(b: ByteArray, off: Int, len: Int) {
                var pos = off; val end = off + len
                while (pos < end) { val n = minOf(16_384, end - pos); writeFrame(2, b.copyOfRange(pos, pos+n)); pos += n }
            }
            override fun flush() = sink.flush()
        }
        override fun connect(endpoint: java.net.SocketAddress?) { throw UnsupportedOperationException() }
        override fun close() { if (!closed) { closed = true; runCatching { transport.close() } } }
        override fun isConnected(): Boolean = transport.isConnected && !transport.isClosed
        override fun isClosed(): Boolean = closed || transport.isClosed
    }
}
