const net = require('node:net');
const crypto = require('node:crypto');

function acceptWebSocket(server, { path = '/ssh-ws', targetPort = 2222 } = {}) {
  server.on('upgrade', (req, client, head) => {
    if (new URL(req.url, 'http://localhost').pathname !== path) { client.destroy(); return; }
    const key = req.headers['sec-websocket-key'];
    if (!key || req.headers['upgrade']?.toLowerCase() !== 'websocket') { client.destroy(); return; }
    const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
    client.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
    const upstream = net.createConnection({ host: '127.0.0.1', port: targetPort });
    let buffer = Buffer.alloc(0), dead = false;
    const close = () => { if (dead) return; dead = true; client.destroy(); upstream.destroy(); };
    client.on('error', close); upstream.on('error', close); client.on('close', close); upstream.on('close', close);
    upstream.on('connect', () => {
      if (head?.length) buffer = Buffer.concat([buffer, head]);
      client.on('data', (chunk) => {
        buffer = Buffer.concat([buffer, chunk]);
        while (buffer.length >= 2) {
          const b0 = buffer[0], b1 = buffer[1], opcode = b0 & 15, masked = !!(b1 & 128);
          let len = b1 & 127, off = 2;
          if (len === 126) { if (buffer.length < 4) return; len = buffer.readUInt16BE(2); off = 4; }
          else if (len === 127) { if (buffer.length < 10) return; const n = buffer.readBigUInt64BE(2); if (n > 1_048_576n) return close(); len = Number(n); off = 10; }
          if (!masked) return close();
          if (buffer.length < off + 4 + len) return;
          const mask = buffer.subarray(off, off + 4); off += 4;
          const payload = Buffer.from(buffer.subarray(off, off + len)); buffer = buffer.subarray(off + len);
          for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i % 4];
          if (opcode === 8) return close();
          if (opcode === 9) { client.write(frame(10, payload)); continue; }
          if (opcode === 2 || opcode === 0) upstream.write(payload);
        }
      });
      upstream.on('data', (data) => { if (!dead) client.write(frame(2, data)); });
    });
  });
}
function acceptTcpPayload(port = 2223, targetPort = 2222) {
  const listener = net.createServer((client) => {
    client.setTimeout(15000);
    let header = Buffer.alloc(0), connected = false, upstream;
    const fail = () => { client.destroy(); if (upstream) upstream.destroy(); };
    client.on('error', fail); client.on('timeout', fail); client.on('close', () => upstream?.destroy());
    const onData = (chunk) => {
      if (connected) return;
      header = Buffer.concat([header, chunk]);
      if (header.length > 16384) return fail();
      const end = header.indexOf('\r\n\r\n');
      if (end < 0) return;
      const request = header.subarray(0, end).toString('latin1');
      if (!/^CONNECT\s+[^\s]+\s+HTTP\/1\.[01]/i.test(request.split('\r\n')[0] || '')) return fail();
      connected = true; client.removeListener('data', onData);
      const extra = header.subarray(end + 4);
      upstream = net.createConnection({ host: '127.0.0.1', port: targetPort });
      upstream.on('error', fail); upstream.on('close', () => client.destroy());
      upstream.on('connect', () => {
        client.write('HTTP/1.1 200 Connection Established\r\nProxy-Agent: DARK-SURF\r\n\r\n');
        client.setTimeout(0);
        if (extra.length) upstream.write(extra);
        client.pipe(upstream); upstream.pipe(client);
      });
    };
    client.on('data', onData);
  });
  listener.listen(port, '0.0.0.0');
  return listener;
}

function frame(opcode, data) {
  const n = data.length; let h;
  if (n < 126) { h = Buffer.from([0x80 | opcode, n]); }
  else if (n <= 65535) { h = Buffer.alloc(4); h[0] = 0x80 | opcode; h[1] = 126; h.writeUInt16BE(n, 2); }
  else { h = Buffer.alloc(10); h[0] = 0x80 | opcode; h[1] = 127; h.writeBigUInt64BE(BigInt(n), 2); }
  return Buffer.concat([h, data]);
}
module.exports = { acceptWebSocket, acceptTcpPayload };
