const test = require('node:test');
const assert = require('node:assert/strict');
const { boot, fakeDevice, enroll, session } = require('./helpers');

test('session : renvoie les paramètres SSH-WS et SSH-TCP liés à un appareil', async () => {
  const t = await boot({ ssh: { enabled: true, secret: 'a'.repeat(64), hostKey: 'ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBFakeTestKey', tcpPort: 2222, wsPath: '/ssh-ws' } });
  try {
    // En test, on remplace seulement le helper système sudo/useradd ; l'API et la génération des identifiants restent réelles.
    t.app.service.setSshAccount = async () => {};
    const plan = t.addPlan({ quota: null }); const seller = t.addReseller('ssh-seller');
    const { codes } = t.app.service.generateCodes(seller, plan, 1, null);
    const device = fakeDevice(); const [, enrolled] = await enroll(t.base, codes[0], device);
    const [status, body] = await session(t.base, enrolled.device_id, device);
    assert.equal(status, 200);
    assert.equal(body.profile.protocol, 'vless');
    assert.equal(body.profile.ssh.tcp_port, 2222);
    assert.equal(body.profile.ssh.ws_port, 443);
    assert.equal(body.profile.ssh.ws_path, '/ssh-ws');
    assert.match(body.profile.ssh.username, /^ds[0-9a-f]{20}$/);
    assert.equal(body.profile.ssh.password.length, 32);
    assert.match(body.profile.ssh.host_key, /^ecdsa-sha2-nistp256 /);
    assert.notEqual(body.profile.ssh.username, t.app.service.sshCredentials('another-device').username);
  } finally { await t.close(); }
});

test('session : distribue SSH-TCP Payload avec son port dédié', async () => {
  const t = await boot({ protocols: { default: 'ssh-tcp-payload' }, ssh: { enabled: true, secret: 'p'.repeat(64), hostKey: 'ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBFakeTestKey', tcpPort: 2222, payloadPort: 2223, wsPath: '/ssh-ws' } });
  try {
    t.app.service.setSshAccount = async () => {};
    const plan = t.addPlan({ quota: null }); const seller = t.addReseller('ssh-payload');
    const { codes } = t.app.service.generateCodes(seller, plan, 1, null);
    const device = fakeDevice(); const [, enrolled] = await enroll(t.base, codes[0], device);
    const [status, body] = await session(t.base, enrolled.device_id, device);
    assert.equal(status, 200);
    assert.equal(body.profile.protocol, 'ssh-tcp-payload');
    assert.equal(body.profile.port, 2223);
    assert.equal(body.profile.ssh.payload_port, 2223);
    assert.equal(body.profile.ssh.tcp_port, 2222);
  } finally { await t.close(); }
});

test('SSH : le trafic des comptes SSH est compté dans le forfait, et la coupure retire le compte', async () => {
  const t = await boot({ ssh: { enabled: true, secret: 'b'.repeat(64), hostKey: 'ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBFakeTestKey', tcpPort: 2222, wsPath: '/ssh-ws' } });
  try {
    const calls = [];
    t.app.service.setSshAccount = async (id, on) => { calls.push([id, on]); };
    let total = 0;
    t.app.service.sshUsage = async () => { const m = new Map(); const c = t.app.service.sshCredentials(calls[0] ? calls[0][0] : 'x'); if (c) m.set(c.username, total); return m; };
    const plan = t.addPlan({ quota: 1000 }); const seller = t.addReseller('ssh-meter');
    const { codes } = t.app.service.generateCodes(seller, plan, 1, null);
    const device = fakeDevice(); const [, enrolled] = await enroll(t.base, codes[0], device);
    await session(t.base, enrolled.device_id, device);
    await t.app.service.enforce();
    assert.deepEqual(calls.at(-1), [enrolled.device_id, true]);
    total = 400; await t.app.service.enforce();
    assert.equal(t.q('SELECT used_bytes FROM devices').all()[0].used_bytes, 400);
    total = 1500; await t.app.service.enforce();                       // dépasse le quota : le compte est coupé
    assert.equal(t.q('SELECT used_bytes FROM devices').all()[0].used_bytes, 1500);
    assert.deepEqual(calls.at(-1), [enrolled.device_id, false]);
  } finally { await t.close(); }
});

test('SSH : lecture du compteur du pare-feu (nom octets), lignes invalides ignorées', async () => {
  const t = await boot({ ssh: { enabled: true, secret: 'c'.repeat(64), hostKey: 'ecdsa-sha2-nistp256 AAAA', tcpPort: 2222, wsPath: '/ssh-ws' } });
  try {
    t.app.service._sudoSsh = async () => 'ds0123456789abcdef0123 1500\nbruit\nds0123456789abcdef0123 500\nroot 9\n';
    const m = await t.app.service.sshUsage();
    assert.equal(m.get('ds0123456789abcdef0123'), 2000);
    assert.equal(m.size, 1);
  } finally { await t.close(); }
});

test('session et statut : le nom saisi par le vendeur sur la clé est renvoyé au client', async () => {
  const t = await boot();
  try {
    const plan = t.addPlan({ quota: null }); const seller = t.addReseller('nom-vendeur');
    const { codes } = t.app.service.generateCodes(seller, plan, 1, 'Jean Mballa');
    const device = fakeDevice(); const [, enrolled] = await enroll(t.base, codes[0], device);
    const [status, body] = await session(t.base, enrolled.device_id, device);
    assert.equal(status, 200);
    assert.equal(body.plan.client_name, 'Jean Mballa');
  } finally { await t.close(); }
});
