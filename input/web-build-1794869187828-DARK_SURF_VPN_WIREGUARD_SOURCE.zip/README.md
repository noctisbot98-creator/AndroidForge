# DARK_SURF (Android, Kotlin)

Client VPN : code TUN -> identité ECDSA (Android Keystore) -> session signée -> tunnel VPN WireGuard (GoBackend officiel) avec secours Xray/TUN et SSH.

- `app/` : application (ouvrir ce dossier dans Android Studio, puis éditer `API_BASE` dans `app/build.gradle.kts`).
- `server-mock/` : mock de l'API pour tester (`node server-mock/test.js`).
- `docs/API.md` : contrat client/serveur.
- Le backend expose `POST /api/v1/enroll`, `challenge`, `session`, `status` et `app/android`.
- Renseigner le vrai domaine HTTPS dans `app/build.gradle.kts` (`API_BASE`) avant compilation. Ne pas conserver le domaine d’exemple.
- AndroidForge : `preBuild` télécharge automatiquement `libv2ray.aar` (AndroidLibXrayLite v26.10.31). Aucun pré-build manuel n’est nécessaire.

Le tunnel utilise `com.wireguard.android:tunnel` (WireGuard-go userspace + VpnService).


## Refonte visuelle professionnelle — novembre 2026

- Identité DARK SURF unifiée : pétrole profond `#071412`, surfaces `#102522`, turquoise `#00D6B8`, cuivre `#E6A45B`, texte `#F1F5F2`.
- Contraste et hiérarchie visuelle harmonisés entre les deux applications.
- Architecture réseau conservée : WireGuard natif dans le client VPN, avec Xray/VLESS et SSH comme chemins de secours ; portail vendeur HTTPS pour DARK SURF PRO.
- Cette livraison est un projet Android source pour AndroidForge, pas un APK précompilé.


### Configuration réseau centralisée
Les transports VLESS, SSH-WS, SSH-TCP et SSH TCP Payload sont pilotés par le panel VPS. L'application ne présente aucun sélecteur de protocole ni formulaire de configuration réseau. Elle récupère le profil serveur à chaque connexion et applique le protocole choisi par l'administrateur.

### WireGuard intégré
- Moteur officiel `com.wireguard.android:tunnel:1.0.20260102` (GoBackend, sans root).
- Clé privée WireGuard générée localement et conservée dans le stockage chiffré AES-GCM.
- Le serveur lie la clé publique au premier appareil, attribue une IP privée et renvoie le profil signé.
- Si WireGuard n’est pas activé côté Admin/VPS, l’application conserve son tunnel Xray/SSH.
