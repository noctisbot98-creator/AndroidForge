# DARK SURF VPN — moteur WireGuard Android

Le client embarque la bibliothèque officielle `com.wireguard.android:tunnel` (GoBackend, sans root). À la première connexion, il génère une paire de clés sur l'appareil ; la clé privée est enregistrée dans le stockage AES-GCM existant (`SecureStore`) et n'est jamais envoyée. Seule la clé publique accompagne le défi signé `/session`. Le profil reçu est monté par GoBackend. Si le serveur n'a pas activé WireGuard ou ne renvoie pas de profil, le tunnel Xray historique reste le secours.

Dépendance : Maven Central `com.wireguard.android:tunnel:1.0.20260102`. Android compile avec Java 17 et core library desugaring, déjà activé dans le projet.
