package com.example.tunnel

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.BufferedReader
import java.io.StringReader

/** Moteur WireGuard officiel (wireguard-go, sans root). La clé privée ne quitte jamais le téléphone. */
class WireGuardEngine(context: Context) {
    private val backend = GoBackend(context.applicationContext)
    private val tunnel = object : Tunnel {
        override fun getName(): String = "darksurf"
        override fun onStateChange(newState: Tunnel.State) { isUp = newState == Tunnel.State.UP }
    }
    @Volatile var isUp: Boolean = false
        private set

    fun start(privateKey: String, profile: WireGuardProfile) {
        require(privateKey.isNotBlank() && profile.serverPublicKey.isNotBlank()) { "wireguard_profile_invalid" }
        val configText = """[Interface]
PrivateKey = $privateKey
Address = ${profile.address}
DNS = ${profile.dns}
MTU = 1380

[Peer]
PublicKey = ${profile.serverPublicKey}
Endpoint = ${profile.endpoint}
AllowedIPs = ${profile.allowedIps}
PersistentKeepalive = ${profile.keepalive}
"""
        val config = Config.parse(BufferedReader(StringReader(configText)))
        backend.setState(tunnel, Tunnel.State.UP, config)
        isUp = true
    }

    fun stop() {
        runCatching { backend.setState(tunnel, Tunnel.State.DOWN, null) }
        isUp = false
    }
}
