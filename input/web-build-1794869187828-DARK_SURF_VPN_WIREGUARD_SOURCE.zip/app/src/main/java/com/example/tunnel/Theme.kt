package com.example.tunnel

import android.content.res.Resources
import android.graphics.Color
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Identité visuelle DARK SURF PRO : pétrole profond, turquoise et cuivre. */
object Ds {
    /** true = sombre, false = clair (fixé au démarrage de l'écran : MainActivity.applyTheme). */
    @Volatile var dark: Boolean = true
    private fun c(d: String, l: String) = Color.parseColor(if (dark) d else l)

    val BG get() = c("#071412", "#F1F7F5")
    val BG2 get() = c("#102522", "#E2EEEA")
    val SURFACE get() = c("#102522", "#FFFFFF")
    val SURFACE2 get() = c("#15312C", "#E9F3F0")
    val LINE get() = c("#28534A", "#C3D9D2")
    val ACCENT get() = c("#00D6B8", "#00907A")
    val ACCENT2 get() = c("#00A88F", "#00796A")
    val WARM get() = c("#E6A45B", "#B8761F")
    val OK get() = c("#00D6B8", "#00907A")
    val ON get() = c("#00D6B8", "#00907A")
    val TEXT get() = c("#F1F5F2", "#0B1F1B")
    val MUTED get() = c("#91AAA1", "#52706A")
    val DANGER get() = c("#FF6B6B", "#C62828")
    /** Texte posé sur un aplat d'accent. */
    val ON_ACCENT get() = c("#04100E", "#FFFFFF")
    /** Voile neutre translucide : blanc en sombre, encre en clair. */
    fun veil(alpha: Int): Int = if (dark) Color.argb(alpha, 255, 255, 255) else Color.argb(alpha, 11, 31, 27)
    /** Style des boîtes de dialogue système. */
    val dialog: Int get() = if (dark) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert

    // Mélange de styles : titres condensés, chiffres monospace, accroches serif italique, corps fin.
    val DISPLAY: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    val BLACK: Typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
    val BODY: Typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    val MONO: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    val SERIF: Typeface = Typeface.create("serif", Typeface.ITALIC)
}

val Int.dp: Int get() = (this * Resources.getSystem().displayMetrics.density).toInt()
val Float.dp: Float get() = this * Resources.getSystem().displayMetrics.density

/** Bilingue FR/EN, comme Geny. */
object Lang {
    @Volatile var fr: Boolean = Locale.getDefault().language == "fr"
    fun t(f: String, e: String) = if (fr) f else e
    fun locale(): Locale = if (fr) Locale.FRANCE else Locale.US
}

fun fmtBytes(b: Long): String {
    val unit = Lang.t("o", "B")
    val v = b.toDouble()
    return when {
        v >= 1e9 -> "%.2f G%s".format(v / 1e9, unit)
        v >= 1e6 -> "%.1f M%s".format(v / 1e6, unit)
        v >= 1e3 -> "%.0f k%s".format(v / 1e3, unit)
        else -> "$b $unit"
    }
}

fun fmtDuration(ms: Long): String {
    val s = ms / 1000
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

fun fmtDate(epochMs: Long, pattern: String = "d MMM yyyy"): String =
    SimpleDateFormat(pattern, Lang.locale()).format(Date(epochMs))
