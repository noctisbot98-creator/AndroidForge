package com.example.tunnel

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.InetEndpoint
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import com.wireguard.crypto.KeyPair
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(val start: Long, val end: Long, val rx: Long, val tx: Long)

/**
 * Orchestre : enrôlement -> session signée -> tunnel WireGuard (userspace, via VpnService).
 * Même logique que Geny (code d'activation, challenge signé, profil à durée limitée),
 * mais le tunnel est assuré par com.wireguard.android:tunnel.
 */
class TunnelManager private constructor(context: Context) {
    private val app = context.applicationContext
    private val store = SecureStore(app)
    private val api = Api()
    private val backend = GoBackend(app)

    private val tunnel = object : Tunnel {
        override fun getName() = "darksurf"
        override fun onStateChange(newState: Tunnel.State) { listener?.invoke(newState == Tunnel.State.UP) }
    }

    private val lock = Any()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var monitor: Job? = null

    @Volatile var listener: ((Boolean) -> Unit)? = null
    /** Appelé quand l'état du forfait change (nouvelle lecture du serveur). */
    @Volatile var onPlanChanged: (() -> Unit)? = null
    /** Raison du dernier arrêt automatique : expired | quota_exceeded | revoked | disabled (null = arrêt normal). */
    @Volatile var lastStop: String? = null
        private set
    @Volatile private var sessionBase = 0L
    @Volatile var connectedAt: Long = 0L
        private set

    // ---- état persistant ----
    private class State(
        val deviceId: String, val wgPrivate: String,
        var profile: Profile? = null, var expiresAt: Long = 0, var token: String? = null,
        var plan: Plan? = null, val history: MutableList<HistoryEntry> = mutableListOf(),
        var lastNotice: Int = 0,
    ) {
        fun toJson() = JSONObject().put("device_id", deviceId).put("wg_private", wgPrivate)
            .put("expires_at", expiresAt).put("token", token).put("last_notice", lastNotice)
            .put("history", JSONArray().also { a ->
                history.forEach { a.put(JSONObject().put("s", it.start).put("e", it.end).put("rx", it.rx).put("tx", it.tx)) }
            })
            .also { j ->
                profile?.let { j.put("profile", it.toJson()) }
                plan?.let { j.put("plan", it.toJson()) }
            }
    }

    private fun load(): State? = store.read()?.let {
        runCatching {
            val j = JSONObject(it)
            val h = j.optJSONArray("history") ?: JSONArray()
            State(
                j.getString("device_id"), j.getString("wg_private"),
                j.optJSONObject("profile")?.let(Profile::fromJson),
                j.optLong("expires_at"), j.optString("token").ifEmpty { null },
                j.optJSONObject("plan")?.let(Plan::fromJson),
                MutableList(h.length()) { i ->
                    h.getJSONObject(i).let { o -> HistoryEntry(o.getLong("s"), o.getLong("e"), o.getLong("rx"), o.getLong("tx")) }
                },
                j.optInt("last_notice"),
            )
        }.getOrNull()
    }

    private fun save(st: State) = store.write(st.toJson().toString())

    /** Lecture-modification-écriture atomique (le moniteur, la tâche de fond et l'écran écrivent le même fichier). */
    private fun <T> edit(block: (State) -> T): T? = synchronized(lock) { load()?.let { st -> block(st).also { save(st) } } }

    // ---- lecture (rapide, utilisable depuis le thread principal) ----
    fun isEnrolled() = load() != null
    fun isConnected() = backend.getState(tunnel) == Tunnel.State.UP
    fun deviceId(): String? = load()?.deviceId
    fun plan(): Plan? = load()?.plan
    fun isPlanOver(): Boolean = load()?.plan?.let { it.expiresAt in 1..(System.currentTimeMillis() / 1000) } == true
    fun history(): List<HistoryEntry> = load()?.history.orEmpty()

    /** (octets reçus, octets envoyés) de la session en cours. */
    suspend fun stats(): Pair<Long, Long> = withContext(Dispatchers.IO) {
        runCatching { backend.getStatistics(tunnel).let { it.totalRx() to it.totalTx() } }.getOrDefault(0L to 0L)
    }

    // ---- opérations ----
    suspend fun activate(rawCode: String) = withContext(Dispatchers.IO) {
        val code = ActivationCode.normalize(rawCode) ?: throw ApiException(ApiError.Rejected, "bad_code_format")
        val kp = KeyPair()
        val deviceId = api.enroll(code, kp.publicKey.toBase64(), "${Build.MANUFACTURER} ${Build.MODEL}")
        save(State(deviceId, kp.privateKey.toBase64()))
    }

    suspend fun connect() = withContext(Dispatchers.IO) {
        val st = load() ?: throw IllegalStateException("not_enrolled")
        val now = System.currentTimeMillis() / 1000
        lastStop = null
        val plan = st.plan
        if (st.profile == null || st.expiresAt - now < RENEW_MARGIN_S || plan == null || plan.expiresAt <= now) {
            // Toujours redemander une session si le forfait a pu changer (recharge, expiration) : le serveur tranche.
            val s = api.session(st.deviceId, networkType())
            edit { it.profile = s.profile; it.expiresAt = s.expiresAt; it.token = s.token; it.plan = s.plan }
        }
        val fresh = load()!!
        backend.setState(tunnel, Tunnel.State.UP, buildConfig(fresh.profile!!, fresh.wgPrivate))
        connectedAt = System.currentTimeMillis()
        sessionBase = 0L
        startMonitor()
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        monitor?.cancel(); monitor = null
        val (rx, tx) = runCatching { backend.getStatistics(tunnel).let { it.totalRx() to it.totalTx() } }.getOrDefault(0L to 0L)
        backend.setState(tunnel, Tunnel.State.DOWN, null)
        val start = connectedAt
        connectedAt = 0L; sessionBase = 0L
        if (start > 0) edit { st ->
            st.history.add(0, HistoryEntry(start, System.currentTimeMillis(), rx, tx))
            while (st.history.size > 50) st.history.removeAt(st.history.size - 1)
        }
    }

    /** Consommation affichée : valeur du serveur + trafic de la session depuis cette valeur. */
    fun liveUsed(plan: Plan, sessionTotal: Long) = plan.usedBytes + (sessionTotal - sessionBase).coerceAtLeast(0L)

    /**
     * Lit l'état du forfait chez le serveur (n'ouvre jamais l'accès), mémorise le forfait,
     * déclenche les notifications (forfait, données, annonces).
     */
    suspend fun refreshStatus(): StatusResponse = withContext(Dispatchers.IO) {
        val st = load() ?: throw IllegalStateException("not_enrolled")
        val r = api.status(st.deviceId, st.lastNotice)
        edit { it.plan = r.plan; it.lastNotice = maxOf(it.lastNotice, r.notices.maxOfOrNull { n -> n.id } ?: 0) }
        sessionBase = runCatching { backend.getStatistics(tunnel).let { it.totalRx() + it.totalTx() } }.getOrDefault(0L)
        PlanEvents.process(app, r)
        onPlanChanged?.invoke()
        r
    }

    /**
     * Tant que le tunnel est monté : date d'expiration vérifiée toutes les 5 s (arrêt à la seconde près),
     * état serveur (données, clé révoquée, recharge) toutes les 30 s. Le serveur coupe aussi l'accès de son côté :
     * ceci sert à arrêter proprement le VPN et à prévenir l'utilisateur.
     */
    private fun startMonitor() {
        monitor?.cancel()
        monitor = scope.launch {
            var lastPoll = System.currentTimeMillis()
            while (isActive) {
                delay(5_000)
                if (backend.getState(tunnel) != Tunnel.State.UP) break
                val plan = load()?.plan
                var stop: String? = null
                if (plan != null && plan.expiresAt > 0 && System.currentTimeMillis() / 1000 >= plan.expiresAt) {
                    stop = "expired"; PlanEvents.ended(app, "expired", plan)
                } else if (System.currentTimeMillis() - lastPoll >= STATUS_EVERY_MS) {
                    lastPoll = System.currentTimeMillis()
                    try { refreshStatus().takeIf { it.state != "active" }?.let { stop = it.state } }
                    catch (e: ApiException) { /* réseau indisponible : on réessaie au prochain tour */ }
                    catch (e: Exception) { /* idem */ }
                }
                stop?.let { reason ->
                    lastStop = reason
                    runCatching { disconnect() }
                    listener?.invoke(false)
                    return@launch
                }
            }
        }
    }

    suspend fun reset() = withContext(Dispatchers.IO) {
        monitor?.cancel(); monitor = null
        runCatching { backend.setState(tunnel, Tunnel.State.DOWN, null) }
        connectedAt = 0L
        store.clear(); DeviceIdentity.reset()
    }

    // ---- helpers ----
    private fun buildConfig(p: Profile, wgPrivate: String): Config {
        val iface = Interface.Builder()
            .excludeApplication(app.packageName)      // l'appli (API, mises à jour) ne passe jamais par le tunnel : ni quota, ni boucle
            .parsePrivateKey(wgPrivate)
            .parseAddresses(p.address)
            .parseDnsServers(p.dns)
            .parseMtu(p.mtu.toString())
            .build()
        val peer = Peer.Builder()
            .parsePublicKey(p.serverPublicKey)
            .setEndpoint(InetEndpoint.parse(p.endpoint))
            .parseAllowedIPs(p.allowedIps)
            .parsePersistentKeepalive(p.keepalive.toString())
            .build()
        return Config.Builder().setInterface(iface).addPeer(peer).build()
    }

    private fun networkType(): String {
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        return if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) "wifi" else "mobile"
    }

    companion object {
        private const val RENEW_MARGIN_S = 120L
        private const val STATUS_EVERY_MS = 30_000L
        @Volatile private var instance: TunnelManager? = null
        fun get(ctx: Context): TunnelManager = instance ?: synchronized(this) {
            instance ?: TunnelManager(ctx.applicationContext).also { instance = it }
        }
    }
}
