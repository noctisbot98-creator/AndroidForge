import java.net.URL
import java.util.Properties
import java.util.zip.ZipFile

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Clé de signature de TES versions (voir tools/make-keystore.sh). Sans elle, impossible de publier des mises à jour.
val ksProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "com.example.tunnel"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.tunnel"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.2.0"
        // Taille : le noyau Xray pèse très lourd par architecture. arm64 couvre presque tous les téléphones depuis 2017.
        ndk { abiFilters += listOf("arm64-v8a") }
        // URL de l'API configurable sans modifier le code source :
        // ./gradlew assembleDebug -PdarkSurfApiBase=https://vpn.example.net/api/v1/
        // ou variable d'environnement DARKSURF_API_BASE.
        val apiBase = (project.findProperty("darkSurfApiBase") as String?)
            ?: System.getenv("DARKSURF_API_BASE")
            ?: "https://15-235-111-58.sslip.io/api/v1/"
        require(apiBase.startsWith("https://")) { "DARK SURF API_BASE doit utiliser HTTPS" }
        buildConfigField("String", "API_BASE", "\"${apiBase.trimEnd('/')}/\"")
    }

    signingConfigs {
        create("release") {
            if (ksProps.containsKey("storeFile")) {
                storeFile = rootProject.file(ksProps.getProperty("storeFile"))
                storePassword = ksProps.getProperty("storePassword")
                keyAlias = ksProps.getProperty("keyAlias")
                keyPassword = ksProps.getProperty("keyPassword")
            }
        }
    }
    buildTypes {
        release {
            if (ksProps.containsKey("storeFile")) signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    buildFeatures { buildConfig = true }
    packaging {
        jniLibs { useLegacyPackaging = true }      // bibliothèques natives compressées dans l'APK : fichier bien plus léger
        resources { excludes += setOf("META-INF/*.kotlin_module", "DebugProbesKt.bin", "kotlin-tooling-metadata.json") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "17" }
}

// AndroidForge lance directement assembleDebug sans exécuter les étapes du workflow.
// Cette dépendance garantit que le moteur Xray est présent AVANT toute compilation.
val downloadXrayCore by tasks.registering {
    val aar = layout.projectDirectory.file("libs/libv2ray.aar")
    outputs.file(aar)
    doLast {
        val target = aar.asFile
        if (!target.exists() || target.length() < 10_000_000L) {
            target.parentFile.mkdirs()
            val tmp = File(target.parentFile, "libv2ray.aar.download")
            val url = URL("https://github.com/2dust/AndroidLibXrayLite/releases/download/v26.10.31/libv2ray.aar")
            try {
                url.openConnection().apply {
                    connectTimeout = 30_000
                    readTimeout = 180_000
                    setRequestProperty("User-Agent", "DARK-SURF-Android-Build")
                }.getInputStream().use { input -> tmp.outputStream().use { output -> input.copyTo(output) } }
                check(tmp.length() > 10_000_000L) { "Téléchargement libv2ray.aar incomplet" }
                ZipFile(tmp).use { zip ->
                    check(zip.getEntry("classes.jar") != null) { "Archive libv2ray.aar invalide" }
                }
                if (target.exists()) target.delete()
                check(tmp.renameTo(target)) { "Impossible d'installer libv2ray.aar" }
                logger.lifecycle("DARK SURF: moteur Xray Android téléchargé (${target.length()} octets)")
            } finally { tmp.delete() }
        } else {
            logger.lifecycle("DARK SURF: moteur Xray déjà présent")
        }
    }
}

tasks.named("preBuild").configure { dependsOn(downloadXrayCore) }

dependencies {
    // Noyau Xray pour Android (AndroidLibXrayLite) : placé dans app/libs/libv2ray.aar (voir tools/fetch-core.sh).
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar"))))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
}
