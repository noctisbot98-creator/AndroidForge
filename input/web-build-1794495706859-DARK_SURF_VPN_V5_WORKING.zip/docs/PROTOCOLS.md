# DARK SURF — état des protocoles

## État du paquet source reçu

| Protocole | État réel dans cette version |
|---|---|
| VLESS / WebSocket / TLS | Implémenté avec libv2ray/Xray |
| VLESS / REALITY | Paramètres présents côté serveur et client |
| VLESS / mKCP | Paramètres présents côté serveur et client |
| SSH-TCP | Non implémenté dans le client |
| SSH-WS | Non implémenté dans le client |
| SSH TCP Payload | Non implémenté dans le client |

Les trois modes SSH ne doivent pas être affichés comme disponibles tant que le transport SSH,
le routage TUN vers le proxy local et la configuration serveur correspondante n'ont pas été
intégrés et testés de bout en bout. Un champ Payload seul ne crée pas un tunnel.

## Architecture d'intégration requise

- SSH-TCP : client SSH embarqué, authentification par compte temporaire, tunnel SOCKS local,
  puis routage du trafic Android via le TUN existant.
- SSH-WS : même moteur SSH, encapsulé dans un transport WebSocket côté client et serveur.
- SSH TCP Payload : profil avec méthode, en-têtes et chaîne Payload validés côté serveur ;
  le moteur doit réellement appliquer ces octets à l'établissement du transport.
- Le serveur doit créer/révoquer les identifiants SSH selon l'état du forfait et du terminal,
  avec limites de sessions et suppression à l'expiration.

## Configuration de l'API Android

L'URL peut être remplacée au build sans éditer le code :

```bash
./gradlew assembleDebug -PdarkSurfApiBase=https://votre-hote/api/v1/
```

Ou définir `DARKSURF_API_BASE` dans l'environnement de compilation. HTTPS est obligatoire.
