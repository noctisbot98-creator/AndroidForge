#!/usr/bin/env bash
# Diagnostic complet du serveur DARK_SURF. Code de sortie 1 s'il y a au moins un échec.
#   sudo darksurf-doctor
set -uo pipefail
[ "$(id -u)" = 0 ] || exec sudo "$0" "$@"
G=$'\033[32m' Y=$'\033[33m' R=$'\033[31m' O=$'\033[0m'; [ -t 1 ] || { G="" Y="" R="" O=""; }
FAIL=0 WARN=0
ok()   { echo "  ${G}OK${O}    $*"; }
warn() { echo "  ${Y}ATTN${O}  $*"; WARN=$((WARN+1)); }
bad()  { echo "  ${R}ECHEC${O} $*"; FAIL=$((FAIL+1)); }

set -a; . /etc/darksurf/darksurf.env 2>/dev/null; set +a
DOMAIN="${PUBLIC_URL#https://}"; WG_PORT="${WG_ENDPOINT##*:}"; IFACE="${WG_IFACE:-wg0}"
echo "DARK_SURF · $(date '+%F %T %Z') · $DOMAIN"

echo "Services"
for u in darksurf caddy "wg-quick@$IFACE" darksurf-backup.timer; do
  systemctl is-active --quiet "$u" && ok "$u actif" || bad "$u arrêté (journalctl -u $u -n 50)"
done

echo "WireGuard"
if wg show "$IFACE" >/dev/null 2>&1; then
  ok "interface $IFACE active, port $(wg show "$IFACE" listen-port)/udp"
  ss -lun 2>/dev/null | grep -q ":$WG_PORT " && ok "UDP $WG_PORT en écoute" || bad "UDP $WG_PORT n'écoute pas"
  peers=$(wg show "$IFACE" peers | wc -l)
  recent=$(wg show "$IFACE" latest-handshakes | awk -v n="$(date +%s)" '$2>0 && n-$2<180 {c++} END{print c+0}')
  ok "$peers appareil(s) autorisé(s), $recent connecté(s) à l'instant (poignée de main < 3 min)"
else bad "interface $IFACE absente (systemctl status wg-quick@$IFACE)"; fi

echo "Routage et pare-feu"
[ "$(sysctl -n net.ipv4.ip_forward 2>/dev/null)" = 1 ] && ok "ip_forward activé" || bad "ip_forward désactivé : le tunnel ne routera rien"
nft list table inet darksurf 2>/dev/null | grep -q masquerade && ok "NAT + isolation des clients en place" || bad "table nftables darksurf absente (systemctl restart wg-quick@$IFACE)"
[ "$(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null)" = bbr ] && ok "BBR actif" || warn "BBR inactif (utile surtout pour l'API, pas bloquant)"
mtu=$(cat "/sys/class/net/$IFACE/mtu" 2>/dev/null); [ -n "$mtu" ] && ok "MTU du tunnel : $mtu"
if curl -fsS --max-time 6 -o /dev/null https://1.1.1.1 2>/dev/null; then ok "sortie Internet du serveur"; else bad "le serveur n'atteint pas Internet"; fi

echo "API et HTTPS"
curl -fsS --max-time 4 http://127.0.0.1:8080/healthz >/dev/null 2>&1 && ok "API locale" || bad "API locale muette (journalctl -u darksurf -n 50)"
if curl -fsS --max-time 8 "https://$DOMAIN/healthz" >/dev/null 2>&1; then
  ok "HTTPS public"
  end=$(echo | openssl s_client -servername "$DOMAIN" -connect "$DOMAIN:443" 2>/dev/null | openssl x509 -noout -enddate 2>/dev/null | cut -d= -f2)
  if [ -n "$end" ]; then
    days=$(( ( $(date -d "$end" +%s) - $(date +%s) ) / 86400 ))
    [ "$days" -ge 10 ] && ok "certificat valide encore $days jours (renouvelé automatiquement)" || warn "certificat : $days jours restants"
  fi
else bad "HTTPS public inaccessible (DNS, ports 80/443 du fournisseur ?)"; fi

echo "Système"
[ "$(timedatectl show -p NTPSynchronized --value 2>/dev/null)" = yes ] && ok "horloge synchronisée (expirations fiables)" || bad "horloge non synchronisée : les dates d'expiration seraient fausses"
free=$(df -Pm /var/lib/darksurf | awk 'NR==2{print $4}'); [ "$free" -ge 1024 ] && ok "disque libre : ${free} Mo" || warn "disque presque plein : ${free} Mo"
mem=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo); [ "$mem" -ge 200 ] && ok "mémoire disponible : ${mem} Mo" || warn "mémoire faible : ${mem} Mo"

echo "Base de données et sauvegardes"
if [ -f "$DB_PATH" ]; then
  r=$(runuser -u darksurf -- sqlite3 -readonly "$DB_PATH" "PRAGMA integrity_check" 2>&1 | head -1)
  [ "$r" = ok ] && ok "intégrité de la base" || bad "base de données : $r"
  last=$(ls -1t /var/backups/darksurf/darksurf-*.db.gz 2>/dev/null | head -1)
  if [ -n "$last" ]; then
    age=$(( ( $(date +%s) - $(stat -c %Y "$last") ) / 3600 ))
    [ "$age" -le 8 ] && ok "dernière sauvegarde il y a ${age} h" || warn "dernière sauvegarde il y a ${age} h"
  else warn "aucune sauvegarde pour l'instant (darksurf-backup)"; fi
else bad "base introuvable : $DB_PATH"; fi

echo
if [ "$FAIL" = 0 ]; then echo "${G}Tout est en ordre${O} ($WARN avertissement(s))."; else echo "${R}$FAIL problème(s) à corriger${O} ($WARN avertissement(s))."; fi
echo "Test de vitesse conseillé : sur un téléphone connecté au VPN, lance un test (fast.com / speedtest) ; comparer avec et sans VPN."
[ "$FAIL" = 0 ]
