#!/usr/bin/env bash
# =============================================================================
# DARK_SURF : installation complète du serveur sur un VPS Ubuntu 22.04/24.04 ou Debian 12.
#
#   sudo ./deploy/install.sh --domain vpn.mondomaine.com --email moi@mail.com [--admin patron]
#   sans domaine :  --domain auto   (utilise IP-du-VPS.sslip.io, gratuit)
#
# À lancer en root, depuis le dossier décompressé du serveur. Le script est RELANÇABLE :
# pour mettre à jour le serveur, décompresse la nouvelle version et relance-le (la base de données,
# les clés WireGuard et la configuration sont conservées).
#
# Ce qu'il met en place :
#   - WireGuard (noyau Linux, UDP 51820) + routage/NAT + MSS clamp + isolation des clients
#   - Node.js 22 (vérifié par SHA-256) + le serveur DARK_SURF (service systemd durci, démarrage auto)
#   - Caddy : HTTPS automatique (Let's Encrypt) devant l'API et les portails vendeur/admin
#   - Réglages réseau (IP forwarding, BBR + fq, tampons UDP), synchronisation de l'heure
#   - Sauvegardes de la base toutes les 6 h, commandes darksurf-admin / darksurf-doctor
# =============================================================================
set -euo pipefail

# ------------------------------------------------------------------ options
DOMAIN="" EMAIL="" ADMIN_LOGIN="" WG_PORT="" MTU="" SUBNET="" SKIP_DNS=0
usage() { sed -n '2,6p' "$0" | sed 's/^# \{0,1\}//'; exit "${1:-0}"; }
while [ $# -gt 0 ]; do
  case "$1" in
    --domain) DOMAIN="${2:-}"; shift 2 ;;
    --email) EMAIL="${2:-}"; shift 2 ;;
    --admin) ADMIN_LOGIN="${2:-}"; shift 2 ;;
    --wg-port) WG_PORT="${2:-}"; shift 2 ;;
    --mtu) MTU="${2:-}"; shift 2 ;;
    --subnet) SUBNET="${2:-}"; shift 2 ;;
    --skip-dns-check) SKIP_DNS=1; shift ;;
    -h|--help) usage 0 ;;
    *) echo "Option inconnue : $1" >&2; usage 1 ;;
  esac
done

C_OK=$'\033[32m' C_WARN=$'\033[33m' C_BAD=$'\033[31m' C_OFF=$'\033[0m'
[ -t 1 ] || { C_OK="" C_WARN="" C_BAD="" C_OFF=""; }
step() { echo; echo "${C_OK}==>${C_OFF} $*"; }
warn() { echo "${C_WARN}!! $*${C_OFF}" >&2; }
die()  { echo "${C_BAD}ERREUR : $*${C_OFF}" >&2; exit 1; }

[ "$(id -u)" = 0 ] || die "lance ce script en root (sudo)."
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
[ -f "$SRC/src/server.js" ] || die "lance-le depuis le dossier du serveur (src/server.js introuvable)."

# ------------------------------------------------------- configuration retenue
CONF=/etc/darksurf/install.conf
mkdir -p /etc/darksurf
# shellcheck disable=SC1090
[ -f "$CONF" ] && . "$CONF"
DOMAIN="${DOMAIN:-${SAVED_DOMAIN:-}}"; EMAIL="${EMAIL:-${SAVED_EMAIL:-}}"
ADMIN_LOGIN="${ADMIN_LOGIN:-${SAVED_ADMIN:-admin}}"; WG_PORT="${WG_PORT:-${SAVED_WG_PORT:-51820}}"
MTU="${MTU:-${SAVED_MTU:-1280}}"; SUBNET="${SUBNET:-${SAVED_SUBNET:-10.8.0.0/16}}"

if [ "$DOMAIN" = "auto" ]; then        # pas de domaine : adresse gratuite basée sur l'IP (ex. 15-235-111-58.sslip.io)
  AUTO_IP="$(curl -4fsS --max-time 8 https://api.ipify.org 2>/dev/null || curl -4fsS --max-time 8 https://ifconfig.me 2>/dev/null || true)"
  [[ "$AUTO_IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || die "impossible de déterminer l'IP publique pour --domain auto."
  DOMAIN="${AUTO_IP//./-}.sslip.io"
fi
[ -n "$DOMAIN" ] || die "--domain est obligatoire (ex. vpn.mondomaine.com, enregistrement DNS A vers l'IP du VPS)."
[ -n "$EMAIL" ]  || die "--email est obligatoire (pour le certificat HTTPS)."
[[ "$DOMAIN" =~ ^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,}$ ]] || die "nom de domaine invalide : $DOMAIN"
[[ "$EMAIL" =~ ^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$ ]] || die "adresse e-mail invalide."
[[ "$ADMIN_LOGIN" =~ ^[a-z0-9._-]{3,32}$ ]] || die "--admin : a-z 0-9 . _ - (3 à 32 caractères)."
[[ "$WG_PORT" =~ ^[0-9]+$ ]] && [ "$WG_PORT" -ge 1024 ] && [ "$WG_PORT" -le 65535 ] || die "--wg-port invalide."
[[ "$MTU" =~ ^[0-9]+$ ]] && [ "$MTU" -ge 1200 ] && [ "$MTU" -le 1420 ] || die "--mtu doit être entre 1200 et 1420."
[[ "$SUBNET" =~ ^10\.[0-9]+\.[0-9]+\.0/(16|17|18|19|20|21|22|23|24)$ ]] || die "--subnet : réseau privé 10.x.y.0/16 à /24 (ex. 10.8.0.0/16)."
SERVER_ADDR="$(echo "$SUBNET" | awk -F'[./]' '{print $1"."$2"."$3".1/"$5}')"

# ------------------------------------------------------------------ contrôles
step "Contrôles préalables"
[ -d /run/systemd/system ] || die "systemd est requis."
. /etc/os-release
case "${ID:-}:${VERSION_ID:-}" in
  ubuntu:22.04|ubuntu:24.04|ubuntu:25.*|debian:12|debian:13) ;;
  *) warn "système non testé (${PRETTY_NAME:-inconnu}) : Ubuntu 22.04/24.04 ou Debian 12 recommandés." ;;
esac
case "$(uname -m)" in x86_64) NODE_ARCH=x64 ;; aarch64) NODE_ARCH=arm64 ;; *) die "architecture non prise en charge : $(uname -m)" ;; esac
VIRT="$(systemd-detect-virt 2>/dev/null || true)"
case "$VIRT" in
  lxc|openvz|systemd-nspawn) die "virtualisation « $VIRT » : le noyau WireGuard n'y est généralement pas disponible. Choisis un VPS KVM." ;;
esac
MEM_MB=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
[ "$MEM_MB" -ge 480 ] || warn "mémoire faible (${MEM_MB} Mo)."
echo "Système : ${PRETTY_NAME:-?} · virtualisation : ${VIRT:-aucune/inconnue} · RAM : ${MEM_MB} Mo"

for p in 80 443; do
  if ss -ltn "sport = :$p" 2>/dev/null | grep -q LISTEN && ! ss -ltnp "sport = :$p" 2>/dev/null | grep -q caddy; then
    die "le port $p est déjà utilisé par un autre service (nginx, apache, x-ui…). Arrête-le avant d'installer."
  fi
done

step "Paquets système"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq --no-install-recommends ca-certificates curl gnupg xz-utils wireguard-tools nftables sqlite3 iproute2 openssl >/dev/null
# Module noyau WireGuard : intégré aux noyaux récents ; sinon paquet DKMS.
if ! modprobe wireguard 2>/dev/null; then
  apt-get install -y -qq wireguard >/dev/null || true
  modprobe wireguard 2>/dev/null || die "le noyau de ce VPS n'offre pas WireGuard. Utilise un VPS KVM avec un noyau Linux 5.6 ou plus."
fi
echo wireguard >/etc/modules-load.d/darksurf.conf
modprobe nf_conntrack 2>/dev/null || true
modprobe tcp_bbr 2>/dev/null && echo tcp_bbr >>/etc/modules-load.d/darksurf.conf || warn "BBR indisponible sur ce noyau (sans conséquence pour le tunnel)."

# DNS : le domaine doit pointer vers CE serveur, sinon le certificat HTTPS ne sera pas délivré.
if [ "$SKIP_DNS" = 0 ]; then
  step "Vérification DNS de $DOMAIN"
  PUB_IP="$(curl -4fsS --max-time 8 https://api.ipify.org 2>/dev/null || curl -4fsS --max-time 8 https://ifconfig.me 2>/dev/null || true)"
  DNS_IP="$(getent ahostsv4 "$DOMAIN" 2>/dev/null | awk '{print $1; exit}')"
  [ -n "$DNS_IP" ] || die "$DOMAIN ne se résout pas. Crée l'enregistrement DNS A vers ${PUB_IP:-IP-du-VPS} (sans proxy Cloudflare), attends quelques minutes puis relance."
  if [ -n "$PUB_IP" ] && [ "$DNS_IP" != "$PUB_IP" ]; then
    die "$DOMAIN pointe vers $DNS_IP mais ce serveur a l'adresse $PUB_IP. Corrige l'enregistrement A (DNS seulement, sans proxy) puis relance, ou utilise --skip-dns-check."
  fi
  echo "$DOMAIN → $DNS_IP ✔"
fi

# ------------------------------------------------------------------ Node.js 22
install_node() {
  local need=0
  if [ -x /usr/local/bin/node ]; then
    /usr/local/bin/node -e 'const [a,b]=process.versions.node.split(".").map(Number);process.exit(a>22||(a===22&&b>=13)?0:1)' || need=1
  else need=1; fi
  [ "$need" = 0 ] && { echo "Node.js $(/usr/local/bin/node -v) déjà installé ✔"; return; }
  local tmp base file; tmp="$(mktemp -d)"; base="https://nodejs.org/dist/latest-v22.x"
  curl -fsSL "$base/SHASUMS256.txt" -o "$tmp/SHASUMS256.txt"
  file="$(grep -oE "node-v22\.[0-9]+\.[0-9]+-linux-$NODE_ARCH\.tar\.xz" "$tmp/SHASUMS256.txt" | head -1)"
  [ -n "$file" ] || die "archive Node.js 22 introuvable."
  curl -fsSL "$base/$file" -o "$tmp/$file"
  (cd "$tmp" && grep " $file\$" SHASUMS256.txt | sha256sum -c - >/dev/null) || die "somme SHA-256 de Node.js incorrecte : téléchargement refusé."
  local dir="/opt/${file%.tar.xz}"
  rm -rf "$dir"; tar -xJf "$tmp/$file" -C /opt
  ln -sf "$dir/bin/node" /usr/local/bin/node
  rm -rf "$tmp"
  echo "Node.js $(/usr/local/bin/node -v) installé ✔"
}
step "Node.js 22"
install_node

# ------------------------------------------------------------------ Caddy
step "Caddy (HTTPS automatique)"
if ! command -v caddy >/dev/null; then
  apt-get install -y -qq --no-install-recommends debian-keyring debian-archive-keyring apt-transport-https >/dev/null 2>&1 || true
  curl -fsSL 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -fsSL 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' >/etc/apt/sources.list.d/caddy-stable.list
  apt-get update -qq && apt-get install -y -qq caddy >/dev/null
fi
echo "$(caddy version | head -1) ✔"

# ------------------------------------------------------------------ réglages noyau
step "Réglages réseau (forwarding, BBR, tampons UDP)"
cat >/etc/sysctl.d/99-darksurf.conf <<'EOF'
net.ipv4.ip_forward = 1
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
net.core.rmem_max = 26214400
net.core.wmem_max = 26214400
net.core.rmem_default = 1048576
net.core.wmem_default = 1048576
net.core.netdev_max_backlog = 5000
net.netfilter.nf_conntrack_max = 262144
net.ipv4.tcp_mtu_probing = 1
net.ipv4.conf.all.rp_filter = 2
EOF
sysctl -q --system 2>/dev/null || warn "certains réglages noyau n'ont pas pu être appliqués (sans gravité)."
# L'expiration des forfaits dépend de l'horloge : elle doit être synchronisée.
timedatectl set-ntp true 2>/dev/null || true

# ------------------------------------------------------------------ WireGuard
step "WireGuard"
umask 077
mkdir -p /etc/wireguard
[ -f /etc/wireguard/server.key ] || wg genkey >/etc/wireguard/server.key
wg pubkey </etc/wireguard/server.key >/etc/wireguard/server.pub
chmod 600 /etc/wireguard/server.key; chmod 644 /etc/wireguard/server.pub
umask 022

# Pare-feu du tunnel (table nftables dédiée, n'interfère pas avec le reste du système) :
#  - les clients ne joignent ni le serveur, ni les réseaux privés/métadonnées du fournisseur, ni les autres clients
#  - e-mail sortant (port 25) bloqué : évite le spam qui ferait suspendre le VPS
#  - MSS clamp : évite les connexions qui se bloquent sur les réseaux mobiles
cat >/etc/darksurf/firewall.nft <<EOF
table inet darksurf
delete table inet darksurf
table inet darksurf {
  chain input {
    type filter hook input priority -5; policy accept;
    iifname "wg0" ct state established,related accept
    iifname "wg0" icmp type echo-request accept
    iifname "wg0" drop
  }
  chain forward {
    type filter hook forward priority -5; policy accept;
    iifname "wg0" oifname "wg0" drop
    iifname "wg0" ip daddr { 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 169.254.0.0/16, 100.64.0.0/10, 127.0.0.0/8 } drop
    iifname "wg0" tcp dport 25 reject with tcp reset
    tcp flags syn / syn,rst iifname "wg0" tcp option maxseg size set rt mtu
    tcp flags syn / syn,rst oifname "wg0" tcp option maxseg size set rt mtu
    iifname "wg0" accept
    oifname "wg0" ct state established,related accept
  }
  chain postrouting {
    type nat hook postrouting priority srcnat; policy accept;
    ip saddr $SUBNET oifname != "wg0" masquerade
  }
}
EOF
nft -c -f /etc/darksurf/firewall.nft || die "règles de pare-feu invalides."

NEW_WG="$(mktemp)"
cat >"$NEW_WG" <<EOF
[Interface]
Address = $SERVER_ADDR
ListenPort = $WG_PORT
PrivateKey = $(cat /etc/wireguard/server.key)
MTU = $MTU
# Les clients ne sont PAS écrits ici : le serveur DARK_SURF les ajoute/retire (forfait, données, expiration).
PostUp = nft -f /etc/darksurf/firewall.nft
PostDown = nft delete table inet darksurf
EOF
chmod 600 "$NEW_WG"
if ! cmp -s "$NEW_WG" /etc/wireguard/wg0.conf 2>/dev/null; then
  install -m 600 "$NEW_WG" /etc/wireguard/wg0.conf
  WG_CHANGED=1
else WG_CHANGED=0; fi
rm -f "$NEW_WG"
systemctl enable wg-quick@wg0 >/dev/null 2>&1
if systemctl is-active --quiet wg-quick@wg0; then
  if [ "$WG_CHANGED" = 1 ]; then systemctl restart wg-quick@wg0; echo "WireGuard reconfiguré ✔"; else nft -f /etc/darksurf/firewall.nft; echo "WireGuard inchangé ✔"; fi
else systemctl start wg-quick@wg0; echo "WireGuard démarré ✔"; fi

# Pare-feu hôte : si ufw est actif, on ouvre uniquement ce qui est nécessaire.
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null; ufw allow "$WG_PORT/udp" >/dev/null
  ufw route allow in on wg0 >/dev/null 2>&1 || true
  echo "ufw : ports 80/tcp, 443/tcp, $WG_PORT/udp ouverts ✔"
fi

# ------------------------------------------------------------------ application
step "Serveur DARK_SURF"
id -u darksurf >/dev/null 2>&1 || useradd --system --home-dir /var/lib/darksurf --shell /usr/sbin/nologin darksurf
mkdir -p /opt/darksurf /var/lib/darksurf/releases /var/backups/darksurf
chown -R darksurf:darksurf /var/lib/darksurf /var/backups/darksurf; chmod 750 /var/lib/darksurf; chmod 700 /var/backups/darksurf
rm -rf /opt/darksurf/src /opt/darksurf/deploy
cp -a "$SRC/src" "$SRC/deploy" "$SRC/package.json" /opt/darksurf/
[ -f "$SRC/README.md" ] && cp -a "$SRC/README.md" /opt/darksurf/
[ -d "$SRC/docs" ] && { rm -rf /opt/darksurf/docs; cp -a "$SRC/docs" /opt/darksurf/; }
chown -R root:root /opt/darksurf; chmod -R go-w /opt/darksurf

ENVF=/etc/darksurf/darksurf.env
if [ ! -f "$ENVF" ]; then
  cat >"$ENVF" <<EOF
HOST=127.0.0.1
PORT=8080
DB_PATH=/var/lib/darksurf/darksurf.db
RELEASES_DIR=/var/lib/darksurf/releases
PUBLIC_URL=https://$DOMAIN
TRUST_PROXY=1
COOKIE_SECURE=1
WG_MODE=real
WG_IFACE=wg0
WG_SERVER_PUBKEY=$(cat /etc/wireguard/server.pub)
WG_ENDPOINT=$DOMAIN:$WG_PORT
WG_SUBNET=$SUBNET
WG_DNS="1.1.1.1, 9.9.9.9"
WG_MTU=$MTU
ENFORCE_INTERVAL_MS=5000
EOF
  echo "Configuration créée : $ENVF"
else
  # Mises à jour des seules valeurs liées à l'installation ; le reste est conservé.
  sed -i -e "s#^PUBLIC_URL=.*#PUBLIC_URL=https://$DOMAIN#" -e "s#^WG_ENDPOINT=.*#WG_ENDPOINT=$DOMAIN:$WG_PORT#" \
         -e "s#^WG_MTU=.*#WG_MTU=$MTU#" -e "s#^WG_SERVER_PUBKEY=.*#WG_SERVER_PUBKEY=$(cat /etc/wireguard/server.pub)#" "$ENVF"
  echo "Configuration existante conservée : $ENVF"
fi
chown root:darksurf "$ENVF"; chmod 640 "$ENVF"

cat >"$CONF" <<EOF
SAVED_DOMAIN="$DOMAIN"
SAVED_EMAIL="$EMAIL"
SAVED_ADMIN="$ADMIN_LOGIN"
SAVED_WG_PORT="$WG_PORT"
SAVED_MTU="$MTU"
SAVED_SUBNET="$SUBNET"
EOF
chmod 600 "$CONF"

cat >/etc/systemd/system/darksurf.service <<'EOF'
[Unit]
Description=DARK_SURF server (API client + portails vendeur/admin)
After=network-online.target wg-quick@wg0.service
Wants=network-online.target
Requires=wg-quick@wg0.service

[Service]
User=darksurf
Group=darksurf
WorkingDirectory=/opt/darksurf
EnvironmentFile=/etc/darksurf/darksurf.env
ExecStart=/usr/local/bin/node --disable-warning=ExperimentalWarning src/server.js
Restart=always
RestartSec=2
LimitNOFILE=65536

# `wg set` a besoin de CAP_NET_ADMIN ; tout le reste est verrouillé.
AmbientCapabilities=CAP_NET_ADMIN
CapabilityBoundingSet=CAP_NET_ADMIN
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX AF_NETLINK
RestrictNamespaces=true
LockPersonality=true
ReadWritePaths=/var/lib/darksurf

[Install]
WantedBy=multi-user.target
EOF

# Commandes d'administration
cat >/usr/local/bin/darksurf-admin <<'EOF'
#!/usr/bin/env bash
# Administration du serveur DARK_SURF (voir : darksurf-admin help)
set -euo pipefail
[ "$(id -u)" = 0 ] || exec sudo "$0" "$@"
args=("$@"); tmp=""
if [ "${1:-}" = "publish-release" ] && [ -n "${2:-}" ] && [ -f "$2" ]; then      # l'APK doit être lisible par l'utilisateur du service
  tmp="$(mktemp -d)"; chmod 755 "$tmp"; install -m 644 "$2" "$tmp/app.apk"; args[1]="$tmp/app.apk"
fi
set +e
runuser -u darksurf -- bash -c 'set -a; . /etc/darksurf/darksurf.env; set +a; cd /opt/darksurf && exec /usr/local/bin/node --disable-warning=ExperimentalWarning src/admin.js "$@"' _ "${args[@]}"
rc=$?
[ -n "$tmp" ] && rm -rf "$tmp"
exit $rc
EOF
cat >/usr/local/bin/darksurf-backup <<'EOF'
#!/usr/bin/env bash
# Sauvegarde cohérente de la base (à chaud), compressée, conservée 14 jours.
# Exécutée sous l'utilisateur du service pour ne jamais créer de fichiers appartenant à root dans la base.
set -euo pipefail
[ "$(id -u)" = 0 ] && exec runuser -u darksurf -- "$0" "$@"
set -a; . /etc/darksurf/darksurf.env; set +a
dest=/var/backups/darksurf
f="$dest/darksurf-$(date +%F-%H%M).db"
sqlite3 "$DB_PATH" ".backup '$f'"
gzip -f "$f"
find "$dest" -name 'darksurf-*.db.gz' -mtime +14 -delete
echo "Sauvegarde : $f.gz"
EOF
install -m 755 "$SRC/deploy/doctor.sh" /usr/local/bin/darksurf-doctor
chmod 755 /usr/local/bin/darksurf-admin /usr/local/bin/darksurf-backup

cat >/etc/systemd/system/darksurf-backup.service <<'EOF'
[Unit]
Description=Sauvegarde de la base DARK_SURF
[Service]
Type=oneshot
ExecStart=/usr/local/bin/darksurf-backup
EOF
cat >/etc/systemd/system/darksurf-backup.timer <<'EOF'
[Unit]
Description=Sauvegarde DARK_SURF toutes les 6 heures
[Timer]
OnCalendar=*-*-* 00/6:17:00
Persistent=true
[Install]
WantedBy=timers.target
EOF

step "Caddy : configuration HTTPS"
[ -f /etc/caddy/Caddyfile ] && ! grep -q darksurf /etc/caddy/Caddyfile && cp -a /etc/caddy/Caddyfile "/etc/caddy/Caddyfile.bak.$(date +%s)"
cat >/etc/caddy/Caddyfile <<EOF
# Géré par l'installateur DARK_SURF
{
	email $EMAIL
}

$DOMAIN {
	encode zstd gzip
	reverse_proxy 127.0.0.1:8080 {
		transport http {
			dial_timeout 5s
		}
	}
	header {
		-Server
	}
}
EOF
caddy validate --config /etc/caddy/Caddyfile >/dev/null 2>&1 || die "Caddyfile invalide."

systemctl daemon-reload
systemctl enable --now darksurf-backup.timer >/dev/null 2>&1
systemctl enable darksurf caddy >/dev/null 2>&1
systemctl restart darksurf
systemctl restart caddy

# ------------------------------------------------------------------ vérifications finales
step "Démarrage"
ok=1
for i in $(seq 1 20); do curl -fsS --max-time 3 http://127.0.0.1:8080/healthz >/dev/null 2>&1 && break; sleep 1; [ "$i" = 20 ] && ok=0; done
[ "$ok" = 1 ] && echo "API locale ✔" || warn "l'API ne répond pas : journalctl -u darksurf -n 50"

# ------------------------------------------------------------------ compte administrateur
step "Compte administrateur"
CRED=/root/darksurf-identifiants.txt
HAS_ADMIN="$(darksurf-admin admin-count 2>/dev/null || echo 0)"
NEW_PW=""
if [ "${HAS_ADMIN:-0}" = "0" ]; then
  NEW_PW="$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-20)"
  darksurf-admin add-admin "$ADMIN_LOGIN" --password "$NEW_PW" >/dev/null
  umask 077
  cat >"$CRED" <<EOF
DARK_SURF - identifiants administrateur (à noter dans un gestionnaire de mots de passe, puis supprimer ce fichier)
Portail   : https://$DOMAIN
Identifiant : $ADMIN_LOGIN
Mot de passe : $NEW_PW
EOF
  umask 022
  echo "Administrateur « $ADMIN_LOGIN » créé ✔ (identifiants dans $CRED)"
else
  echo "Un administrateur existe déjà : aucun compte créé ✔"
fi

step "Vérifications"
https_ok=0
for i in $(seq 1 45); do
  if curl -fsS --max-time 4 "https://$DOMAIN/healthz" >/dev/null 2>&1; then https_ok=1; break; fi; sleep 2
done
[ "$https_ok" = 1 ] && echo "HTTPS public + certificat ✔" || warn "HTTPS pas encore prêt (DNS/ports 80 et 443 ouverts ? journalctl -u caddy -n 50). Relance darksurf-doctor dans une minute."

echo
darksurf-doctor || true

cat <<EOF

${C_OK}Installation terminée.${C_OFF}

  Portail administrateur : https://$DOMAIN   (identifiants : $CRED)
  Point d'accès WireGuard : $DOMAIN:$WG_PORT/udp   MTU $MTU
  Clé publique du serveur : $(cat /etc/wireguard/server.pub)

À faire maintenant :
  1. Pare-feu du FOURNISSEUR (panneau du VPS) : ouvre TCP 80, TCP 443 et UDP $WG_PORT.
  2. Dans les applis Android, mets l'adresse de l'API : https://$DOMAIN/api/v1/ (et le portail : https://$DOMAIN).
  3. Connecte-toi au portail, crée tes forfaits (Forfaits) puis tes vendeurs (Tableau de bord > Nouveau vendeur).
  4. Publie l'APK du VPN :  darksurf-admin publish-release app.apk --version-code 1 --version-name 1.0.0
  5. Vérifie à tout moment :  darksurf-doctor        Sauvegardes : /var/backups/darksurf
  Mise à jour du serveur : décompresse la nouvelle version et relance  sudo ./deploy/install.sh
EOF
