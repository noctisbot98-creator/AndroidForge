// Toute la configuration vient de l'environnement (voir deploy/darksurf.env.example).
const env = process.env;
const bool = (v, d) => (v === undefined ? d : !['0', 'false', 'no', ''].includes(String(v).toLowerCase()));

function load(overrides = {}) {
  const e = { ...env, ...overrides };
  return {
    port: Number(e.PORT || 8080),
    host: e.HOST || '127.0.0.1',                 // derrière Caddy/nginx : n'écoute qu'en local
    dbPath: e.DB_PATH || './data/darksurf.db',
    releasesDir: e.RELEASES_DIR || './data/releases',   // APK publiés (commande publish-release)
    publicUrl: (e.PUBLIC_URL || '').replace(/\/+$/, ''),   // ex. https://api.example.com (sinon déduit de la requête)
    trustProxy: bool(e.TRUST_PROXY, false),      // lire X-Forwarded-For / -Proto (uniquement derrière TON proxy)
    cookieSecure: bool(e.COOKIE_SECURE, true),
    wg: {
      mode: e.WG_MODE || 'dry',                  // "real" sur le VPS, "dry" pour développer
      iface: e.WG_IFACE || 'wg0',
      serverPublicKey: e.WG_SERVER_PUBKEY || Buffer.alloc(32, 7).toString('base64'),
      endpoint: e.WG_ENDPOINT || '203.0.113.10:51820',
      subnet: e.WG_SUBNET || '10.8.0.0/16',
      dns: e.WG_DNS || '1.1.1.1, 9.9.9.9',
      mtu: Number(e.WG_MTU || 1280),
      allowedIps: e.WG_ALLOWED_IPS || '0.0.0.0/0, ::/0',
      keepalive: Number(e.WG_KEEPALIVE || 25),
    },
    enforceIntervalMs: Number(e.ENFORCE_INTERVAL_MS || 5_000),
    tzOffsetS: Number(e.TZ_OFFSET_S || 3600),        // fuseau pour les plages horaires (Cameroun = UTC+1, sans heure d'été)
    supportPhone: e.SUPPORT_PHONE || '+237 621 86 21 34',   // affiché dans le portail vendeur pour demander des crédits
    profileTtlS: Number(e.PROFILE_TTL_S || 3600),
    codePrefix: 'TUN-',                           // doit correspondre à ActivationCode côté appli
    ...overrides.top,
  };
}
module.exports = { load };
