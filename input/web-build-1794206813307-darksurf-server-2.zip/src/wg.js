const { execFile } = require('child_process');

/** Première adresse libre du réseau WireGuard (/16 à /30 ; .1 = serveur, .0 et diffusion exclues). */
function allocateIp(subnet, used) {
  const [base, bitsStr] = subnet.split('/');
  const bits = Number(bitsStr || 24);
  if (!(bits >= 16 && bits <= 30)) throw new Error('WG_SUBNET : préfixe /16 à /30 attendu');
  const o = base.split('.').map(Number);
  const net = (((o[0] << 24) | (o[1] << 16) | (o[2] << 8) | o[3]) >>> 0) & (~0 << (32 - bits)) >>> 0;
  const size = 2 ** (32 - bits);
  const fmt = (n) => [n >>> 24, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');
  const taken = new Set(used.map((ip) => ip.split('/')[0]));
  for (let i = 2; i < size - 1; i++) { const ip = fmt(net + i); if (!taken.has(ip)) return `${ip}/32`; }
  throw new Error('plage d\'adresses WireGuard pleine');
}

/** Mode "dry" : mémoire seulement (développement et tests). */
class DryBackend {
  constructor() { this.peers = new Map(); this.counters = new Map(); }
  async addPeer(pub, ip) { this.peers.set(pub, ip); }
  async removePeer(pub) { this.peers.delete(pub); }
  async transfer() { return new Map(this.counters); }      // pub -> octets rx+tx cumulés
  async listPeers() { return new Set(this.peers.keys()); }
}

/** Mode "real" : pilote l'interface WireGuard du serveur avec la commande `wg` (droits root). */
class RealBackend {
  constructor(iface) { this.iface = iface; }
  run(args) {
    return new Promise((resolve, reject) =>
      execFile('wg', args, { timeout: 10_000 }, (err, out) => (err ? reject(err) : resolve(out))));
  }
  addPeer(pub, ip) { return this.run(['set', this.iface, 'peer', pub, 'allowed-ips', ip]); }
  removePeer(pub) { return this.run(['set', this.iface, 'peer', pub, 'remove']); }
  async transfer() {
    const m = new Map();
    for (const line of (await this.run(['show', this.iface, 'transfer'])).split('\n')) {
      const [pub, rx, tx] = line.split('\t');
      if (pub && rx !== undefined) m.set(pub, Number(rx) + Number(tx));
    }
    return m;
  }
  async listPeers() {
    return new Set((await this.run(['show', this.iface, 'peers'])).split('\n').filter(Boolean));
  }
}

const makeBackend = (cfg) => (cfg.mode === 'real' ? new RealBackend(cfg.iface) : new DryBackend());

module.exports = { allocateIp, DryBackend, RealBackend, makeBackend };
