# DARK_SURF (Android, Kotlin)

Client VPN : code d'activation -> identité ECDSA (Keystore) -> session signée -> tunnel WireGuard.

- `app/` : application (ouvrir ce dossier dans Android Studio, puis éditer `API_BASE` dans `app/build.gradle.kts`).
- `server-mock/` : mock de l'API pour tester (`node server-mock/test.js`).
- `docs/API.md` : contrat client/serveur.

Le tunnel utilise `com.wireguard.android:tunnel` (WireGuard-go userspace + VpnService).
