package com.example.tunnel

import android.content.res.Resources
import android.graphics.Color
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Identité visuelle DARK_SURF : verre dépoli sur nuit bleue, lueurs bleu / violet / ambre. */
object Ds {
    val BG = Color.parseColor("#050816")
    val BG2 = Color.parseColor("#0B1236")
    val SURFACE = Color.argb(30, 255, 255, 255)        // verre : blanc translucide
    val SURFACE2 = Color.argb(46, 255, 255, 255)
    val LINE = Color.argb(70, 150, 180, 255)           // liseré lumineux
    val ACCENT = Color.parseColor("#5B9BFF")           // bleu électrique
    val ACCENT2 = Color.parseColor("#B07CFF")          // violet
    val WARM = Color.parseColor("#FFB066")             // ambre
    val OK = Color.parseColor("#3DDC97")
    val ON = Color.parseColor("#2EE6A8")               // connecté : vert menthe
    val TEXT = Color.parseColor("#EAF0FF")
    val MUTED = Color.parseColor("#8C9BC4")
    val DANGER = Color.parseColor("#FF6B7A")

    // Mélange de styles : titres condensés, chiffres monospace, accroches serif italique, corps fin.
    val DISPLAY: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    val BLACK: Typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
    val BODY: Typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    val MONO: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    val SERIF: Typeface = Typeface.create("serif", Typeface.ITALIC)
}

val Int.dp: Int get() = (this * Resources.getSystem().displayMetrics.density).toInt()
val Float.dp: Float get() = this * Resources.getSystem().displayMetrics.density

/** Bilingue FR/EN, comme Geny. */
object Lang {
    @Volatile var fr: Boolean = Locale.getDefault().language == "fr"
    fun t(f: String, e: String) = if (fr) f else e
    fun locale(): Locale = if (fr) Locale.FRANCE else Locale.US
}

fun fmtBytes(b: Long): String {
    val unit = Lang.t("o", "B")
    val v = b.toDouble()
    return when {
        v >= 1e9 -> "%.2f G%s".format(v / 1e9, unit)
        v >= 1e6 -> "%.1f M%s".format(v / 1e6, unit)
        v >= 1e3 -> "%.0f k%s".format(v / 1e3, unit)
        else -> "$b $unit"
    }
}

fun fmtDuration(ms: Long): String {
    val s = ms / 1000
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

fun fmtDate(epochMs: Long, pattern: String = "d MMM yyyy"): String =
    SimpleDateFormat(pattern, Lang.locale()).format(Date(epochMs))
