#!/usr/bin/env bash
# Télécharge le noyau Xray pour Android (AndroidLibXrayLite) dans app/libs/libv2ray.aar.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p app/libs
curl -fL --retry 3 -o app/libs/libv2ray.aar https://github.com/2dust/AndroidLibXrayLite/releases/latest/download/libv2ray.aar
ls -la app/libs/libv2ray.aar
