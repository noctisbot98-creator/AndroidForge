package com.example.tunnel

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.drawable.Drawable
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

// ---------- helpers de construction ----------

fun rect(fill: Int, radius: Float = 16f, stroke: Int = 0, strokeW: Int = 1) = GradientDrawable().apply {
    setColor(fill); cornerRadius = radius.dp
    if (stroke != 0) setStroke(strokeW.dp, stroke)
}

/** Panneau de verre : reflet clair en haut, liseré lumineux. */
fun glass(radius: Float = 24f, strong: Boolean = false) = GradientDrawable(
    GradientDrawable.Orientation.TOP_BOTTOM,
    intArrayOf(if (strong) Color.parseColor("#1B3933") else Color.parseColor("#15312C"), Color.parseColor("#102522"))
).apply { cornerRadius = radius.dp; setStroke(1.dp, Ds.LINE) }

/** Fond de l'application : nuit bleue avec trois lueurs (bleu, violet, ambre) comme des reflets sur du verre. */
class GlowBackground : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat(); val h = bounds.height().toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, h, Ds.BG, Ds.BG2, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, w, h, p)
        fun glow(cx: Float, cy: Float, r: Float, col: Int, a: Int) {
            p.shader = RadialGradient(cx, cy, r, Color.argb(a, Color.red(col), Color.green(col), Color.blue(col)), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, p)
        }
        glow(w * 0.95f, h * 0.08f, w * 0.75f, Ds.ACCENT, 48)
        glow(w * 0.02f, h * 0.55f, w * 0.7f, Ds.ACCENT2, 28)
        glow(w * 0.85f, h * 0.95f, w * 0.55f, Ds.WARM, 34)
        p.shader = null
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(f: ColorFilter?) {}
    @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.OPAQUE
}

fun gradient(radius: Float = 16f) =
    GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Ds.ACCENT, Ds.WARM)).apply { cornerRadius = radius.dp }

fun lin(w: Int = MATCH, h: Int = WRAP, top: Int = 0, weight: Float = 0f) =
    LinearLayout.LayoutParams(w, h, weight).apply { topMargin = top.dp }

fun Context.tv(s: CharSequence, size: Float, color: Int = Ds.TEXT, font: Typeface = Ds.BODY, spacing: Float = 0f) =
    TextView(this).apply {
        text = s; textSize = size; setTextColor(color); typeface = font; letterSpacing = spacing
    }

fun Context.col(pad: Int = 0) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; setPadding(pad.dp, pad.dp, pad.dp, pad.dp)
}

fun Context.row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

fun Context.card() = col().apply {
    background = glass(24f); setPadding(18.dp, 16.dp, 18.dp, 16.dp)
}

fun Context.primaryButton(label: String, onClick: () -> Unit) =
    tv(label.uppercase(), 15f, Color.WHITE, Ds.DISPLAY, 0.14f).apply {
        gravity = Gravity.CENTER; background = gradient(16f); minHeight = 52.dp
        setOnClickListener { onClick() }
    }

fun Context.ghostButton(label: String, color: Int = Ds.ACCENT, onClick: () -> Unit) =
    tv(label.uppercase(), 13f, color, Ds.DISPLAY, 0.14f).apply {
        gravity = Gravity.CENTER; background = rect(Color.argb(20, 255, 255, 255), 16f, color, 1); minHeight = 48.dp
        setOnClickListener { onClick() }
    }

/** Petit libellé de section : monospace, espacé, discret. */
fun Context.overline(s: String) = tv(s.uppercase(), 11f, Ds.MUTED, Ds.MONO, 0.18f)

// ---------- logo ----------

/** Logo provisoire : anneau dégradé + vague stylisée. Remplaçable par ton propre logo. */
class LogoView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat()
        val cx = width / 2f; val cy = height / 2f
        p.shader = LinearGradient(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2, Ds.ACCENT, Ds.WARM, Shader.TileMode.CLAMP)
        p.strokeWidth = s * 0.07f
        cv.drawCircle(cx, cy, s * 0.42f, p)
        // deux vagues
        for ((k, dy) in listOf(-0.10f, 0.12f).withIndex()) {
            val x0 = cx - s * 0.26f; val w = s * 0.52f; val y = cy + s * dy
            val path = Path().apply {
                moveTo(x0, y)
                quadTo(x0 + w * 0.25f, y - s * 0.14f, x0 + w * 0.5f, y)
                quadTo(x0 + w * 0.75f, y + s * 0.14f, x0 + w, y)
            }
            p.strokeWidth = s * (if (k == 0) 0.07f else 0.05f)
            cv.drawPath(path, p)
        }
    }
}

// ---------- bouton de connexion ----------

enum class Orb { IDLE, BUSY, ON }

fun drawPower(cv: Canvas, cx: Float, cy: Float, r: Float, color: Int, stroke: Float) {
    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = stroke; this.color = color
    }
    cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -60f, 300f, false, p)
    cv.drawLine(cx, cy - r * 1.15f, cx, cy - r * 0.1f, p)
}

/** Gros bouton rond animé : halo pulsé (connecté), arc rotatif (en cours), contour (prêt). */
class OrbView(c: Context) : View(c) {
    var state = Orb.IDLE
        set(v) { field = v; invalidate() }

    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (ValueAnimator.areAnimatorsEnabled()) anim.start()
    }

    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat()
        val cx = width / 2f; val cy = height / 2f; val r = s * 0.30f
        p.shader = null

        if (state == Orb.ON) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f.dp; p.color = Ds.ON
            for (k in 0..2) {
                val ph = (t + k / 3f) % 1f
                p.alpha = ((1f - ph) * 110).toInt()
                cv.drawCircle(cx, cy, r + ph * s * 0.2f, p)
            }
            p.alpha = 255
        }
        // halo statique
        p.style = Paint.Style.FILL
        p.color = if (state == Orb.ON) Ds.ON else Ds.LINE
        p.alpha = if (state == Orb.ON) 40 else 70
        cv.drawCircle(cx, cy, r * 1.22f, p)
        p.alpha = 255

        // disque
        if (state == Orb.ON) {
            p.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r, Ds.ON, Color.parseColor("#12A97F"), Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, r, p)
            p.shader = null
        } else {
            p.color = Color.argb(60, 255, 255, 255)
            cv.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f.dp
            p.color = if (state == Orb.BUSY) Ds.LINE else Ds.ACCENT
            cv.drawCircle(cx, cy, r, p)
        }
        if (state == Orb.BUSY) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f.dp; p.strokeCap = Paint.Cap.ROUND; p.color = Ds.WARM
            cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), t * 360f, 100f, false, p)
        }
        val icon = when (state) { Orb.ON -> Color.WHITE; Orb.BUSY -> Ds.WARM; Orb.IDLE -> Ds.ACCENT }
        drawPower(cv, cx, cy, r * 0.38f, icon, 5f.dp)
    }
}

/** Bouton central surélevé de la barre du bas. */
class PowerBadge(c: Context) : View(c) {
    var busy = false
        set(v) { field = v; alpha = if (v) 0.6f else 1f }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f - 2f.dp
        p.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r, Ds.ACCENT, Ds.WARM, Shader.TileMode.CLAMP)
        p.style = Paint.Style.FILL
        cv.drawCircle(cx, cy, r, p)
        p.shader = null
        drawPower(cv, cx, cy, r * 0.36f, Color.WHITE, 3.5f.dp)
    }
}

// ---------- icônes de navigation ----------

class IconView(c: Context, private val kind: String) : View(c) {
    var tint = Ds.MUTED
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Ds.DISPLAY }

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat()
        val x = (width - s) / 2; val y = (height - s) / 2
        p.color = tint; p.strokeWidth = s * 0.09f
        fun px(f: Float) = x + f * s
        fun py(f: Float) = y + f * s
        when (kind) {
            "home" -> cv.drawPath(Path().apply {
                moveTo(px(.12f), py(.48f)); lineTo(px(.5f), py(.14f)); lineTo(px(.88f), py(.48f))
                moveTo(px(.22f), py(.42f)); lineTo(px(.22f), py(.86f)); lineTo(px(.78f), py(.86f)); lineTo(px(.78f), py(.42f))
            }, p)
            "activity" -> cv.drawPath(Path().apply {
                moveTo(px(.08f), py(.55f)); lineTo(px(.3f), py(.55f)); lineTo(px(.42f), py(.2f))
                lineTo(px(.6f), py(.85f)); lineTo(px(.72f), py(.45f)); lineTo(px(.92f), py(.45f))
            }, p)
            "settings" -> for ((yy, kx) in listOf(.25f to .3f, .5f to .7f, .75f to .45f)) {
                cv.drawLine(px(.12f), py(yy), px(.88f), py(yy), p)
                cv.drawCircle(px(kx), py(yy), s * 0.09f, p)
            }
            "key" -> {
                cv.drawCircle(px(.3f), py(.62f), s * 0.18f, p)
                cv.drawLine(px(.42f), py(.5f), px(.88f), py(.12f), p)
                cv.drawLine(px(.74f), py(.22f), px(.84f), py(.32f), p)
            }
            "card" -> {
                cv.drawRoundRect(RectF(px(.1f), py(.2f), px(.9f), py(.8f)), s * .1f, s * .1f, p)
                cv.drawLine(px(.1f), py(.42f), px(.9f), py(.42f), p)
                cv.drawLine(px(.22f), py(.64f), px(.4f), py(.64f), p)
            }
            "check" -> {
                cv.drawCircle(px(.5f), py(.5f), s * 0.4f, p)
                cv.drawPath(Path().apply { moveTo(px(.32f), py(.52f)); lineTo(px(.45f), py(.65f)); lineTo(px(.69f), py(.37f)) }, p)
            }
            else -> {
                cv.drawCircle(px(.5f), py(.5f), s * 0.4f, p)
                tp.color = tint; tp.textSize = s * 0.55f
                cv.drawText("?", px(.5f), py(.5f) + s * 0.2f, tp)
            }
        }
    }
}

/** Barre de progression dégradée vert -> jaune. */
class BarView(c: Context, frac0: Float) : View(c) {
    var frac = frac0
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val h = height.toFloat(); val rad = h / 2
        p.shader = null; p.color = Color.argb(50, 255, 255, 255)
        cv.drawRoundRect(RectF(0f, 0f, width.toFloat(), h), rad, rad, p)
        val w = width * frac.coerceIn(0f, 1f)
        if (w > 0f) {
            p.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, Ds.ACCENT, Ds.WARM, Shader.TileMode.CLAMP)
            cv.drawRoundRect(RectF(0f, 0f, maxOf(w, h), h), rad, rad, p)
        }
    }
}


/** Courbe de trafic en direct : réception (bleu) et envoi (ambre), jusqu'à 60 mesures. */
class ChartView(c: Context) : View(c) {
    var rx: List<Float> = emptyList()
    var tx: List<Float> = emptyList()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f.dp; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val grid = Paint().apply { color = Color.argb(40, 150, 180, 255); strokeWidth = 1f; pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f, 10f), 0f) }

    fun set(r: List<Float>, t: List<Float>) { rx = r; tx = t; invalidate() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat() - 4f.dp
        for (i in 0..3) cv.drawLine(0f, h * i / 3f, w, h * i / 3f, grid)
        val max = maxOf(1f, (rx + tx).maxOrNull() ?: 1f) * 1.15f
        fun line(d: List<Float>, col: Int) {
            if (d.size < 2) return
            val path = Path()
            d.forEachIndexed { i, v ->
                val x = w * i / 59f; val y = h - (v / max) * h
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            p.color = col; cv.drawPath(path, p)
        }
        line(rx, Ds.ACCENT); line(tx, Ds.WARM)
    }
}

/** Icône cloche (notifications). */
class BellView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = Ds.TEXT }
    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat(); val x = (width - s) / 2; val y = (height - s) / 2
        p.strokeWidth = s * 0.08f
        val path = Path().apply {
            moveTo(x + s * .2f, y + s * .72f); lineTo(x + s * .8f, y + s * .72f)
            quadTo(x + s * .68f, y + s * .62f, x + s * .68f, y + s * .42f)
            cubicTo(x + s * .68f, y + s * .14f, x + s * .32f, y + s * .14f, x + s * .32f, y + s * .42f)
            quadTo(x + s * .32f, y + s * .62f, x + s * .2f, y + s * .72f)
        }
        cv.drawPath(path, p)
        cv.drawLine(x + s * .42f, y + s * .84f, x + s * .58f, y + s * .84f, p)
    }
}

/** Ligne de réglage en verre : titre, sous-titre, chevron (ou interrupteur). */
fun Context.settingRow(title: String, sub: String, onClick: () -> Unit) = row().apply {
    background = glass(22f); setPadding(18.dp, 16.dp, 14.dp, 16.dp)
    addView(col().apply {
        addView(tv(title, 16f, Ds.TEXT, Ds.DISPLAY))
        addView(tv(sub, 13f, Ds.MUTED, Ds.BODY), lin(WRAP, WRAP, 2))
    }, lin(0, WRAP, 0, 1f))
    addView(tv("›", 24f, Ds.MUTED, Ds.BODY))
    setOnClickListener { onClick() }
}

fun Context.switchRow(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) = row().apply {
    background = glass(22f); setPadding(18.dp, 14.dp, 14.dp, 14.dp)
    addView(col().apply {
        addView(tv(title, 16f, Ds.TEXT, Ds.DISPLAY))
        addView(tv(sub, 13f, Ds.MUTED, Ds.BODY), lin(WRAP, WRAP, 2))
    }, lin(0, WRAP, 0, 1f))
    addView(android.widget.Switch(context).apply {
        isChecked = on
        setOnCheckedChangeListener { _, v -> onChange(v) }
    })
}

/** Signature de l'auteur : discrète, en capitales aérées sur un filet fin (police système « light », sobre et lisible). */
fun Context.signature(): View = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
    addView(View(context).apply { setBackgroundColor(Ds.LINE) }, LinearLayout.LayoutParams(36.dp, 1.dp).apply { bottomMargin = 10.dp })
    addView(TextView(context).apply {
        text = "BY NOCTIS"; textSize = 12f; setTextColor(Ds.MUTED); letterSpacing = 0.42f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); gravity = Gravity.CENTER
    })
}
