# Publier une mise à jour

**Une seule fois** — créer ta clé de signature : `tools/make-keystore.sh`
(sauvegarde `dark-surf-release.jks` + `keystore.properties` hors du projet ; perdue = plus de mises à jour possibles).
Les clients doivent installer **une première version signée avec cette clé** : les mises à jour suivantes devront l'être aussi.

**À chaque version :**
1. Dans `app/build.gradle.kts` : augmente `versionCode` (entier, toujours plus grand) et `versionName`.
2. `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk`.
3. Envoie l'APK sur le serveur : `scp app/build/outputs/apk/release/app-release.apk user@serveur:/tmp/`.
4. Publie-le sur le serveur :
   ```
   cd /opt/darksurf && set -a && . /etc/darksurf/darksurf.env && set +a
   sudo -E -u darksurf node --disable-warning=ExperimentalWarning src/admin.js publish-release /tmp/app-release.apk \
     --version-code 2 --version-name 1.1.0 --notes "Ce qui change" [--required] [--min-code 1]
   ```
   - `--required` : mise à jour bloquante pour tous les clients plus anciens.
   - `--min-code N` : obligatoire seulement pour les versions < N.
5. Retirer une version : `admin.js deactivate-release 2` ; lister : `admin.js list-releases`.

**Côté client :** à l'ouverture (au plus toutes les 6 h) l'appli demande `POST /api/v1/app/android`.
Si une version plus récente existe, un bandeau jaune apparaît sur l'Accueil : téléchargement HTTPS depuis ton serveur,
vérification SHA-256 puis de la signature, et l'utilisateur confirme l'installation Android.
La 1re fois, Android demande d'autoriser « installer des applis inconnues » pour DARK_SURF.


## Correctif de compatibilité TLS — DARK SURF

- Le profil accepte désormais un `host` WebSocket distinct du `sni` TLS ; si le backend ne fournit pas `host`, il reprend `sni`.
- Le client Xray annonce explicitement l'empreinte TLS `chrome` et ALPN `http/1.1` pour améliorer la compatibilité client TLS (ce choix n'est pas déduit du code Android GENY, absent de l'archive).
- La validation TLS reste active : aucun `allowInsecure` et aucun SNI GENY copié dans DARK SURF.
- Le chemin WebSocket, l'UUID, le domaine/SNI et le DNS restent ceux fournis par le backend DARK SURF.
- Validation stricte des champs du profil avant le démarrage du tunnel.
