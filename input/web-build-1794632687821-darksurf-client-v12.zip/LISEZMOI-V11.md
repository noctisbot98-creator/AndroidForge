# DARK_SURF V11 — ce qui est livré

Domaine : https://vpn.zidanexmd.space  (VPS 15.235.111.58)

## Règle d'or
Le client et le vendeur ne configurent RIEN. Le client colle sa clé et se connecte.
Le serveur impose l'ordre des connexions (champ `attempts` de /session) ; l'appli essaie la 1re,
puis la suivante si elle échoue (VLESS/WS, REALITY, SSH-WS, SSH-TCP).

## Contenu
- darksurf-install-v11.sh : serveur + installation (aucun argument nécessaire, valeurs par défaut du projet).
- darksurf-client-v11.zip : appli client Android (projet Gradle, build GitHub / AndroidForge).
- darksurf-seller-v11.zip : applis DARK_SURF PRO (vendeur) et DARK_SURF ADMIN (coquille du portail).
- seller-private.pem : clé SECRÈTE qui signe les codes d'activation vendeur/admin. Ne jamais la mettre dans un APK ni sur GitHub.

## Installation
    bash /root/darksurf-install-v11.sh
(équivaut à --domain vpn.zidanexmd.space --email noctibot98@gmail.com --admin zidanedark --reality --udp)
Le mot de passe admin est écrit dans /root/darksurf-identifiants.txt (à noter puis supprimer).
Ports à ouvrir chez l'hébergeur : TCP 22, 80, 443, 2222, 8443 ; UDP 4443.

## Ce qui a changé par rapport à V10
- Plus aucun choix de protocole ni de DNS dans l'appli client.
- SSH-WS et SSH-TCP dans l'appli (JSch), avec pare-feu serveur et comptage du trafic SSH.
- Mode « Payload » supprimé (serveur, panneau, tests, installeur).
- Citations (24) qui changent toutes les 5 minutes ; bouton de connexion et citation qui changent de couleur à chaque étape.
- Le nom saisi par le vendeur sur la clé s'affiche chez le client (« Compte de … »).
- Prix en crédits ET en FCFA (1 crédit = 100 FCFA).
- Appli et connexion API pointent sur vpn.zidanexmd.space (HTTPS uniquement).

## Limites connues (honnêtement)
- L'appli n'a pas pu être compilée ici (pas de SDK Android) : première compilation à faire sur GitHub/AndroidForge.
- 3 tests serveur (app-config-shape, client-config-xray, tunnel-e2e) exigent le vrai binaire Xray : ils ne tournent que sur le VPS.
- Le problème de départ (pas d'Internet à travers ce VPS depuis ta SIM) n'est PAS prouvé résolu par ce changement.
