package com.noctis.darksurf

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Mesures réseau réelles utilisées par l'interface :
 *  - IP publique AVANT connexion (hors tunnel, l'appli est exclue du VPN) ;
 *  - IP publique APRÈS connexion (à travers le tunnel) ;
 *  - latence vers le serveur DARK_SURF (qualité de connexion) ;
 *  - type de réseau actif (Wi-Fi / mobile).
 *
 * Aucune de ces valeurs n'est inventée : si la mesure échoue, on renvoie null et
 * l'interface affiche « — ».
 */
object NetProbe {

    /** IP publique vue depuis l'extérieur. `viaTunnel` = true pour passer par le tunnel. */
    suspend fun publicIp(viaTunnel: Boolean = false): String? = withContext(Dispatchers.IO) {
        val endpoints = listOf("https://api.ipify.org", "https://ifconfig.me/ip", "https://icanhazip.com")
        for (e in endpoints) {
            val r = runCatching { httpGet(e.trim(), 6000) }.getOrNull()
            if (!r.isNullOrBlank() && r.trim().matches(Regex("^[0-9a-fA-F:.]{3,45}$"))) return@withContext r.trim()
        }
        null
    }

    /** Latence TCP vers l'hôte de l'API (ms), ou -1 si injoignable. */
    suspend fun latencyMs(): Int = withContext(Dispatchers.IO) {
        runCatching {
            val host = URL(BuildConfig.API_BASE).host
            val t0 = System.nanoTime()
            val reachable = InetAddress.getByName(host).isReachable(4000)
            if (!reachable) return@withContext -1
            ((System.nanoTime() - t0) / 1_000_000).toInt()
        }.getOrDefault(-1)
    }

    /** Type de réseau actif, tel que vu par Android. */
    fun networkType(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "—"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "4G/5G"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "—"
        }
    }

    /** Le serveur DARK_SURF répond-il ? (endpoint /healthz, hors tunnel). */
    suspend fun serverHealthy(): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val u = URL(BuildConfig.API_BASE)
            val health = "${u.protocol}://${u.host}${if (u.port > 0) ":${u.port}" else ""}/healthz"
            val c = (URL(health).openConnection() as HttpURLConnection).run {
                connectTimeout = 6000; readTimeout = 6000
                val code = responseCode; disconnect(); code
            }
            c in 200..299
        }.getOrDefault(false)
    }

    private fun httpGet(url: String, timeout: Int): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = timeout; readTimeout = timeout; requestMethod = "GET"
            setRequestProperty("User-Agent", "DARK-SURF/${BuildConfig.VERSION_NAME}")
        }
        return try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }
}
