package com.noctis.darksurf

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.ColorDrawable
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.provider.Settings
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


private enum class Conn { IDLE, CONNECTING, CONNECTED, DISCONNECTING }
private const val QUOTE_MS = 300_000L      // une citation toutes les 5 minutes

/**
 * DARK_SURF — même charpente que Geny (accueil, activité, réglages, aide, barre du bas à 5 emplacements),
 * habillage DARK SURF : pétrole profond, turquoise, cuivre et cartes à bordures fines.
 */
class MainActivity : ComponentActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var tm: TunnelManager
    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout

    private var tab = 0                 // 0 accueil · 1 activité · 2 réglages · 3 aide
    private var conn = Conn.IDLE
    private var phase = 0                                  // étape de connexion (couleurs)
    private var quoteTap = 0
    private var quoteSlot = System.currentTimeMillis() / QUOTE_MS
    private var quoteViews: QuoteViews? = null
    private var orbView: OrbView? = null
    private var error: String? = null
    private var rx = 0L
    private var tx = 0L
    private var prefillCode = ""
    private var update: UpdateInfo? = null
    private var updateMsg: String? = null
    private var updateStatus: String? = null
    private var updating = false
    private var planBuiltEmpty = false
    private var diagMsg: String? = null
    private var diagOk = true
    private val faqOpen = mutableSetOf<Int>()

    // trafic en direct (60 dernières secondes)
    private val rxHist = ArrayDeque<Float>()
    private val txHist = ArrayDeque<Float>()
    private var lastRx = 0L
    private var lastTx = 0L
    private var rateRx = 0f
    private var rateTx = 0f

    // vues mises à jour chaque seconde
    private var rxTv: TextView? = null
    private var txTv: TextView? = null
    private var planRemainTv: TextView? = null
    private var planUsedTv: TextView? = null
    private var planPctTv: TextView? = null
    private var planBar: BarView? = null
    private var chart: ChartView? = null
    private var rateRxTv: TextView? = null
    private var rateTxTv: TextView? = null
    private var sessRxTv: TextView? = null
    private var sessTxTv: TextView? = null
    private var sessDurTv: TextView? = null

    private val ticker = object : Runnable {
        override fun run() { tick(); handler.postDelayed(this, 1000) }
    }

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun askNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 && !Notifier.canNotify(this) && !prefs.getBoolean("notif_asked", false)) {
            prefs.edit().putBoolean("notif_asked", true).apply()
            notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) doConnect() else { error = t("Autorisation VPN refusée.", "VPN permission denied."); render() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tm = TunnelManager.get(this)
        prefs = getSharedPreferences("ui", Context.MODE_PRIVATE)
        if (prefs.contains("fr")) Lang.fr = prefs.getBoolean("fr", Lang.fr)
        window.setBackgroundDrawable(GlowBackground())

        root = FrameLayout(this).apply { background = GlowBackground(); clipChildren = false }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        setContentView(root)

        handleIntent(intent)
        if (tm.isConnected()) conn = Conn.CONNECTED
        tm.onPlanChanged = { runOnUiThread { if (tm.isEnrolled()) { if (tab == 0 && planBuiltEmpty && tm.plan() != null) render() else updatePlanViews() } } }
        render()
        if (!prefs.getBoolean("rules", false)) showRules()
        askNotificationPermission()
        checkUpdate(manual = false)
        if (tm.isEnrolled()) scope.launch { runCatching { tm.refreshStatus() } }
    }

    override fun onResume() { super.onResume(); handler.post(ticker) }
    override fun onPause() { handler.removeCallbacks(ticker); super.onPause() }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
        render()
    }

    private fun handleIntent(i: Intent?) { i?.data?.getQueryParameter("code")?.let { prefillCode = it } }

    private fun t(f: String, e: String) = Lang.t(f, e)
    private fun haptic(v: View) { if (prefs.getBoolean("haptics", true)) v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY) }

    // ------------------------------------------------------------------ rendu

    private fun render() {
        root.removeAllViews()
        rxTv = null; txTv = null; planRemainTv = null; planUsedTv = null; planPctTv = null; planBar = null
        chart = null; rateRxTv = null; rateTxTv = null; sessRxTv = null; sessTxTv = null; sessDurTv = null
        if (!tm.isEnrolled()) { root.addView(activationScreen()); return }

        val page = when (tab) { 0 -> homeScreen(); 1 -> activityScreen(); 2 -> settingsScreen(); else -> helpScreen() }
        val scroll = ScrollView(this).apply { isFillViewport = true; isVerticalScrollBarEnabled = false; addView(page) }
        root.addView(col().apply {
            clipChildren = false
            addView(scroll, lin(MATCH, 0, weight = 1f))
            addView(bottomNav())
        })
    }

    private fun unitRate(bytesPerSec: Float): String {
        val mb = prefs.getString("unit", "MBps") == "MBps"
        val v = if (mb) bytesPerSec / 1e6f else bytesPerSec * 8f / 1e6f
        return "%.2f".format(Lang.locale(), v)
    }
    private fun unitName() = if (prefs.getString("unit", "MBps") == "MBps") "MB/s" else "Mb/s"

    private fun tick() {
        if (!tm.isEnrolled()) return
        val slot = System.currentTimeMillis() / QUOTE_MS
        if (slot != quoteSlot) { quoteSlot = slot; quoteTap = 0; quoteViews?.text?.text = quotes()[quoteIndex()] }
        if (conn == Conn.CONNECTING || conn == Conn.DISCONNECTING) {
            phase++; orbView?.let { it.tint = stateAccent() }; quoteViews?.paint(stateAccent())
        }
        if (conn == Conn.CONNECTED && !tm.isConnected()) {          // coupé par le système
            conn = Conn.IDLE
            error = when (tm.lastStop) {
                "expired" -> t("Votre forfait a expiré : le VPN s'est arrêté.", "Your plan has expired: the VPN stopped.")
                "quota_exceeded" -> t("Données épuisées : le VPN s'est arrêté.", "Data used up: the VPN stopped.")
                "outside_window" -> t("Hors plage horaire : le VPN s'est arrêté.", "Outside allowed hours: the VPN stopped.")
                "revoked", "disabled" -> t("Cette clé n'est plus valable.", "This key is no longer valid.")
                else -> t("Connexion interrompue.", "Connection interrupted.")
            }
            render(); return
        }
        if (conn != Conn.CONNECTED) return
        scope.launch {
            val (r, x) = tm.stats()
            if (lastRx > 0 || lastTx > 0) {
                rateRx = (r - lastRx).coerceAtLeast(0).toFloat(); rateTx = (x - lastTx).coerceAtLeast(0).toFloat()
            }
            lastRx = r; lastTx = x; rx = r; tx = x
            rxHist.addLast(rateRx); txHist.addLast(rateTx)
            while (rxHist.size > 60) rxHist.removeFirst()
            while (txHist.size > 60) txHist.removeFirst()
            rxTv?.text = fmtBytes(r); txTv?.text = fmtBytes(x)
            sessRxTv?.text = fmtBytes(r); sessTxTv?.text = fmtBytes(x)
            tm.connectedAt.takeIf { it > 0 }?.let { sessDurTv?.text = fmtDuration(System.currentTimeMillis() - it) }
            rateRxTv?.text = unitRate(rateRx); rateTxTv?.text = unitRate(rateTx)
            chart?.set(rxHist.toList(), txHist.toList())
            updatePlanViews()
        }
    }

    // ------------------------------------------------------------ activation

    private fun activationScreen(): View {
        var busy = false
        val status = tv(error ?: "", 13f, Ds.DANGER, Ds.BODY).apply { gravity = Gravity.CENTER }
        val input = EditText(this).apply {
            hint = "TUN-••••••••••••••••••••••••••••••••"; setHintTextColor(Ds.MUTED)
            setText(prefillCode); setTextColor(Ds.ACCENT); typeface = Ds.MONO; textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(true); gravity = Gravity.CENTER
            background = rect(Ds.SURFACE, 16f, Ds.LINE, 1); setPadding(16.dp, 16.dp, 16.dp, 16.dp)
        }
        val button = primaryButton(t("Activer", "Activate")) {
            if (busy) return@primaryButton
            busy = true; status.setTextColor(Ds.MUTED); status.text = t("Activation…", "Activating…")
            scope.launch {
                try {
                    tm.activate(input.text.toString()); error = null; prefillCode = ""; busy = false; render()
                } catch (e: CancellationException) { throw e
                } catch (e: ApiException) {
                    busy = false; status.setTextColor(Ds.DANGER); status.text = apiMessage(e)
                } catch (e: Exception) {
                    busy = false; status.setTextColor(Ds.DANGER)
                    status.text = t("Activation impossible : ", "Could not activate: ") + (e.message ?: "")
                }
            }
        }
        return col(28).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            addView(View(context), lin(MATCH, 40.dp))
            addView(LogoView(context), lin(96.dp, 96.dp))
            addView(tv("DARK_SURF", 34f, Ds.TEXT, Ds.BLACK, 0.08f), lin(WRAP, WRAP, 14))
            addView(tv(t("Surfe dans l'ombre.", "Surf in the dark."), 16f, Ds.WARM, Ds.SERIF), lin(WRAP, WRAP, 4))
            addView(signature(), lin(WRAP, WRAP, 10))
            addView(overline(t("Code d'activation", "Activation code")), lin(WRAP, WRAP, 44))
            addView(input, lin(MATCH, WRAP, 10))
            addView(button, lin(MATCH, WRAP, 16))
            addView(status, lin(MATCH, WRAP, 14))
        }
    }

    // ----------------------------------------------------------------- en-tête commun

    private fun header(): View = row().apply {
        addView(LogoView(context), lin(44.dp, 44.dp))
        addView(tv("DARK_SURF", 22f, Ds.TEXT, Ds.BLACK, 0.06f), lin(WRAP, WRAP).apply { leftMargin = 12.dp }.also { it.weight = 1f; it.width = 0 })
        if (tab != 0 && conn == Conn.CONNECTED) {
            addView(row().apply {
                background = glass(20f); setPadding(12.dp, 8.dp, 14.dp, 8.dp)
                addView(View(context).apply { background = rect(Ds.ON, 8f) }, lin(8.dp, 8.dp))
                addView(tv(t("Connecté", "Connected"), 13f, Ds.ON, Ds.DISPLAY), lin(WRAP, WRAP).apply { leftMargin = 8.dp })
            }, lin(WRAP, WRAP).apply { rightMargin = 10.dp })
        }
        addView(FrameLayout(context).apply {
            background = glass(24f)
            addView(BellView(context), FrameLayout.LayoutParams(22.dp, 22.dp, Gravity.CENTER))
            setOnClickListener { haptic(it); showBell() }
        }, lin(44.dp, 44.dp))
    }

    private fun showBell() {
        val items = Notifier.recent(this)
        val msg = if (items.isEmpty()) t("Aucune notification pour le moment.", "No notifications yet.")
        else items.joinToString("\n\n") { (ti, x, at) -> "• $ti\n  $x\n  ${fmtDate(at, "d MMM · HH:mm")}" }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setTitle(t("Notifications", "Notifications"))
            .setMessage(msg).setPositiveButton("OK", null).show()
    }

    // ----------------------------------------------------------------- accueil

    private fun quoteIndex() = (((System.currentTimeMillis() / QUOTE_MS).toInt() + quoteTap) % quotes().size + quotes().size) % quotes().size

    /** Couleur de l'étape en cours : repos, connexion (qui tourne), connecté, déconnexion, erreur. */
    private fun stateAccent(): Int = when (conn) {
        Conn.CONNECTED -> Color.parseColor("#34D399")
        Conn.CONNECTING -> intArrayOf(Ds.ACCENT2, Ds.ACCENT, Color.parseColor("#F59E0B"))[phase % 3]
        Conn.DISCONNECTING -> if (phase % 2 == 0) Color.parseColor("#F59E0B") else Ds.DANGER
        Conn.IDLE -> if (error != null) Ds.DANGER else Ds.ACCENT
    }

    private fun quotes() = listOf(
        t("Dans l'ombre, chaque octet trouve sa route.", "In the dark, every byte finds its way."),
        t("Les vagues ne demandent la permission à personne.", "Waves ask no one for permission."),
        t("Reste discret. Va loin.", "Stay quiet. Go far."),
        t("La nuit appartient à ceux qui surfent.", "The night belongs to those who surf."),
        t("Un bon réseau ne fait jamais de bruit.", "A good network never makes noise."),
        t("Sois l'ombre qui glisse sur la vague.", "Be the shadow gliding on the wave."),
        t("Ce que tu ne vois pas, personne ne l'intercepte.", "What you can't see, no one intercepts."),
        t("Plus la nuit est noire, plus la vague brille.", "The darker the night, the brighter the wave."),
        t("Le silence est la plus rapide des connexions.", "Silence is the fastest connection."),
        t("Qui maîtrise l'ombre maîtrise le chemin.", "Who masters the shadow masters the path."),
        t("Avance sans bruit, laisse le monde faire du vacarme.", "Move quietly, let the world make noise."),
        t("Une porte fermée à tous, ouverte pour toi.", "A door closed to all, open to you."),
        t("La liberté commence là où le signal ne ment pas.", "Freedom starts where the signal doesn't lie."),
        t("Même la tempête passe par un tunnel.", "Even the storm passes through a tunnel."),
        t("Le vrai pouvoir ne s'affiche pas.", "True power doesn't show off."),
        t("Chaque clic est une vague, choisis la tienne.", "Every click is a wave, choose yours."),
        t("Dans le noir, les meilleurs chemins se dessinent.", "In the dark, the best paths appear."),
        t("Reste insaisissable.", "Stay elusive."),
        t("L'eau trouve toujours son passage.", "Water always finds its way."),
        t("Le calme avant la vitesse.", "The calm before the speed."),
        t("Ce qui est protégé voyage plus loin.", "What is protected travels further."),
        t("Surfe léger, pense lourd.", "Surf light, think deep."),
        t("L'ombre n'a pas peur de la lumière, elle la contourne.", "The shadow doesn't fear the light, it goes around it."),
        t("Un nom discret, un chemin libre.", "A quiet name, a free path."),
    )

    private fun orbState() = when (conn) { Conn.CONNECTED -> Orb.ON; Conn.IDLE -> Orb.IDLE; else -> Orb.BUSY }

    private fun maskedKey(): String {
        val c = tm.code() ?: return "—"
        return if (c.length > 12) c.take(8) + "••••••" + c.takeLast(4) else c
    }

    private fun homeScreen(): View = col(20).apply {
        addView(header(), lin())
        update?.let { addView(updateCard(it), lin(MATCH, WRAP, 12)) }

        addView(tv(t("Votre connexion.", "Your connection."), 28f, Ds.TEXT, Ds.BLACK).apply { letterSpacing = -0.01f }, lin(WRAP, WRAP, 18))
        addView(android.text.SpannableString(t("En toute liberté.", "Stay connected.")).let { sp ->
            sp.setSpan(android.text.style.ForegroundColorSpan(Ds.WARM), 0, sp.length, 0)
            tv(sp, 28f, Ds.TEXT, Ds.SERIF).apply { setTypeface(typeface, Typeface.BOLD_ITALIC) }
        }, lin(WRAP, WRAP))

        addView(OrbView(context).apply { state = orbState(); tint = stateAccent(); orbView = this; contentDescription = t("Bouton de connexion VPN", "VPN connection button"); setOnClickListener { haptic(it); toggle() } }, lin(MATCH, 276.dp, 2))

        val title = when (conn) {
            Conn.IDLE -> t("Prêt à se connecter", "Ready to connect")
            Conn.CONNECTING -> t("Connexion en cours…", "Connecting…")
            Conn.CONNECTED -> t("Vous êtes connecté", "You are connected")
            Conn.DISCONNECTING -> t("Déconnexion…", "Disconnecting…")
        }
        addView(tv(title, 24f, Ds.TEXT, Ds.DISPLAY).apply { gravity = Gravity.CENTER }, lin(MATCH, WRAP, 0))
        error?.let { addView(tv(it, 13f, Ds.DANGER, Ds.BODY).apply { gravity = Gravity.CENTER }, lin(MATCH, WRAP, 8)) }

        // clé masquée + copier
        addView(row().apply {
            background = glass(22f); setPadding(14.dp, 12.dp, 12.dp, 12.dp)
            addView(FrameLayout(context).apply {
                background = rect(Ds.SURFACE2, 14f)
                addView(IconView(context, "key").apply { tint = Ds.ACCENT2 }, FrameLayout.LayoutParams(22.dp, 22.dp, Gravity.CENTER))
            }, lin(44.dp, 44.dp))
            addView(tv(maskedKey(), 17f, Ds.TEXT, Ds.MONO).apply { setSingleLine(true) }, lin(0, WRAP, 0, 1f).apply { leftMargin = 14.dp })
            addView(tv(t("Copier", "Copy"), 14f, Ds.WARM, Ds.DISPLAY).apply {
                gravity = Gravity.CENTER; background = rect(Ds.SURFACE2, 18f); setPadding(16.dp, 10.dp, 16.dp, 10.dp)
                setOnClickListener { v ->
                    haptic(v)
                    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("key", tm.code() ?: ""))
                    text = t("Copié", "Copied"); v.postDelayed({ text = t("Copier", "Copy") }, 1500)
                }
            }, lin(WRAP, WRAP))
        }, lin(MATCH, WRAP, 16))

        addView(quoteCard(quotes()[quoteIndex()], stateAccent(), { quoteViews = it }) { quoteTap++; render() }, lin(MATCH, WRAP, 12))

        // réception / envoi
        addView(row().apply {
            val r = tv(fmtBytes(rx), 22f, Ds.TEXT, Ds.DISPLAY); rxTv = r
            val x = tv(fmtBytes(tx), 22f, Ds.TEXT, Ds.DISPLAY); txTv = x
            addView(flowCard(t("Réception", "Download"), "↓", Ds.ACCENT2, r), lin(0, WRAP, 0, 1f))
            addView(View(context), lin(12.dp, 1))
            addView(flowCard(t("Envoi", "Upload"), "↑", Ds.ON, x), lin(0, WRAP, 0, 1f))
        }, lin(MATCH, WRAP, 12))

        addView(planCard(), lin(MATCH, WRAP, 12))
        addView(signature(), lin(MATCH, WRAP, 22))
    }

    private fun flowCard(label: String, arrow: String, color: Int, value: TextView) = card().apply {
        addView(row().apply {
            addView(tv(arrow, 18f, color, Ds.BLACK).apply { gravity = Gravity.CENTER; background = rect(Ds.SURFACE2, 12f) }, lin(34.dp, 34.dp))
            addView(tv(label, 14f, Ds.MUTED, Ds.DISPLAY), lin(WRAP, WRAP).apply { leftMargin = 10.dp })
        })
        addView(value, lin(WRAP, WRAP, 12))
        addView(tv(t("Cumulé · cette session", "Total · this session"), 12f, Ds.MUTED, Ds.BODY), lin(WRAP, WRAP, 2))
    }

    private fun usedAndQuota(): Pair<Long, Long?> {
        val plan = tm.plan() ?: return 0L to null
        val used = if (conn == Conn.CONNECTED) tm.liveUsed(plan, rx + tx) else plan.usedBytes
        return used to plan.quotaBytes
    }

    private fun timeLeft(plan: Plan): String {
        val s = plan.expiresAt - System.currentTimeMillis() / 1000
        if (plan.expiresAt <= 0) return ""
        if (s <= 0) return t("expiré", "expired")
        val d = s / 86400; val h = (s % 86400) / 3600; val m = (s % 3600) / 60
        return when {
            d > 0 -> "$d ${t("j", "d")} $h h"
            h > 0 -> "$h h $m min"
            else -> "$m min"
        }
    }

    private fun updatePlanViews() {
        val plan = tm.plan() ?: return
        val (used, q) = usedAndQuota()
        if (q != null) {
            planRemainTv?.text = t("${fmtBytes((q - used).coerceAtLeast(0))} restants", "${fmtBytes((q - used).coerceAtLeast(0))} left")
            planUsedTv?.text = t("${fmtBytes(used)} utilisés sur ${fmtBytes(q)}", "${fmtBytes(used)} used of ${fmtBytes(q)}")
            planPctTv?.text = "${(used * 100 / q).coerceIn(0, 100)} %"
            planBar?.frac = used.toFloat() / q
        }
    }

    private fun planCard(): View = card().apply {
        val plan = tm.plan()
        addView(row().apply {
            addView(FrameLayout(context).apply {
                background = rect(Ds.SURFACE2, 16f)
                addView(IconView(context, "card").apply { tint = Ds.ACCENT2 }, FrameLayout.LayoutParams(24.dp, 24.dp, Gravity.CENTER))
            }, lin(52.dp, 52.dp))
            addView(col().apply {
                addView(overline(t("Mon forfait", "My plan")))
                addView(tv(plan?.name ?: "—", 20f, Ds.TEXT, Ds.DISPLAY), lin(WRAP, WRAP, 2))
                plan?.clientName?.let { addView(tv(t("Compte de ", "Account of ") + it, 14f, Ds.WARM, Ds.DISPLAY), lin(WRAP, WRAP, 2)) }
            }, lin(0, WRAP, 0, 1f).apply { leftMargin = 14.dp })
            val q = plan?.quotaBytes
            if (q != null) {
                val pct = tv("", 13f, Ds.ACCENT2, Ds.DISPLAY).apply { background = rect(Ds.SURFACE2, 16f); setPadding(14.dp, 6.dp, 14.dp, 6.dp) }
                planPctTv = pct; addView(pct)
            }
        })
        planBuiltEmpty = plan == null
        if (plan == null) {
            addView(tv(t("Connectez-vous pour afficher votre forfait.", "Connect to see your plan."), 14f, Ds.MUTED), lin(WRAP, WRAP, 12))
            return@apply
        }
        val q = plan.quotaBytes
        if (q == null) {
            addView(tv(t("Données illimitées", "Unlimited data"), 24f, Ds.ACCENT2, Ds.DISPLAY), lin(WRAP, WRAP, 14))
        } else {
            val rem = tv("", 26f, Ds.ACCENT2, Ds.BLACK); planRemainTv = rem
            addView(rem, lin(WRAP, WRAP, 14))
            val bar = BarView(context, 0f); planBar = bar
            addView(bar, lin(MATCH, 10.dp, 10))
            val used = tv("", 13f, Ds.MUTED, Ds.BODY); planUsedTv = used
            addView(used, lin(WRAP, WRAP, 8))
        }
        val state = if (conn == Conn.CONNECTED || plan.expiresAt <= 0 || plan.expiresAt * 1000 > System.currentTimeMillis()) t("Forfait actif", "Active plan") else t("Forfait expiré", "Plan expired")
        val left = timeLeft(plan).let { if (it.isEmpty()) "" else " · ${if (it == t("expiré", "expired")) it else t("$it restantes", "$it left")}" }
        val win = plan.windowText()?.let { " · $it" } ?: ""
        addView(tv("$state$left$win · 1 ${t("appareil", "device")}", 13f, Ds.MUTED, Ds.BODY), lin(WRAP, WRAP, 2))
        addView(row().apply {
            addView(tv(t("Détail", "Details"), 16f, Ds.ACCENT2, Ds.DISPLAY).apply {
                gravity = Gravity.CENTER; background = rect(Ds.SURFACE2, 22f); minHeight = 54.dp
                setOnClickListener { haptic(it); showPlanDetail(plan) }
            }, lin(0, 54.dp, 0, 1f))
            addView(View(context), lin(12.dp, 1))
            addView(tv(t("Support", "Support"), 16f, Ds.ON, Ds.DISPLAY).apply {
                gravity = Gravity.CENTER; background = rect(Color.argb(40, 46, 230, 168), 22f); minHeight = 54.dp
                setOnClickListener { haptic(it); openSupport() }
            }, lin(0, 54.dp, 0, 1f))
        }, lin(MATCH, WRAP, 14))
        updatePlanViews()
    }

    private fun openSupport(extra: String = "") {
        val uri = Uri.parse("https://wa.me/${SUPPORT_WA}" + if (extra.isNotEmpty()) "?text=" + Uri.encode(extra) else "")
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
    }

    private fun showPlanDetail(plan: Plan) {
        val (used, q) = usedAndQuota()
        val lines = mutableListOf(plan.name)
        lines.add(if (q == null) t("Données : illimitées", "Data: unlimited") else t("Données : ${fmtBytes(used)} utilisés sur ${fmtBytes(q)}", "Data: ${fmtBytes(used)} used of ${fmtBytes(q)}"))
        if (plan.expiresAt > 0) lines.add(t("Expire le ", "Expires ") + fmtDate(plan.expiresAt * 1000, "d MMM yyyy · HH:mm"))
        plan.windowText()?.let { lines.add(t("Plage horaire : $it", "Time window: $it")) }
        lines.add(t("Appareils : 1", "Devices: 1"))
        lines.add(t("Débit : non limité", "Speed: not limited"))
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setTitle(t("Détail du forfait", "Plan details"))
            .setMessage(lines.joinToString("\n")).setPositiveButton("OK", null).show()
    }

    // ---------------------------------------------------------------- activité

    private fun activityScreen(): View = col(20).apply {
        addView(header(), lin())
        addView(tv(t("Votre activité", "Your activity"), 30f, Ds.TEXT, Ds.BLACK), lin(WRAP, WRAP, 18))
        addView(tv(t("Votre connexion, en un coup d'œil.", "Your connection at a glance."), 15f, Ds.MUTED, Ds.SERIF), lin(WRAP, WRAP, 2))

        addView(card().apply {
            addView(row().apply {
                addView(tv(t("Trafic en direct", "Live traffic"), 20f, Ds.TEXT, Ds.DISPLAY), lin(0, WRAP, 0, 1f))
                addView(tv(if (conn == Conn.CONNECTED) t("OBSERVÉ", "OBSERVED") else t("EN PAUSE", "PAUSED"), 11f, Ds.ON, Ds.MONO, 0.12f).apply {
                    background = rect(Color.argb(40, 46, 230, 168), 16f); setPadding(14.dp, 8.dp, 14.dp, 8.dp)
                })
            })
            addView(row().apply {
                addView(legend(t("Réception", "Download"), Ds.ACCENT2)); addView(View(context), lin(8.dp, 1)); addView(legend(t("Envoi", "Upload"), Ds.ON))
            }, lin(MATCH, WRAP, 12))
            addView(tv(unitName(), 12f, Ds.MUTED, Ds.BODY), lin(WRAP, WRAP, 10))
            val c = ChartView(context).apply { set(rxHist.toList(), txHist.toList()) }; chart = c
            addView(c, lin(MATCH, 170.dp, 4))
            addView(tv(t("Jusqu'à 60 observations récentes", "Up to 60 recent samples"), 12f, Ds.MUTED, Ds.BODY), lin(WRAP, WRAP, 8))
        }, lin(MATCH, WRAP, 16))

        addView(row().apply {
            val a = tv(unitRate(rateRx), 26f, Ds.TEXT, Ds.DISPLAY); rateRxTv = a
            val b = tv(unitRate(rateTx), 26f, Ds.TEXT, Ds.DISPLAY); rateTxTv = b
            addView(rateCard(t("Réception", "Download"), "↓", Ds.ACCENT2, a), lin(0, WRAP, 0, 1f))
            addView(View(context), lin(12.dp, 1))
            addView(rateCard(t("Envoi", "Upload"), "↑", Ds.ON, b), lin(0, WRAP, 0, 1f))
        }, lin(MATCH, WRAP, 12))

        addView(card().apply {
            addView(tv(t("Cette session", "This session"), 20f, Ds.TEXT, Ds.DISPLAY))
            val r = tv(fmtBytes(rx), 16f, Ds.TEXT, Ds.DISPLAY); sessRxTv = r
            val x = tv(fmtBytes(tx), 16f, Ds.TEXT, Ds.DISPLAY); sessTxTv = x
            val d = tv(if (tm.connectedAt > 0) fmtDuration(System.currentTimeMillis() - tm.connectedAt) else "00:00:00", 16f, Ds.TEXT, Ds.DISPLAY); sessDurTv = d
            addView(sessRow("↓", t("Données reçues", "Data received"), r), lin(MATCH, WRAP, 14))
            addView(sessRow("↑", t("Données envoyées", "Data sent"), x), lin(MATCH, WRAP, 12))
            addView(sessRow("◷", t("Durée observée", "Observed time"), d), lin(MATCH, WRAP, 12))
        }, lin(MATCH, WRAP, 12))

        val h = tm.history()
        if (h.isNotEmpty()) {
            addView(overline(t("Sessions précédentes", "Previous sessions")), lin(WRAP, WRAP, 24))
            h.take(10).forEach { e ->
                addView(card().apply {
                    addView(row().apply {
                        addView(tv(fmtDate(e.start, "d MMM · HH:mm"), 15f, Ds.TEXT, Ds.DISPLAY), lin(0, WRAP, 0, 1f))
                        addView(tv(fmtDuration(e.end - e.start), 15f, Ds.WARM, Ds.MONO))
                    })
                    addView(row().apply {
                        addView(tv("↓ ${fmtBytes(e.rx)}", 13f, Ds.ACCENT2, Ds.MONO), lin(0, WRAP, 0, 1f))
                        addView(tv("↑ ${fmtBytes(e.tx)}", 13f, Ds.ON, Ds.MONO))
                    }, lin(MATCH, WRAP, 8))
                }, lin(MATCH, WRAP, 10))
            }
        }
    }

    private fun legend(label: String, color: Int) = row().apply {
        background = glass(18f); setPadding(14.dp, 9.dp, 16.dp, 9.dp)
        addView(View(context).apply { background = rect(color, 10f) }, lin(10.dp, 10.dp))
        addView(tv(label, 13f, Ds.TEXT, Ds.DISPLAY), lin(WRAP, WRAP).apply { leftMargin = 8.dp })
    }

    private fun rateCard(label: String, arrow: String, color: Int, value: TextView) = card().apply {
        addView(row().apply {
            addView(tv(arrow, 18f, color, Ds.BLACK).apply { gravity = Gravity.CENTER; background = rect(Ds.SURFACE2, 12f) }, lin(34.dp, 34.dp))
            addView(tv(label, 14f, Ds.MUTED, Ds.DISPLAY), lin(WRAP, WRAP).apply { leftMargin = 10.dp })
        })
        addView(value, lin(WRAP, WRAP, 12))
        addView(tv("${unitName()} · ${t("en direct", "live")}", 12f, Ds.MUTED, Ds.BODY), lin(WRAP, WRAP, 2))
    }

    private fun sessRow(icon: String, label: String, value: TextView) = row().apply {
        addView(tv(icon, 18f, Ds.MUTED, Ds.BLACK).apply { gravity = Gravity.CENTER }, lin(34.dp, WRAP))
        addView(tv(label, 15f, Ds.MUTED, Ds.BODY), lin(0, WRAP, 0, 1f).apply { leftMargin = 10.dp })
        addView(value)
    }

    // ---------------------------------------------------------------- réglages

    private fun section(s: String) = overline(s).apply { setPadding(8.dp, 0, 0, 0) }

    private fun settingsScreen(): View = col(20).apply {
        addView(header(), lin())
        addView(tv(t("À votre façon", "Your way"), 30f, Ds.TEXT, Ds.BLACK), lin(WRAP, WRAP, 18))
        addView(tv(t("Les réglages qui vous sont utiles.", "The settings you actually need."), 15f, Ds.MUTED, Ds.SERIF), lin(WRAP, WRAP, 2))

        addView(section(t("Connexion", "Connection")), lin(WRAP, WRAP, 22))
        addView(settingRow(t("Activation", "Activation"), t("Activer un nouveau forfait", "Activate a new plan")) {
            AlertDialog.Builder(context, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(t("Nouveau forfait", "New plan"))
                .setMessage(t("Pour utiliser une autre clé, cet appareil sera réinitialisé puis vous saisirez la nouvelle clé. Pour recharger la même clé, demandez simplement à votre vendeur : rien à faire ici.",
                    "To use another key, this device will be reset and you will enter the new key. To top up the same key, just ask your seller: nothing to do here."))
                .setNegativeButton(t("Annuler", "Cancel"), null)
                .setPositiveButton(t("Continuer", "Continue")) { _, _ -> scope.launch { tm.reset(); conn = Conn.IDLE; tab = 0; error = null; render() } }.show()
        }, lin(MATCH, WRAP, 10))
        addView(settingRow(t("Notifications", "Notifications"), t("Gérer les notifications Android", "Manage Android notifications")) {
            runCatching { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) }
        }, lin(MATCH, WRAP, 10))

        addView(section(t("Application", "App")), lin(WRAP, WRAP, 22))
        addView(settingRow(t("Mettre à jour l'application", "Update the app"),
            updateMsg ?: (if (update == null) t("DARK_SURF est à jour · Version ${BuildConfig.VERSION_NAME}", "DARK_SURF is up to date · Version ${BuildConfig.VERSION_NAME}")
            else t("Version ${update!!.versionName} disponible", "Version ${update!!.versionName} available"))) {
            if (update != null) { tab = 0; render() } else checkUpdate(manual = true)
        }, lin(MATCH, WRAP, 10))

        addView(section(t("Confort", "Comfort")), lin(WRAP, WRAP, 22))
        addView(settingRow(t("Langue", "Language"), if (Lang.fr) "Français" else "English") {
            AlertDialog.Builder(context, android.R.style.Theme_Material_Dialog_Alert).setTitle(t("Langue", "Language"))
                .setItems(arrayOf("Français", "English")) { _, i -> Lang.fr = i == 0; prefs.edit().putBoolean("fr", Lang.fr).apply(); render() }.show()
        }, lin(MATCH, WRAP, 10))
        addView(settingRow(t("Unité des débits", "Speed unit"),
            if (unitName() == "MB/s") t("Mégaoctets par seconde · MB/s", "Megabytes per second · MB/s") else t("Mégabits par seconde · Mb/s", "Megabits per second · Mb/s")) {
            AlertDialog.Builder(context, android.R.style.Theme_Material_Dialog_Alert).setTitle(t("Unité des débits", "Speed unit"))
                .setItems(arrayOf("MB/s", "Mb/s")) { _, i -> prefs.edit().putString("unit", if (i == 0) "MBps" else "Mbps").apply(); render() }.show()
        }, lin(MATCH, WRAP, 10))
        addView(switchRow(t("Retour tactile", "Haptic feedback"), t("Une vibration lors des actions", "A vibration on actions"), prefs.getBoolean("haptics", true)) {
            prefs.edit().putBoolean("haptics", it).apply()
        }, lin(MATCH, WRAP, 10))

        addView(section(t("Vos informations", "Your information")), lin(WRAP, WRAP, 22))
        addView(settingRow(t("Informations de connexion", "Connection information"), t("Comprendre ce qui est affiché", "Understand what is shown")) {
            AlertDialog.Builder(context, android.R.style.Theme_Material_Dialog_Alert).setTitle(t("Informations de connexion", "Connection information"))
                .setMessage(t(
                    "• Réception / Envoi : les données échangées par le tunnel pendant la session.\n• Le forfait affiché vient du serveur ; il est mis à jour toutes les 30 secondes quand vous êtes connecté.\n• Le VPN ne limite pas votre débit : la vitesse dépend de votre réseau mobile ou Wi-Fi.\n• Rien n'est enregistré sur ce que vous consultez.",
                    "• Download / Upload: data exchanged by the tunnel during the session.\n• The plan shown comes from the server and refreshes every 30 seconds while connected.\n• The VPN does not limit your speed: it depends on your mobile or Wi-Fi network.\n• Nothing is recorded about what you browse."))
                .setPositiveButton("OK", null).show()
        }, lin(MATCH, WRAP, 10))
        addView(settingRow(t("Effacer le suivi en direct", "Clear live tracking"), t("Réinitialiser la courbe et l'historique", "Reset the chart and history")) {
            rxHist.clear(); txHist.clear(); lastRx = 0; lastTx = 0; scope.launch { tm.clearHistory(); render() }
        }, lin(MATCH, WRAP, 10))

        addView(tv("DARK_SURF · Version ${BuildConfig.VERSION_NAME}", 12f, Ds.MUTED, Ds.MONO).apply { gravity = Gravity.CENTER }, lin(MATCH, WRAP, 28))
        addView(signature(), lin(MATCH, WRAP, 10))
    }

    // -------------------------------------------------------------------- aide

    private fun helpScreen(): View = col(20).apply {
        addView(header(), lin())
        addView(tv(t("On vous accompagne", "We are here to help"), 30f, Ds.TEXT, Ds.BLACK), lin(WRAP, WRAP, 18))
        addView(tv(t("Des réponses simples, au bon endroit.", "Simple answers, in the right place."), 15f, Ds.MUTED, Ds.SERIF), lin(WRAP, WRAP, 2))

        addView(section(t("Diagnostic du réseau", "Network check")), lin(WRAP, WRAP, 22))
        addView(card().apply {
            addView(row().apply {
                addView(FrameLayout(context).apply {
                    background = rect(Ds.SURFACE2, 16f)
                    addView(IconView(context, "check").apply { tint = Ds.ACCENT2 }, FrameLayout.LayoutParams(26.dp, 26.dp, Gravity.CENTER))
                }, lin(52.dp, 52.dp))
                addView(tv(t("Vérifier ma connexion", "Check my connection"), 18f, Ds.TEXT, Ds.DISPLAY), lin(0, WRAP, 0, 1f).apply { leftMargin = 14.dp })
            })
            diagMsg?.let { addView(tv(it, 14f, if (diagOk) Ds.ON else Ds.DANGER, Ds.BODY), lin(WRAP, WRAP, 12)) }
            addView(primaryButton(t("Lancer la vérification", "Run the check")) { runDiagnostic() }, lin(MATCH, WRAP, 14))
        }, lin(MATCH, WRAP, 10))

        addView(section(t("Les questions fréquentes", "Frequently asked questions")), lin(WRAP, WRAP, 22))
        val faq = listOf(
            t("Comment me connecter ?", "How do I connect?") to t("Appuyez sur le grand bouton rond de l'accueil. Au premier lancement, Android demande l'autorisation VPN : acceptez.", "Tap the big round button on Home. On first launch Android asks for VPN permission: accept."),
            t("La connexion ne démarre pas", "The connection does not start") to t("Vérifiez votre accès Internet, puis lancez le diagnostic ci-dessus. Si le message parle d'interception, changez de réseau Wi-Fi. Vérifiez aussi que votre forfait n'est pas expiré ou épuisé.", "Check your Internet access, then run the check above. If it mentions interception, switch Wi-Fi network. Also check your plan is not expired or used up."),
            t("Que représentent les compteurs de l'accueil ?", "What do the Home counters show?") to t("Les données reçues et envoyées par le tunnel depuis le début de la session, et ce qu'il reste sur votre forfait.", "Data received and sent through the tunnel since the session began, and what is left on your plan."),
            t("Pourquoi le débit varie-t-il ?", "Why does speed vary?") to t("Le VPN ne bride pas la vitesse. Elle dépend de votre réseau (signal, Wi-Fi, heure) et de la distance au serveur.", "The VPN does not throttle speed. It depends on your network (signal, Wi-Fi, time of day) and distance to the server."),
            t("Puis-je fermer l'application ?", "Can I close the app?") to t("Oui : le VPN continue en arrière-plan. Coupez-le depuis le bouton de l'accueil.", "Yes: the VPN keeps running in the background. Turn it off with the Home button."),
            t("Mon forfait est épuisé ou expiré", "My plan is used up or expired") to t("Demandez à votre vendeur de recharger votre clé (la même) puis reconnectez-vous.", "Ask your seller to top up your key (the same one), then reconnect."),
        )
        addView(card().apply {
            faq.forEachIndexed { i, (q, a) ->
                if (i > 0) addView(View(context).apply { setBackgroundColor(Ds.LINE) }, lin(MATCH, 1.dp, 0))
                addView(col().apply {
                    setPadding(0, 14.dp, 0, 14.dp)
                    addView(row().apply {
                        addView(tv(q, 16f, Ds.TEXT, Ds.DISPLAY), lin(0, WRAP, 0, 1f))
                        addView(tv(if (i in faqOpen) "⌃" else "›", 22f, Ds.MUTED, Ds.BODY))
                    })
                    if (i in faqOpen) addView(tv(a, 14f, Ds.MUTED, Ds.BODY), lin(WRAP, WRAP, 8))
                    setOnClickListener { if (!faqOpen.add(i)) faqOpen.remove(i); render() }
                })
            }
        }, lin(MATCH, WRAP, 10))

        addView(card().apply {
            addView(row().apply {
                addView(FrameLayout(context).apply {
                    background = rect(Ds.SURFACE2, 16f)
                    addView(tv("i", 22f, Ds.ACCENT2, Ds.BLACK).apply { gravity = Gravity.CENTER })
                }, lin(48.dp, 48.dp))
                addView(tv(t("Un problème persiste ?", "Still a problem?"), 18f, Ds.TEXT, Ds.DISPLAY), lin(0, WRAP, 0, 1f).apply { leftMargin = 14.dp })
            })
            addView(tv(t("Préparez un résumé de l'état de l'application à communiquer à l'assistance.", "Prepare a summary of the app state to send to support."), 14f, Ds.MUTED, Ds.BODY), lin(WRAP, WRAP, 12))
            addView(ghostButton(t("Prévisualiser le résumé", "Preview the summary")) { showSummary() }, lin(MATCH, WRAP, 14))
        }, lin(MATCH, WRAP, 16))

        addView(tv(t("À propos de DARK_SURF", "About DARK_SURF"), 15f, Ds.ACCENT2, Ds.DISPLAY).apply {
            gravity = Gravity.CENTER
            setOnClickListener {
                AlertDialog.Builder(context, android.R.style.Theme_Material_Dialog_Alert).setTitle("DARK_SURF")
                    .setMessage("Version ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})\n" + t("Votre internet, sans limites.\nSupport : +237 621 86 21 34", "Your internet, without limits.\nSupport: +237 621 86 21 34"))
                    .setPositiveButton("OK", null).show()
            }
        }, lin(MATCH, WRAP, 22))
        addView(signature(), lin(MATCH, WRAP, 18))
    }

    private fun runDiagnostic() {
        diagMsg = t("Vérification…", "Checking…"); diagOk = true; render()
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val u = URL(BuildConfig.API_BASE).let { "${it.protocol}://${it.host}/healthz" }
                    (URL(u).openConnection() as HttpURLConnection).run { connectTimeout = 6000; readTimeout = 6000; val c = responseCode; disconnect(); c in 200..299 }
                }.getOrDefault(false)
            }
            diagOk = ok
            diagMsg = if (ok) t("L'accès à Internet et au service a été vérifié avec succès.", "Internet and service access verified successfully.")
            else t("Le service est injoignable. Vérifiez votre connexion ou changez de réseau.", "The service is unreachable. Check your connection or switch network.")
            render()
        }
    }

    private fun summaryText(): String {
        val p = tm.plan()
        return listOf(
            "DARK_SURF ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
            "Android ${android.os.Build.VERSION.RELEASE} · ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}",
            "Appareil : ${tm.deviceId()?.take(13) ?: "—"}…",
            "État : ${conn.name}",
            "Forfait : ${p?.name ?: "—"}${p?.let { " · exp. " + fmtDate(it.expiresAt * 1000, "d MMM yyyy HH:mm") } ?: ""}",
            "Dernier message : ${error ?: "aucun"}",
        ).joinToString("\n")
    }

    private fun showSummary() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setTitle(t("Résumé pour l'assistance", "Summary for support"))
            .setMessage(summaryText())
            .setNegativeButton(t("Fermer", "Close"), null)
            .setPositiveButton(t("Envoyer au support", "Send to support")) { _, _ -> openSupport(summaryText()) }.show()
    }

    // --------------------------------------------------------------- navigation

    private fun bottomNav(): View {
        val bar = row().apply {
            setBackgroundColor(Ds.SURFACE); clipChildren = false; clipToPadding = false
            setPadding(0, 6.dp, 0, 6.dp)
        }
        val items = listOf(
            Triple("home", t("Accueil", "Home"), 0), Triple("activity", t("Activité", "Activity"), 1),
            Triple("", "", -1),
            Triple("settings", t("Réglages", "Settings"), 2), Triple("help", t("Aide", "Help"), 3),
        )
        items.forEach { (kind, label, idx) ->
            if (idx == -1) { bar.addView(centerButton(), lin(0, 58.dp, 0, 1f)); return@forEach }
            val sel = tab == idx
            bar.addView(col().apply {
                gravity = Gravity.CENTER
                val icon = IconView(context, kind).apply { tint = if (sel) Ds.ACCENT else Ds.MUTED }
                addView(FrameLayout(context).apply {
                    if (sel) background = rect(Ds.SURFACE2, 14f)
                    addView(icon, FrameLayout.LayoutParams(22.dp, 22.dp, Gravity.CENTER))
                }, lin(54.dp, 30.dp))
                addView(tv(label, 11f, if (sel) Ds.TEXT else Ds.MUTED, Ds.DISPLAY, 0.04f), lin(WRAP, WRAP, 3))
                setOnClickListener { tab = idx; render() }
            }, lin(0, 58.dp, 0, 1f))
        }
        return bar
    }

    private fun centerButton(): View = col().apply {
        gravity = Gravity.CENTER_HORIZONTAL; clipChildren = false
        val badge = PowerBadge(context).apply { busy = conn == Conn.CONNECTING || conn == Conn.DISCONNECTING }
        addView(FrameLayout(context).apply {
            translationY = -14f.dp; clipChildren = false
            addView(badge, FrameLayout.LayoutParams(50.dp, 50.dp, Gravity.CENTER))
        }, lin(64.dp, 32.dp))
        addView(
            tv(if (conn == Conn.CONNECTED) t("Couper", "Stop") else t("Connexion", "Connect"), 11f, Ds.TEXT, Ds.DISPLAY, 0.04f).apply {
                gravity = Gravity.CENTER
            }, lin(WRAP, WRAP, 3)
        )
        setOnClickListener { toggle() }
    }
    // ------------------------------------------------------------- connexion

    private fun toggle() {
        when (conn) {
            Conn.IDLE -> {
                if (update?.required == true) {
                    error = t("Une mise à jour obligatoire est disponible.", "A required update is available."); render(); return
                }
                val i = VpnService.prepare(this); if (i != null) vpnPermission.launch(i) else doConnect()
            }
            Conn.CONNECTED -> doDisconnect()
            else -> Unit
        }
    }

    private fun doConnect() {
        conn = Conn.CONNECTING; error = null; phase = 0; render()
        tm.stage = { _, _, _ -> runOnUiThread { phase++; orbView?.let { it.tint = stateAccent() }; quoteViews?.paint(stateAccent()) } }
        scope.launch {
            try {
                tm.connect(); conn = Conn.CONNECTED; rx = 0; tx = 0
            } catch (e: CancellationException) { throw e
            } catch (e: ApiException) { conn = Conn.IDLE; error = apiMessage(e)
            } catch (e: Exception) { conn = Conn.IDLE; error = t("Connexion impossible : ", "Could not connect: ") + (e.message ?: "") }
            render()
        }
    }

    private fun doDisconnect() {
        conn = Conn.DISCONNECTING; phase = 0; render()
        scope.launch {
            runCatching { tm.disconnect() }
            conn = Conn.IDLE; phase = 0; render()
        }
    }

    private fun apiMessage(e: ApiException) = when (e.kind) {
        ApiError.Rejected -> if (e.code == "bad_code_format") t("Ce code n'a pas le bon format.", "This code is not in the right format.")
        else t("Le service a refusé la demande. Mettez l'application à jour.", "The service refused the request. Update the app.")
        ApiError.Unauthorized -> t("Appareil non reconnu. Réinitialisez-le dans les réglages.", "Device not recognised. Reset it in settings.")
        ApiError.Forbidden -> when (e.code) {
            "device_limit" -> t("Limite d'appareils atteinte.", "Device limit reached.")
            "invalid_code" -> t("Code invalide ou déjà utilisé.", "Invalid or already used code.")
            "plan_expired" -> t("Votre forfait a expiré. Demandez à votre vendeur de recharger votre clé.", "Your plan has expired. Ask your seller to top up your key.")
            "quota_exceeded" -> t("Données épuisées. Demandez à votre vendeur de recharger votre clé.", "Data used up. Ask your seller to top up your key.")
            "outside_window" -> t("Ce forfait ne fonctionne que pendant sa plage horaire (ex. de 00h à 06h). Réessayez à ce moment-là.", "This plan only works during its time window (e.g. 00h–06h). Try again then.")
            else -> t("Accès refusé.", "Access denied.")
        }
        ApiError.RateLimited -> t("Trop de tentatives. Patientez quelques minutes.", "Too many attempts. Wait a few minutes.")
        ApiError.ServerBusy -> t("Service momentanément indisponible.", "Service temporarily unavailable.")
        ApiError.Unreachable -> t("Service injoignable. Vérifiez votre accès Internet.", "Cannot reach the service. Check your Internet access.")
        ApiError.Timeout -> t("Le serveur met trop de temps à répondre. Réessayez dans un instant.", "The server is taking too long to respond. Try again shortly.")
        ApiError.Intercepted -> t("Connexion interceptée (certificat invalide). Changez de réseau.", "Connection intercepted (invalid certificate). Switch network.")
    }
    // ------------------------------------------------------------ mise à jour

    private fun checkUpdate(manual: Boolean) {
        val last = prefs.getLong("upd_check", 0)
        if (!manual && System.currentTimeMillis() - last < 6 * 3600_000L) return     // au plus toutes les 6 h
        if (manual) { updateMsg = t("Vérification…", "Checking…"); render() }
        scope.launch {
            try {
                val info = withContext(Dispatchers.IO) { Api().checkUpdate(BuildConfig.VERSION_CODE) }
                prefs.edit().putLong("upd_check", System.currentTimeMillis()).apply()
                update = info
                if (manual) updateMsg = if (info == null) t("Vous avez la dernière version.", "You have the latest version.")
                else t("Version ${info.versionName} disponible (page Accueil).", "Version ${info.versionName} available (Home tab).")
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) {
                if (manual) updateMsg = t("Vérification impossible pour le moment.", "Could not check right now.")
            }
            if (tm.isEnrolled()) render()      // ne pas reconstruire l'écran d'activation (saisie en cours)
        }
    }

    private fun updateCard(info: UpdateInfo): View = card().apply {
        background = rect(Ds.SURFACE2, 20f, Ds.WARM, 1)
        addView(overline(if (info.required) t("Mise à jour obligatoire", "Required update") else t("Mise à jour disponible", "Update available")))
        addView(tv("DARK_SURF ${info.versionName}", 20f, Ds.TEXT, Ds.DISPLAY), lin(WRAP, WRAP, 6))
        if (info.notes.isNotBlank()) addView(tv(info.notes, 14f, Ds.MUTED, Ds.SERIF), lin(WRAP, WRAP, 4))
        val status = tv(updateStatus ?: "", 13f, Ds.WARM, Ds.MONO)
        addView(status, lin(WRAP, WRAP, 8))
        addView(primaryButton(t("Mettre à jour", "Update")) { startUpdate(info, status) }, lin(MATCH, WRAP, 12))
    }

    private fun startUpdate(info: UpdateInfo, status: TextView) {
        if (updating) return
        if (!Updater.canInstall(this)) {
            updateStatus = t("Autorise l'installation pour DARK_SURF, puis reviens ici.", "Allow installs for DARK_SURF, then come back.")
            status.text = updateStatus
            Updater.requestInstallPermission(this); return
        }
        updating = true
        scope.launch {
            try {
                val apk = withContext(Dispatchers.IO) {
                    Updater.download(this@MainActivity, info) { p ->
                        runOnUiThread { status.text = t("Téléchargement… $p %", "Downloading… $p%") }
                    }
                }
                status.text = t("Prêt à installer.", "Ready to install.")
                Updater.install(this@MainActivity, apk)
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) {
                updateStatus = updateError(e); status.text = updateStatus
            } finally { updating = false }
        }
    }

    private fun updateError(e: Exception) = when ((e as? Updater.UpdateException)?.reason) {
        "bad_checksum" -> t("Fichier corrompu : réessaie.", "Corrupted file: try again.")
        "bad_signature" -> t("Signature invalide : mise à jour refusée.", "Invalid signature: update refused.")
        "untrusted_url" -> t("Adresse de téléchargement non autorisée.", "Download address not allowed.")
        "bad_size" -> t("Fichier de taille inattendue : mise à jour refusée.", "Unexpected file size: update refused.")
        else -> t("Téléchargement impossible. Vérifie ta connexion.", "Download failed. Check your connection.")
    }
    private fun showRules() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(t("Bienvenue sur DARK_SURF", "Welcome to DARK_SURF"))
            .setMessage(
                t(
                    "Avant de commencer, lisez les règles d'utilisation :\n\n• Utilisez le service dans le respect de la loi.\n• Ne partagez pas votre code d'activation.\n• Un code est lié à un nombre limité d'appareils.",
                    "Before you start, please read the rules for using the service:\n\n• Use the service lawfully.\n• Do not share your activation code.\n• A code is tied to a limited number of devices."
                )
            )
            .setCancelable(false)
            .setPositiveButton(t("J'ai compris", "I understand")) { _, _ -> prefs.edit().putBoolean("rules", true).apply() }
            .show()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        tm.listener = null; tm.onPlanChanged = null
        scope.cancel()
        super.onDestroy()
    }

    private companion object { const val SUPPORT_WA = "237621862134" }
}
