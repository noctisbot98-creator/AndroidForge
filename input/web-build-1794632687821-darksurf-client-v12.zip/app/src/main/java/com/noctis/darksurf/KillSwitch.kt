package com.noctis.darksurf

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor

/**
 * Kill switch DARK_SURF.
 *
 * Principe : quand le tunnel principal est coupé, on établit un VPN « vide » qui capture
 * TOUT le trafic (0.0.0.0/0 et ::/0) mais ne possède aucune route sortante utilisable.
 * Résultat : les applications ne peuvent plus joindre Internet tant que le VPN n'est pas
 * rétabli — c'est exactement le comportement attendu d'un kill switch.
 *
 * Android n'autorise qu'un seul VPN actif à la fois : ce service est donc arrêté
 * AVANT le démarrage du tunnel Xray (voir MainActivity.doConnect / doDisconnect).
 */
class KillSwitch : VpnService() {

    private var pfd: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        goForeground()
        if (pfd == null) {
            pfd = runCatching {
                Builder()
                    .setSession("DARK_SURF · kill switch")
                    .addAddress("10.255.255.1", 32)
                    .addRoute("0.0.0.0", 0)
                    .addAddress("fd00:1:fd00:1::1", 128)
                    .addRoute("::", 0)
                    .setBlocking(true)
                    .establish()
            }.getOrNull()
        }
        return START_STICKY
    }

    private fun goForeground() {
        Notifier.ensureChannels(this)
        val n: Notification = Notification.Builder(this, Notifier.CH_INFO)
            .setContentTitle("DARK_SURF")
            .setContentText(getString(R.string.killswitch_active))
            .setSmallIcon(R.drawable.ic_stat)
            .setOngoing(true)
            .build()
        startForeground(NOTIF_ID, n)
    }

    override fun onDestroy() {
        runCatching { pfd?.close() }
        pfd = null
        super.onDestroy()
    }

    companion object {
        private const val NOTIF_ID = 4711
        const val ACTION_STOP = "com.noctis.darksurf.KILLSWITCH_STOP"

        fun start(ctx: Context) {
            runCatching {
                ctx.startForegroundService(Intent(ctx, KillSwitch::class.java))
            }
        }

        fun stop(ctx: Context) {
            runCatching {
                ctx.startService(Intent(ctx, KillSwitch::class.java).setAction(ACTION_STOP))
            }
        }
    }
}
