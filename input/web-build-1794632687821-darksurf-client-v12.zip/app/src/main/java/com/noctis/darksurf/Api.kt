package com.noctis.darksurf

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.SSLException

/** Erreurs métier, alignées sur docs/API.md. */
enum class ApiError { Rejected, Unauthorized, Forbidden, RateLimited, ServerBusy, Unreachable, Intercepted, Timeout }

class ApiException(val kind: ApiError, val code: String? = null) : IOException("$kind ${code ?: ""}")

/** Accès SSH propre à l'appareil (SSH-TCP / SSH-WS). Fourni par le serveur, jamais saisi par l'utilisateur. */
data class SshProfile(
    val host: String, val tcpPort: Int, val wsPort: Int,
    val username: String, val password: String, val wsPath: String, val hostKey: String,
) {
    fun toJson() = JSONObject().put("host", host).put("tcp_port", tcpPort).put("ws_port", wsPort)
        .put("username", username).put("password", password).put("ws_path", wsPath).put("host_key", hostKey)

    companion object {
        fun fromJson(j: JSONObject): SshProfile? {
            val host = j.optString("host").ifEmpty { return null }
            val user = j.optString("username").ifEmpty { return null }
            val pass = j.optString("password").ifEmpty { return null }
            val key = j.optString("host_key").ifEmpty { return null }
            return SshProfile(host, j.optInt("tcp_port", 2222), j.optInt("ws_port", 443), user, pass, j.optString("ws_path", "/ssh-ws"), key)
        }
    }
}

/**
 * Une façon de se connecter, dans l'ordre voulu par le serveur.
 * kind = "xray" (outbound complet) ou "ssh" (id = ssh-ws | ssh-tcp, identifiants dans Profile.ssh).
 */
data class Attempt(val id: String, val kind: String, val outbound: String?) {
    fun toJson() = JSONObject().put("id", id).put("kind", kind).also { j -> outbound?.let { j.put("outbound", JSONObject(it)) } }

    companion object {
        fun fromJson(j: JSONObject): Attempt? {
            val id = j.optString("id").ifEmpty { return null }
            val kind = j.optString("kind")
            if (kind != "xray" && kind != "ssh") return null
            val ob = j.optJSONObject("outbound")?.toString()
            if (kind == "xray" && ob == null) return null
            return Attempt(id, kind, ob)
        }
    }
}

/** Profil Xray renvoyé par le serveur (VLESS sur WebSocket + TLS, port 443). Aucun secret propre à l'appareil : l'UUID est attribué par le serveur. */
data class Profile(
    val address: String,        // hôte du serveur
    val port: Int,              // 443
    val uuid: String,
    val path: String,           // chemin WebSocket secret fourni par DARK SURF
    val sni: String,            // nom couvert par le certificat TLS
    val host: String,           // Host HTTP WebSocket (distinct du SNI si le serveur le demande)
    val dns: String,            // ex. "1.1.1.1"
    val ssh: SshProfile? = null, // identifiants SSH propres à cet appareil (fournis par le serveur)
) {
    fun toJson() = JSONObject()
        .put("address", address).put("port", port).put("uuid", uuid)
        .put("path", path).put("sni", sni).put("host", host).put("dns", dns)
        .also { j -> ssh?.let { j.put("ssh", it.toJson()) } }

    companion object {
        fun fromJson(j: JSONObject): Profile {
            val addr = j.getString("address").trim()
            val sni = j.optString("sni", addr).trim()
            val host = j.optString("host", sni).trim()
            val port = j.optInt("port", 443)
            val uuid = j.getString("uuid").trim()
            val path = j.getString("path").trim()
            val dns = j.optString("dns", "1.1.1.1").trim()
            require(addr.isNotEmpty() && sni.isNotEmpty() && host.isNotEmpty()) { "bad_server_host" }
            require(port in 1..65535) { "bad_server_port" }
            require(uuid.matches(Regex("^[0-9a-fA-F-]{32,36}$"))) { "bad_server_uuid" }
            require(path.startsWith("/") && !path.contains(" ")) { "bad_ws_path" }
            require(dns.isNotEmpty()) { "bad_dns" }
            return Profile(addr, port, uuid, path, sni, host, dns, j.optJSONObject("ssh")?.let(SshProfile::fromJson))
        }
    }
}

/** Forfait. quotaBytes == null -> illimité. */
data class Plan(
    val name: String, val quotaBytes: Long?, val usedBytes: Long, val expiresAt: Long,
    /** Plage horaire d'utilisation en minutes depuis minuit (heure du Cameroun), -1 = 24 h/24. */
    val windowStart: Int = -1, val windowEnd: Int = -1,
    /** Nom saisi par le vendeur sur la clé : affiché chez le client. */
    val clientName: String? = null,
) {
    fun toJson() = JSONObject().put("name", name).put("used_bytes", usedBytes).put("expires_at", expiresAt)
        .also { if (quotaBytes != null) it.put("quota_bytes", quotaBytes) }
        .also { if (windowStart >= 0) it.put("window", JSONObject().put("start", windowStart).put("end", windowEnd)) }
        .also { if (!clientName.isNullOrEmpty()) it.put("client_name", clientName) }

    /** « 00h–06h » ou null. */
    fun windowText(): String? = if (windowStart < 0) null else "%02dh–%02dh".format(windowStart / 60 % 24, windowEnd / 60 % 24)

    companion object {
        fun fromJson(j: JSONObject) = Plan(
            j.optString("name", "Plan"),
            if (j.isNull("quota_bytes") || !j.has("quota_bytes")) null else j.getLong("quota_bytes"),
            j.optLong("used_bytes"), j.optLong("expires_at"),
            j.optJSONObject("window")?.getInt("start") ?: -1, j.optJSONObject("window")?.getInt("end") ?: -1,
            j.optString("client_name", "").ifEmpty { null },
        )
    }
}

data class SessionResponse(val token: String, val expiresAt: Long, val profile: Profile, val plan: Plan?, val attempts: List<Attempt>)

data class Notice(val id: Int, val title: String, val body: String)

/** État du forfait renvoyé par /status : active | expired | quota_exceeded | revoked | disabled | outside_window. */
data class StatusResponse(val state: String, val now: Long, val plan: Plan, val notices: List<Notice>)

/** Version plus récente annoncée par le serveur. */
data class UpdateInfo(
    val versionCode: Int, val versionName: String, val url: String, val sha256: String,
    val size: Long, val notes: String, val required: Boolean,
)

class Api(private val base: String = BuildConfig.API_BASE) {

    fun enroll(code: String, label: String): String {
        val signingKey = DeviceIdentity.publicKeyB64()
        val signature = DeviceIdentity.sign("Tunnel/activate/v2\n$code\n$signingKey")
        val r = post(
            "enroll",
            JSONObject().put("code", code).put("signing_key", signingKey).put("label", label).put("signature", signature)
        )
        return r.getString("device_id")
    }

    fun session(deviceId: String, network: String): SessionResponse {
        val ch = post("challenge", JSONObject().put("device_id", deviceId))
        val challenge = ch.getString("challenge")
        val signature = DeviceIdentity.sign(ch.getString("message"))
        val r = post(
            "session",
            JSONObject().put("device_id", deviceId).put("challenge", challenge)
                .put("signature", signature).put("network", network)
        )
        return SessionResponse(
            token = r.getString("token"),
            expiresAt = r.getLong("expires_at"),
            profile = Profile.fromJson(r.getJSONObject("profile")),
            plan = r.optJSONObject("plan")?.let(Plan::fromJson),
            attempts = r.optJSONArray("attempts")?.let { a -> List(a.length()) { i -> a.getJSONObject(i) }.mapNotNull(Attempt::fromJson) }.orEmpty(),
        )
    }

    /** État du forfait + annonces, sans toucher au tunnel (même défi signé que la session). */
    fun status(deviceId: String, sinceNotice: Int): StatusResponse {
        val ch = post("challenge", JSONObject().put("device_id", deviceId))
        val signature = DeviceIdentity.sign(ch.getString("message"))
        val r = post(
            "status",
            JSONObject().put("device_id", deviceId).put("challenge", ch.getString("challenge"))
                .put("signature", signature).put("since_notice", sinceNotice)
        )
        val ns = r.optJSONArray("notices")
        val notices = List(ns?.length() ?: 0) { i -> ns!!.getJSONObject(i).let { Notice(it.getInt("id"), it.getString("title"), it.getString("body")) } }
        return StatusResponse(r.getString("state"), r.getLong("now"), Plan.fromJson(r.getJSONObject("plan")), notices.sortedBy { it.id })
    }

    /** null = à jour. */
    fun checkUpdate(currentVersionCode: Int): UpdateInfo? {
        val r = post("app/android", JSONObject().put("version_code", currentVersionCode))
        if (!r.optBoolean("update")) return null
        return UpdateInfo(
            r.getInt("version_code"), r.getString("version_name"), r.getString("url"), r.getString("sha256").lowercase(),
            r.optLong("size"), r.optString("notes"), r.optBoolean("required"),
        )
    }

    private fun post(path: String, body: JSONObject): JSONObject {
        var target = URL(base + path)
        var hops = 0
        while (true) {
            val conn = target.openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 10_000
                conn.readTimeout = 15_000
                conn.doOutput = true
                conn.instanceFollowRedirects = false
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                val status = conn.responseCode
                // HttpURLConnection ne suit PAS une redirection sur un POST : il renvoie
                // le 3xx tel quel, avec un corps vide. On la suit nous-memes en rejouant
                // le POST sur la nouvelle adresse (Caddy redirige http -> https en 308).
                if (status in 300..399 && hops < 3) {
                    val loc = conn.getHeaderField("Location")
                    if (!loc.isNullOrBlank()) {
                        target = URL(target, loc)
                        hops++
                        continue
                    }
                }
                val text = (if (status < 400) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (status in 200..299) return JSONObject(text)
                val code = runCatching { JSONObject(text).optString("error") }.getOrNull()?.ifEmpty { null }
                throw ApiException(
                    when (status) {
                        401 -> ApiError.Unauthorized
                        403 -> ApiError.Forbidden
                        429 -> ApiError.RateLimited
                        in 500..599 -> ApiError.ServerBusy
                        else -> ApiError.Rejected
                    }, code
                )
            } catch (e: ApiException) {
                throw e
            } catch (e: SSLException) {
                throw ApiException(ApiError.Intercepted)   // certificat invalide / interception TLS
            } catch (e: java.net.SocketTimeoutException) {
                // Le serveur a reçu la requête mais n'a pas répondu à temps : ce n'est PAS
                // une absence d'Internet. Message distinct pour ne pas envoyer l'utilisateur
                // vérifier sa connexion alors que le problème est côté serveur.
                throw ApiException(ApiError.Timeout)
            } catch (e: IOException) {
                throw ApiException(ApiError.Unreachable)
            } finally {
                conn.disconnect()
            }
        }
    }
}
