package com.noctis.darksurf

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import org.json.JSONArray
import org.json.JSONObject

/**
 * Tunnel : VpnService Android + noyau Xray (bibliothèque libv2ray de AndroidLibXrayLite).
 * Le noyau lit directement l'interface TUN (descripteur de fichier) : pas de pont tun2socks à part.
 * L'appli elle-même est exclue du tunnel (API, mises à jour) : aucune boucle, aucun quota consommé par elle.
 */
class XrayVpnService : VpnService() {
    private var pfd: ParcelFileDescriptor? = null
    private var core: CoreController? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopTunnel(); return START_NOT_STICKY }
        // Deux formes acceptées :
        //  - EXTRA_OUTBOUND : l'outbound Xray complet fourni par /protocols (multi-protocoles) ;
        //  - EXTRA_PROFILE  : l'ancien profil VLESS/WS, conservé pour ne rien casser.
        val outboundJson = intent?.getStringExtra(EXTRA_OUTBOUND)
        val sshMode = intent?.getStringExtra(EXTRA_SSH_MODE)?.takeIf { it == "ssh-ws" || it == "ssh-tcp" }
        val profile = intent?.getStringExtra(EXTRA_PROFILE)?.let { runCatching { Profile.fromJson(JSONObject(it)) }.getOrNull() }
        if (profile == null || (outboundJson == null && sshMode == null && profile.address.isEmpty())) { fail("bad_profile"); return START_NOT_STICKY }
        if (sshMode != null && profile.ssh == null) { fail("ssh_profile_missing"); return START_NOT_STICKY }
        goForeground()
        Thread { startTunnel(profile, outboundJson, sshMode) }.start()
        return START_NOT_STICKY       // jamais relancé seul : la session et le forfait se vérifient côté appli
    }

    /** DNS fourni par le serveur : l'utilisateur n'a aucun réglage à faire. */
    private fun chosenDns(fallback: String): String = fallback

    private fun startTunnel(p: Profile, outboundJson: String?, sshMode: String?) = synchronized(LOCK) {
        try {
            stopCore()
            Libv2ray.initCoreEnv(filesDir.absolutePath, "")
            // SSH : le tunnel SSH ouvre un SOCKS local, que le noyau Xray (entrée TUN) utilise comme sortie.
            if (sshMode != null) SshTunnel.start(p.ssh!!, sshMode)
            // Le noyau ne doit PAS résoudre le nom du serveur lui-même (sa requête DNS passerait dans le tunnel qui n'existe pas encore) :
            // on le résout ici, hors tunnel (l'appli est exclue du VPN), et on lui donne l'adresse IP.
            val serverHost = if (outboundJson != null) outboundHost(outboundJson) else p.address
            val resolved = java.net.InetAddress.getAllByName(serverHost)
            val serverIp = resolved.firstOrNull { it is java.net.Inet4Address }?.hostAddress
                ?: resolved.firstOrNull { it is java.net.Inet6Address }?.hostAddress
                ?: throw IllegalStateException("dns_failed:" + serverHost)
            // Configure les deux familles IP pour éviter qu'un téléphone LTE IPv6-only
            // ou qu'une application demandant IPv6 ne reste sans route.
            val hasIpv6 = resolved.any { it is java.net.Inet6Address }
            val builder = Builder().setSession("DARK_SURF").setMtu(1400)
                .addAddress("10.10.14.2", 30)
                .addRoute("0.0.0.0", 0)
                .addDnsServer(chosenDns(p.dns))
                .setBlocking(false)
            if (hasIpv6) {
                builder.addAddress("fd10:10:14::2", 126)
                    .addRoute("::", 0)
                    .addDnsServer("2606:4700:4700::1111")
            }
            val b = builder
            runCatching { b.addDisallowedApplication(packageName) }
            val fd = b.establish() ?: throw IllegalStateException("vpn_denied")
            pfd = fd
            val c = Libv2ray.newCoreController(object : CoreCallbackHandler {
                override fun startup(): Long = 0
                override fun shutdown(): Long = 0
                override fun onEmitStatus(code: Long, msg: String?): Long = 0
            })
            // StartLoop(tunFd) positionne lui-même la variable xray.tun.fd attendue
            // par AndroidLibXrayLite ; ne pas écraser cette variable côté Java.
            val cfg = when {
                sshMode != null -> SshTunnel.socksConfig(p.dns)
                outboundJson != null -> configForOutbound(outboundJson, serverIp)
                else -> xrayConfig(p, serverIp)
            }
            c.startLoop(cfg, fd.fd)
            core = c
            error = null; running = true
        } catch (e: Throwable) {
            fail(e.message ?: e.javaClass.simpleName)
        }
    }

    /** Hôte du serveur, lu dans l'outbound fourni par le serveur (vnext ou servers). */
    private fun outboundHost(json: String): String {
        val o = JSONObject(json)
        val s = o.optJSONObject("settings") ?: throw IllegalStateException("bad_outbound")
        s.optJSONArray("vnext")?.optJSONObject(0)?.optString("address")?.takeIf { it.isNotEmpty() }?.let { return it }
        s.optJSONArray("servers")?.optJSONObject(0)?.optString("address")?.takeIf { it.isNotEmpty() }?.let { return it }
        throw IllegalStateException("bad_outbound")
    }

    private fun fail(why: String) {
        error = why; running = false
        stopCore()
        stopForegroundCompat(); stopSelf()
    }

    private fun stopCore() {
        runCatching { core?.stopLoop() }; core = null
        runCatching { SshTunnel.stop() }
        runCatching { pfd?.close() }; pfd = null
    }

    private fun stopTunnel() = synchronized(LOCK) {
        running = false
        stopCore()
        stopForegroundCompat(); stopSelf()
    }

    override fun onRevoke() { stopTunnel() }
    override fun onDestroy() { running = false; stopCore(); super.onDestroy() }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "VPN", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH).setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("DARK_SURF").setContentText(Lang.t("Connecté", "Connected"))
            .setContentIntent(open).setOngoing(true).build()
        runCatching {
            if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
            else startForeground(1, n)
        }
    }

    private fun stopForegroundCompat() { runCatching { stopForeground(STOP_FOREGROUND_REMOVE) } }

    companion object {
        const val ACTION_STOP = "com.noctis.darksurf.STOP"
        const val EXTRA_PROFILE = "profile"
        const val EXTRA_OUTBOUND = "outbound"
        const val EXTRA_SSH_MODE = "ssh_mode"
        private const val CH = "vpn"
        private val LOCK = Any()
        @Volatile var running = false
        @Volatile var error: String? = null

        /**
         * Configuration cliente Xray à partir d'un outbound fourni par /protocols.
         * L'outbound est repris tel quel (c'est le serveur qui fait autorité sur le
         * protocole, le transport et la sécurité) ; on remplace seulement l'adresse par
         * l'IP résolue hors tunnel, pour que le noyau n'ait pas à faire de DNS avant
         * que le tunnel existe.
         */
        fun configForOutbound(outboundJson: String, ip: String): String {
            val out = JSONObject(outboundJson)
            val s = out.optJSONObject("settings") ?: JSONObject()
            s.optJSONArray("vnext")?.optJSONObject(0)?.put("address", ip)
            s.optJSONArray("servers")?.optJSONObject(0)?.put("address", ip)
            // Camouflage : on fragmente la poignée de main TLS (premier paquet) pour les transports TCP chiffrés.
            val ss = out.optJSONObject("streamSettings")
            val sec = ss?.optString("security", "none") ?: "none"
            val net = ss?.optString("network", "tcp") ?: "tcp"
            val fragmentable = ss != null && net != "kcp" && (sec == "tls" || sec == "reality")
            if (fragmentable) {
                val sock = ss!!.optJSONObject("sockopt") ?: JSONObject().also { ss.put("sockopt", it) }
                sock.put("dialerProxy", "fragment")
            }
            val frag = JSONObject().put("tag", "fragment").put("protocol", "freedom")
                .put("settings", JSONObject().put("fragment", JSONObject().put("packets", "tlshello").put("length", "100-200").put("interval", "10-20")))
                .put("streamSettings", JSONObject().put("sockopt", JSONObject().put("tcpNoDelay", true)))
            val tun = JSONObject().put("tag", "tun").put("protocol", "tun")
                .put("settings", JSONObject().put("mtu", 1400))
                .put("sniffing", JSONObject().put("enabled", true).put("destOverride", JSONArray().put("http").put("tls")))
            val outs = JSONArray().put(out).put(JSONObject().put("tag", "direct").put("protocol", "freedom"))
            if (fragmentable) outs.put(frag)
            return JSONObject()
                .put("log", JSONObject().put("loglevel", "warning"))
                .put("inbounds", JSONArray().put(tun))
                .put("routing", JSONObject().put("domainStrategy", "AsIs"))
                .put("outbounds", outs)
                .toString()
        }

        /** Configuration cliente Xray : entrée TUN -> VLESS/WebSocket/TLS vers le serveur. */
        fun xrayConfig(p: Profile, ip: String): String {
            // Paramètres TLS alignés sur GENY : SNI explicite, empreinte Chrome et ALPN HTTP/1.1.
            // La validation du certificat reste active : aucun allowInsecure.
            val tls = JSONObject()
                .put("serverName", p.sni)
                .put("fingerprint", "chrome")
                .put("alpn", JSONArray().put("http/1.1"))
            val out = JSONObject().put("tag", "proxy").put("protocol", "vless")
                .put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject()
                    .put("address", ip).put("port", p.port)
                    .put("users", JSONArray().put(JSONObject().put("id", p.uuid).put("encryption", "none"))))))
                .put("streamSettings", JSONObject().put("network", "ws").put("security", "tls")
                    .put("tlsSettings", tls)
                    .put("wsSettings", JSONObject().put("path", p.path).put("headers", JSONObject().put("Host", p.host))))
            val tun = JSONObject().put("tag", "tun").put("protocol", "tun")
                .put("settings", JSONObject().put("mtu", 1400))
                .put("sniffing", JSONObject().put("enabled", true).put("destOverride", JSONArray().put("http").put("tls")))
            return JSONObject()
                .put("log", JSONObject().put("loglevel", "warning"))
                .put("inbounds", JSONArray().put(tun))
                .put("routing", JSONObject().put("domainStrategy", "AsIs"))
                .put("outbounds", JSONArray().put(out).put(JSONObject().put("tag", "direct").put("protocol", "freedom")))
                .toString()
        }
    }
}
