package com.noctis.darksurf

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.ensureChannels(this)
        StatusWorker.schedule(this)
    }
}
