import java.net.URL
import java.util.Properties
import java.util.zip.ZipFile

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val ksProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "com.noctis.darksurf"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.noctis.darksurf"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "1.3.0"
        ndk { abiFilters += listOf("arm64-v8a") }
        // Serveur DARK_SURF de l'utilisateur : HTTP direct sur l'IP (pas de domaine, donc pas de TLS).
        buildConfigField("String", "API_BASE", "\"https://vpn.zidanexmd.space/api/v1/\"")
        buildConfigField("String", "PANEL_URL", "\"https://15-235-111-58.sslip.io\"")
    }

    signingConfigs {
        create("release") {
            if (ksProps.containsKey("storeFile")) {
                storeFile = rootProject.file(ksProps.getProperty("storeFile"))
                storePassword = ksProps.getProperty("storePassword")
                keyAlias = ksProps.getProperty("keyAlias")
                keyPassword = ksProps.getProperty("keyPassword")
            }
        }
    }
    buildTypes {
        release {
            if (ksProps.containsKey("storeFile")) signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += setOf("META-INF/*.kotlin_module") }
    lint { checkReleaseBuilds = false; abortOnError = false }
}

val downloadXrayCore by tasks.registering {
    val aar = layout.projectDirectory.file("libs/libv2ray.aar")
    outputs.file(aar)
    doLast {
        val target = aar.asFile
        if (!target.exists() || target.length() < 10_000_000L) {
            target.parentFile.mkdirs()
            val tmp = File(target.parentFile, "libv2ray.aar.download")
            val url = URL("https://github.com/2dust/AndroidLibXrayLite/releases/download/v26.10.31/libv2ray.aar")
            try {
                url.openConnection().apply {
                    connectTimeout = 30_000
                    readTimeout = 300_000
                    setRequestProperty("User-Agent", "DARK-SURF-Android-Build")
                }.getInputStream().use { input -> tmp.outputStream().use { output -> input.copyTo(output) } }
                check(tmp.length() > 10_000_000L) { "Telechargement libv2ray.aar incomplet" }
                ZipFile(tmp).use { zip -> check(zip.getEntry("classes.jar") != null) { "Archive libv2ray.aar invalide" } }
                if (target.exists()) target.delete()
                check(tmp.renameTo(target)) { "Impossible d'installer libv2ray.aar" }
                logger.lifecycle("DARK SURF: moteur Xray telecharge (${target.length()} octets)")
            } finally { tmp.delete() }
        } else {
            logger.lifecycle("DARK SURF: moteur Xray deja present")
        }
    }
}

tasks.named("preBuild").configure { dependsOn(downloadXrayCore) }

dependencies {
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar"))))
    implementation("com.github.mwiede:jsch:0.2.21")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
}
