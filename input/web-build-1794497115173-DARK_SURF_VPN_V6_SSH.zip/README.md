# DARK_SURF (Android, Kotlin)

Client VPN : code TUN -> identité ECDSA (Android Keystore) -> session signée -> tunnel VPN Xray/TUN avec VLESS ou transport SSH.

- `app/` : application (ouvrir ce dossier dans Android Studio, puis éditer `API_BASE` dans `app/build.gradle.kts`).
- `server-mock/` : mock de l'API pour tester (`node server-mock/test.js`).
- `docs/API.md` : contrat client/serveur.
- Le backend attendu expose `POST /api/v1/enroll`, `challenge`, `session`, `status` et `app/android`.
- L’adresse API est configurée sur `https://15-235-111-58.sslip.io/api/v1/`. Le serveur doit renvoyer un profil VLESS dont `address`, `sni`, `port` et `path` correspondent à sa configuration Xray/Caddy.
- AndroidForge : `preBuild` télécharge automatiquement `libv2ray.aar` (AndroidLibXrayLite v26.10.31). Aucun pré-build manuel n’est nécessaire.

Le tunnel utilise `com.wireguard.android:tunnel` (WireGuard-go userspace + VpnService).


## Refonte visuelle professionnelle — novembre 2026

- Identité DARK SURF unifiée : pétrole profond `#071412`, surfaces `#102522`, turquoise `#00D6B8`, cuivre `#E6A45B`, texte `#F1F5F2`.
- Contraste et hiérarchie visuelle harmonisés entre les deux applications.
- Architecture réseau et logique métier conservées : VPN Xray/VLESS WebSocket + TLS pour l’application VPN ; portail vendeur HTTPS pour DARK SURF PRO.
- Cette livraison est un projet Android source pour AndroidForge, pas un APK précompilé.
