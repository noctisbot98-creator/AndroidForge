# DARK SURF — transports SSH

Les trois transports sont sélectionnables dans **Réglages → Mode de connexion**.

| Mode | Chemin réseau | Port côté VPS |
|---|---|---:|
| SSH-WS | SSH dans WebSocket sécurisé (WSS) via Caddy | 443 / `/ssh-ws` |
| SSH-TCP | SSH direct | 2222/tcp |
| SSH TCP Payload | HTTP CONNECT puis SSH | 2223/tcp |

Le client Android utilise JSch pour ouvrir un SOCKS dynamique local. Le noyau Xray conserve l'interface TUN Android et envoie les flux TCP dans ce SOCKS. Le compte SSH est propre à chaque appareil, créé à la première session autorisée et verrouillé par le backend lorsque l'accès n'est plus valide. L'installateur configure un `sshd` séparé sans shell, sans TTY, sans agent forwarding et limité au port-forwarding local.

**Limite de SSH :** ce transport transporte du TCP. Les usages qui exigent de l'UDP (certains jeux, appels ou applications temps réel) doivent rester sur VLESS. SSH-WS et Payload ne contournent pas les restrictions d'un opérateur ; ils fournissent un transport chiffré pour un serveur et un réseau que tu administres.

Après installation du serveur, vérifier les ports 2222/tcp et 2223/tcp dans le pare-feu du VPS et dans le pare-feu du fournisseur cloud. Le port 443 doit déjà être accessible pour HTTPS/WSS.
