// Panneau d'administration : /api/admin/* (session obligatoire + e-mail administrateur).
const express = require('express');
const crypto = require('crypto');
const database = require('../routes/func/database');
const activity = require('../routes/func/activity');
const health = require('./health');
const assistant = require('./assistant');
const { getSessionToken, verifySessionToken } = require('../routes/func/session');

const router = express.Router();
router.use(express.json({ limit: '50kb' }));

function adminEmails() {
  return String(process.env.ADMIN_EMAILS || 'zidanetedoum9@gmail.com')
    .split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
}

function getAdmin(req) {
  const decoded = verifySessionToken(getSessionToken(req));
  if (!decoded?.mail) return null;
  const user = database.getDatabaseByUser(decoded.mail);
  if (!user || user.isBanned || !user.isVerified) return null;
  if (decoded.userid && user.userId !== decoded.userid) return null;
  return adminEmails().includes(String(user.mail).toLowerCase()) ? user : null;
}

function requireAdmin(req, res, next) {
  const admin = getAdmin(req);
  if (!admin) return res.status(403).json({ status: false, message: 'Accès administrateur requis.' });
  req.admin = admin;
  res.setHeader('Cache-Control', 'no-store');
  next();
}

const limits = () => ({
  free: Number(process.env.free_user_limit || 20),
  premium: Number(process.env.premium_user_limit || 1000000),
});

function publicUser(u) {
  const l = limits();
  const limit = require('../routes/func/quota').getLimit(u);
  return {
    mail: u.mail, username: u.username || String(u.mail).split('@')[0], date: u.date, lastUsed: u.lastUsed, uses: u.uses || 0,
    isPremium: !!u.isPremium, isBanned: !!u.isBanned, isVerified: !!u.isVerified,
    customLimit: u.customLimit || null, limit, remaining: Math.max(0, limit - (u.uses || 0)),
    isAdmin: adminEmails().includes(String(u.mail).toLowerCase()),
  };
}

function rawUsers() {
  // getDatabase() retire le hash ; apikey conservée (l'admin la voit, jamais le mot de passe).
  return database.getDatabase();
}

router.get('/me', requireAdmin, (req, res) => {
  res.json({ status: true, mail: req.admin.mail, maintenance: activity.getSettings().maintenance });
});

router.get('/overview', requireAdmin, (req, res) => {
  const users = rawUsers();
  const rows = activity.all().filter((r) => r.type === 'api');
  const now = Date.now();
  const day = rows.filter((r) => now - Date.parse(r.t) < 24 * 3600 * 1000);
  const hours = Array.from({ length: 24 }, (_, i) => ({ h: i, n: 0, err: 0 }));
  const base = new Date(now); base.setMinutes(0, 0, 0);
  for (const r of day) {
    const idx = 23 - Math.floor((base.getTime() + 3600000 - Date.parse(r.t)) / 3600000);
    const cell = hours[Math.max(0, Math.min(23, idx))];
    cell.n++; if (r.status >= 400) cell.err++;
  }
  const count = (arr, key) => {
    const m = new Map();
    for (const r of arr) { const k = key(r); if (k) m.set(k, (m.get(k) || 0) + 1); }
    return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([name, n]) => ({ name, n }));
  };
  const avg = day.length ? Math.round(day.reduce((s, r) => s + (r.ms || 0), 0) / day.length) : 0;
  res.json({
    status: true,
    maintenance: activity.getSettings().maintenance,
    users: {
      total: users.length, premium: users.filter((u) => u.isPremium).length,
      banned: users.filter((u) => u.isBanned).length, unverified: users.filter((u) => !u.isVerified).length,
      totalUses: users.reduce((s, u) => s + (u.uses || 0), 0),
    },
    last24h: { requests: day.length, errors: day.filter((r) => r.status >= 400).length, avgMs: avg, activeUsers: new Set(day.map((r) => r.mail).filter(Boolean)).size },
    hours,
    topEndpoints: count(day, (r) => r.path),
    topUsers: count(day, (r) => r.mail),
    topErrors: count(day.filter((r) => r.status >= 400), (r) => `${r.status} ${r.path}`),
    loggedEvents: activity.all().length,
  });
});

router.get('/activity', requireAdmin, (req, res) => {
  const { limit, type, mail, status, q } = req.query;
  res.json({ status: true, rows: activity.query({ limit, type, mail, status, q }) });
});

router.get('/users', requireAdmin, (req, res) => {
  res.json({ status: true, users: rawUsers().map(publicUser).sort((a, b) => Date.parse(b.lastUsed || 0) - Date.parse(a.lastUsed || 0)) });
});

function applyUserAction(admin, mail, action, value) {
  const target = database.getDatabaseByUser(mail || '');
  if (!target) return { ok: false, code: 404, message: 'Utilisateur introuvable.' };
  const self = String(target.mail).toLowerCase() === String(admin.mail).toLowerCase();
  const protectedAdmin = adminEmails().includes(String(target.mail).toLowerCase());
  const fail = (message, code = 400) => ({ ok: false, code, message });
  let message = 'OK';
  switch (action) {
    case 'ban': case 'unban':
      if (self || protectedAdmin) return fail('Un compte administrateur ne peut pas être banni.');
      database.UpdateDatabase(target.mail, { isBanned: action === 'ban' }); message = action === 'ban' ? 'Compte banni.' : 'Compte débanni.'; break;
    case 'premium': case 'unpremium':
      database.UpdateDatabase(target.mail, { isPremium: action === 'premium' }); message = action === 'premium' ? 'Passé en premium.' : 'Premium retiré.'; break;
    case 'verify':
      database.UpdateDatabase(target.mail, { isVerified: true, verifyCode: undefined }); message = 'Compte vérifié.'; break;
    case 'resetuses':
      database.UpdateDatabase(target.mail, { uses: 0 }); message = 'Compteur remis à zéro.'; break;
    case 'setlimit': {
      const n = Math.trunc(Number(value));
      if (!Number.isFinite(n) || n < 0 || n > 1e9) return fail('Limite invalide.');
      database.UpdateDatabase(target.mail, { customLimit: n || undefined }); message = n ? `Limite personnalisée : ${n}.` : 'Limite personnalisée retirée.'; break;
    }
    case 'addrequests': {
      const n = Math.trunc(Number(value));
      if (!Number.isFinite(n) || n === 0 || Math.abs(n) > 1e9) return fail('Nombre de requêtes invalide.');
      const cur = require('../routes/func/quota').getLimit(target);
      const next = Math.max(0, cur + n);
      database.UpdateDatabase(target.mail, { customLimit: next });
      message = `${n > 0 ? '+' : ''}${n} requêtes : quota ${cur} → ${next}.`; break;
    }
    case 'setpassword': {
      const pw = String(value || '');
      if (pw.length < 6) return fail('6 caractères minimum.');
      const hashPassword = crypto.createHash('md5').update(pw).digest('hex');
      database.UpdateDatabase(target.mail, { hashPassword, userId: crypto.createHash('md5').update(target.mail + hashPassword).digest('hex') });
      message = 'Mot de passe modifié (ses sessions sont invalidées).'; break;
    }
    case 'delete':
      if (self || protectedAdmin) return fail('Un compte administrateur ne peut pas être supprimé.');
      database.DeleteDatabase(target.mail); message = 'Compte supprimé.'; break;
    default:
      return fail('Action inconnue.');
  }
  activity.record({ type: 'admin', mail: admin.mail, action, target: target.mail, status: 200 });
  return { ok: true, code: 200, message, target: target.mail };
}

router.post('/users/action', requireAdmin, (req, res) => {
  const { mail, action, value } = req.body || {};
  const r = applyUserAction(req.admin, mail, action, value);
  res.status(r.code).json({ status: r.ok, message: r.message });
});

function setMaintenance(admin, on) {
  activity.setSettings({ maintenance: !!on });
  activity.record({ type: 'admin', mail: admin.mail, action: on ? 'maintenance_on' : 'maintenance_off', status: 200 });
  return on ? 'Maintenance activée : l’API répond 503 aux clients.' : 'Maintenance désactivée.';
}

function clearLogs(admin) {
  activity.clear();
  activity.record({ type: 'admin', mail: admin.mail, action: 'logs_cleared', status: 200 });
  return 'Journal vidé.';
}

router.post('/maintenance', requireAdmin, (req, res) => {
  const on = !!req.body?.on;
  res.json({ status: true, maintenance: on, message: setMaintenance(req.admin, on) });
});

router.get('/app-config', requireAdmin, (req, res) => {
  res.json({ status: true, config: require('../routes/func/appconfig').get() });
});
router.post('/app-config', requireAdmin, (req, res) => {
  const cfg = require('../routes/func/appconfig').set(req.body || {});
  res.json({ status: true, message: 'Configuration de l\'application enregistrée.', config: cfg });
});

router.post('/logs/clear', requireAdmin, (req, res) => {
  res.json({ status: true, message: clearLogs(req.admin) });
});

// Santé du système + test de toutes les routes
router.get('/system', requireAdmin, (req, res) => res.json({ status: true, ...health.systemInfo(), blockedIps: activity.getSettings().blockedIps || [] }));
router.get('/health', requireAdmin, (req, res) => res.json({ status: true, ...health.getState() }));
router.post('/health/run', requireAdmin, (req, res) => {
  const r = health.start(req.admin);
  res.status(r.ok ? 200 : 409).json({ status: r.ok, message: r.message });
});

// Assistant (commandes en français)
router.post('/assistant', requireAdmin, (req, res) => {
  const reply = assistant.handle(req.admin, String(req.body?.message || '').slice(0, 300), { applyUserAction, setMaintenance, clearLogs, publicUser, rawUsers });
  res.json({ status: true, reply });
});

module.exports = { router, getAdmin, applyUserAction, setMaintenance, clearLogs, publicUser, rawUsers };
