// Assistant d'administration : comprend des ordres en français et pilote le système.
// Fonctionne sans IA externe : règles + mots-clés (aucune clé ni coût). Les actions
// destructrices demandent une confirmation ("oui") dans les 60 secondes.
const activity = require('../routes/func/activity');
const health = require('./health');

const pending = new Map(); // mail admin -> { run, label, at }
const EMAIL = /[^\s@]+@[^\s@]+\.[^\s@]+/;
const IPV = /\b(?:\d{1,3}\.){3}\d{1,3}\b|\b[0-9a-f:]{6,}\b/i;
const norm = (s) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
const fmtUp = (s) => { const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); return `${d ? d + 'j ' : ''}${h}h ${m}min`; };

const HELP = `Je peux faire :
• statut — état général (utilisateurs, requêtes, erreurs, mémoire)
• erreurs — dernières erreurs de l'API
• activité — dernières requêtes · activité de <mail ou ip>
• utilisateur <mail> — fiche complète
• top — utilisateurs et routes les plus actifs
• bannir / débannir <mail>
• premium / retirer premium <mail>
• limite <mail> <nombre> (0 = retirer)
• reset <mail> — remet son usage à zéro
• nouvelle clé <mail>
• supprimer <mail> (avec confirmation)
• bloquer ip <adresse> / débloquer ip <adresse> / ips bloquées
• maintenance on / maintenance off
• tester les routes — vérifie toutes les routes · résultat du test
• vider le journal (avec confirmation)`;

function userLine(u) {
  return `${u.mail} — ${u.uses}/${u.limit} requêtes${u.isPremium ? ' · premium' : ''}${u.isBanned ? ' · BANNI' : ''}${u.isVerified ? '' : ' · non vérifié'}`;
}

function handle(admin, raw, ctx) {
  const text = raw.trim();
  const t = norm(text);
  if (!t) return 'Écris un ordre, par exemple « statut » ou « aide ».';
  const key = String(admin.mail).toLowerCase();

  // Confirmation d'une action en attente
  if (/^(oui|confirme|confirmer|ok|yes)$/.test(t)) {
    const p = pending.get(key);
    pending.delete(key);
    if (!p || Date.now() - p.at > 60000) return 'Aucune action en attente de confirmation.';
    return p.run();
  }
  if (/^(non|annule|annuler|stop)$/.test(t)) { pending.delete(key); return 'Annulé.'; }
  const ask = (label, run) => { pending.set(key, { label, run, at: Date.now() }); return `⚠️ ${label}\nRéponds « oui » pour confirmer (60 s) ou « non » pour annuler.`; };

  const mail = (text.match(EMAIL) || [])[0];
  const users = ctx.rawUsers();
  const byMailOrKey = (needle) => users.find((u) => String(u.mail).toLowerCase() === String(needle).toLowerCase());
  const act = (action, value) => { const r = ctx.applyUserAction(admin, mail, action, value); return (r.ok ? '✅ ' : '❌ ') + r.message; };
  const needMail = () => 'Indique l’e-mail de l’utilisateur, par exemple : ' + (text.split(' ')[0] || 'bannir') + ' nom@exemple.com';

  if (/^(aide|help|\?|commandes)/.test(t)) return HELP;

  if (/^(statut|etat|status|resume|bilan)/.test(t)) {
    const rows = activity.all().filter((r) => r.type === 'api' && Date.now() - Date.parse(r.t) < 86400000);
    const errs = rows.filter((r) => r.status >= 400).length;
    const sys = health.systemInfo();
    const h = health.getState();
    return [
      `🟢 API en ligne depuis ${fmtUp(sys.uptimeSeconds)}${activity.getSettings().maintenance ? ' — ⚠️ MODE MAINTENANCE ACTIF' : ''}`,
      `Utilisateurs : ${users.length} (${users.filter((u) => u.isPremium).length} premium, ${users.filter((u) => u.isBanned).length} bannis)`,
      `24 h : ${rows.length} requêtes, ${errs} erreurs${rows.length ? ` (${Math.round(errs / rows.length * 100)} %)` : ''}`,
      `Mémoire : ${sys.rssMb} Mo · charge CPU : ${sys.load[0]}${sys.disk ? ` · disque libre : ${sys.disk.freeMb} Mo` : ''}`,
      h.finishedAt ? `Dernier test des routes : ${h.passed} OK / ${h.failed.length} en échec (${new Date(h.finishedAt).toLocaleString('fr-FR')})` : 'Aucun test de routes effectué — tape « tester les routes ».',
    ].join('\n');
  }

  if (/^(erreur|errors|probleme)/.test(t)) {
    const rows = activity.query({ status: 'error', limit: 10 });
    return rows.length ? 'Dernières erreurs :\n' + rows.map((r) => `• ${new Date(r.t).toLocaleTimeString('fr-FR')} ${r.status} ${r.method || ''} ${r.path || r.action} ${r.mail ? '(' + r.mail + ')' : ''}`).join('\n') : 'Aucune erreur récente 🎉';
  }

  if (/^(top|plus actif|classement)/.test(t)) {
    const rows = activity.all().filter((r) => r.type === 'api');
    const top = (k) => { const m = new Map(); rows.forEach((r) => r[k] && m.set(r[k], (m.get(r[k]) || 0) + 1)); return [...m].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([n, c]) => `• ${n} : ${c}`).join('\n') || '—'; };
    return `Utilisateurs les plus actifs :\n${top('mail')}\n\nRoutes les plus appelées :\n${top('path')}\n\nIP les plus actives :\n${top('ip')}`;
  }

  if (/^(activite|journal|logs?|dernieres? requetes)/.test(t) && !/vider|effacer/.test(t)) {
    const ip = (text.match(IPV) || [])[0];
    const rows = activity.query({ limit: 12, mail: mail || undefined, q: !mail && ip ? ip : undefined });
    return rows.length ? 'Activité récente :\n' + rows.map((r) => `• ${new Date(r.t).toLocaleTimeString('fr-FR')} ${r.type} ${r.status} ${r.method || ''} ${r.path || r.action || ''} ${r.mail || r.ip || ''}`).join('\n') : 'Aucune activité trouvée.';
  }

  if (/^(utilisateur|user|compte|info|fiche)/.test(t)) {
    const u = mail ? byMailOrKey(mail) : null;
    if (!u) return mail ? 'Utilisateur introuvable.' : needMail();
    const pu = ctx.publicUser(u);
    const last = activity.query({ limit: 5, mail: u.mail });
    return `${userLine(pu)}\nInscrit : ${u.date ? new Date(u.date).toLocaleDateString('fr-FR') : '?'} · dernier usage : ${u.lastUsed ? new Date(u.lastUsed).toLocaleString('fr-FR') : 'jamais'}\nDernières requêtes :\n` + (last.map((r) => `• ${new Date(r.t).toLocaleTimeString('fr-FR')} ${r.status} ${r.path}`).join('\n') || '—');
  }

  if (/^(debannir|unban)/.test(t)) return mail ? act('unban') : needMail();
  if (/^(bannir|ban)\b/.test(t)) return mail ? ask(`Bannir ${mail} ?`, () => act('ban')) : needMail();
  if (/^(retirer premium|enlever premium|unpremium|downgrade)/.test(t)) return mail ? act('unpremium') : needMail();
  if (/^(premium|passer premium|upgrade)/.test(t)) return mail ? act('premium') : needMail();
  if (/^(reset|remettre|raz)/.test(t)) return mail ? act('resetuses') : needMail();
  if (/^(verifier|verify|valider)/.test(t)) return mail ? act('verify') : needMail();
  if (/^(supprimer|delete|effacer le compte)/.test(t) && mail) return ask(`Supprimer définitivement le compte ${mail} ?`, () => act('delete'));
  if (/^(limite|quota)/.test(t)) {
    if (!mail) return needMail();
    const n = (text.replace(mail, '').match(/\d+/) || [])[0];
    return n == null ? 'Indique le nombre : limite ' + mail + ' 500' : act('setlimit', n);
  }

  if (/ips? bloquee?s?|liste.*ip/.test(t)) {
    const l = activity.getSettings().blockedIps || [];
    return l.length ? 'IP bloquées :\n' + l.map((i) => '• ' + i).join('\n') : 'Aucune IP bloquée.';
  }
  if (/(debloquer|deblo).*ip|^debloquer/.test(t)) {
    const ip = (text.match(IPV) || [])[0];
    if (!ip) return 'Indique l’adresse IP.';
    const l = (activity.getSettings().blockedIps || []).filter((i) => i !== ip);
    activity.setSettings({ blockedIps: l }); activity.record({ type: 'admin', mail: admin.mail, action: 'unblock_ip', target: ip, status: 200 });
    return `✅ ${ip} débloquée.`;
  }
  if (/^(bloquer|block)/.test(t)) {
    const ip = (text.match(IPV) || [])[0];
    if (!ip) return 'Indique l’adresse IP : bloquer ip 1.2.3.4';
    if (['127.0.0.1', '::1'].includes(ip)) return '❌ Impossible de bloquer l’adresse locale.';
    return ask(`Bloquer l’IP ${ip} ? Elle recevra une erreur 403.`, () => {
      const l = [...new Set([...(activity.getSettings().blockedIps || []), ip])];
      activity.setSettings({ blockedIps: l }); activity.record({ type: 'admin', mail: admin.mail, action: 'block_ip', target: ip, status: 200 });
      return `✅ ${ip} bloquée.`;
    });
  }

  if (/maintenance/.test(t)) {
    if (/\b(off|desactiv|arret|fin|quitt)/.test(t)) return '✅ ' + ctx.setMaintenance(admin, false);
    if (/\b(on|activ|lancer|demarr)/.test(t)) return ask('Activer la maintenance ? Tous les appels API répondront 503.', () => '✅ ' + ctx.setMaintenance(admin, true));
    return 'Dis « maintenance on » ou « maintenance off ».';
  }

  if (/(resultat|rapport).*(test|route)|^resultat/.test(t) || (/^(test|verifie|check)/.test(t) && /(resultat|rapport)/.test(t))) {
    const h = health.getState();
    if (h.running) return `Test en cours : ${h.done}/${h.total}…`;
    if (!h.finishedAt) return 'Aucun test effectué. Tape « tester les routes ».';
    return `Test du ${new Date(h.finishedAt).toLocaleString('fr-FR')} : ${h.passed} routes OK, ${h.failed.length} en échec.` + (h.failed.length ? '\n' + h.failed.slice(0, 25).map((f) => `• ${f.href.split('?')[0]} → ${f.code || 'ERR'} ${f.note}`).join('\n') + (h.failed.length > 25 ? `\n… et ${h.failed.length - 25} autres (voir le tableau de santé).` : '') : ' 🎉');
  }
  if (/^(test|verifie|check|diagnostic)/.test(t)) {
    const r = health.start(admin);
    return (r.ok ? '🔎 ' : '❌ ') + r.message + (r.ok ? '\nTape « résultat du test » dans une minute.' : '');
  }

  if (/(vider|effacer|supprimer).*(journal|logs?)/.test(t)) return ask('Vider tout le journal d’activité ?', () => '✅ ' + ctx.clearLogs(admin));

  return 'Je n’ai pas compris. Tape « aide » pour voir ce que je sais faire.';
}

module.exports = { handle };
