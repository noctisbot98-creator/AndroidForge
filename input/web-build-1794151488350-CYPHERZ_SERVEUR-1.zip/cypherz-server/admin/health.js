// Surveillance : infos système + test des moteurs d'IA (Groq principal, Gemini renfort).
const os = require('os');
const fs = require('fs');
const path = require('path');
const llm = require('../routes/func/llm');

const FILE = path.resolve(__dirname, '../activity/health.json');
let state = { running: false, startedAt: null, finishedAt: null, total: 0, done: 0, results: [] };
try { state = { ...state, ...JSON.parse(fs.readFileSync(FILE, 'utf8')), running: false }; } catch {}

async function probe(label, configured, fn) {
  const started = Date.now();
  if (!configured) return { href: label, label, ok: false, code: 0, ms: 0, note: 'clé non configurée sur le serveur' };
  try { const r = await fn(); return { href: label, label, ok: !!r.text, code: 200, ms: Date.now() - started, note: `modèle : ${r.model}` }; }
  catch (e) { return { href: label, label, ok: false, code: e.upstreamStatus || 0, ms: Date.now() - started, note: String(e.message || e).slice(0, 140) }; }
}

function start() {
  if (state.running) return { ok: false, message: 'Un test est déjà en cours.' };
  state = { running: true, startedAt: new Date().toISOString(), finishedAt: null, total: 2, done: 0, results: [] };
  (async () => {
    const ask = 'Réponds uniquement : OK';
    state.results.push(await probe('Groq (principal)', llm.hasGroq(), () => llm.askGroq(ask, { maxTokens: 20 }))); state.done++;
    state.results.push(await probe('Gemini (renfort)', llm.hasGemini(), () => llm.askGemini(ask, { maxTokens: 20 }))); state.done++;
    state.running = false; state.finishedAt = new Date().toISOString();
    try { fs.mkdirSync(path.dirname(FILE), { recursive: true }); fs.writeFileSync(FILE, JSON.stringify(state)); } catch {}
  })();
  return { ok: true, message: 'Test des moteurs d\'IA lancé (quelques secondes).' };
}

function getState() {
  const failed = state.results.filter((r) => !r.ok);
  return { ...state, results: undefined, passed: state.results.length - failed.length, failed };
}

function systemInfo() {
  const mem = process.memoryUsage();
  let disk = null;
  try { const s = fs.statfsSync(process.cwd()); disk = { freeMb: Math.round(s.bavail * s.bsize / 1048576), totalMb: Math.round(s.blocks * s.bsize / 1048576) }; } catch {}
  return {
    node: process.version, pid: process.pid, uptimeSeconds: Math.round(process.uptime()),
    rssMb: Math.round(mem.rss / 1048576), heapMb: Math.round(mem.heapUsed / 1048576),
    load: os.loadavg().map((n) => Number(n.toFixed(2))), cpus: os.cpus().length,
    sysFreeMb: Math.round(os.freemem() / 1048576), sysTotalMb: Math.round(os.totalmem() / 1048576), disk,
    ai: { groq: llm.hasGroq(), gemini: llm.hasGemini() },
  };
}

module.exports = { start, getState, systemInfo };
