const test = require('node:test');
const assert = require('node:assert');
process.env.GROQ_API_KEY = 'gk'; process.env.GEMINI_API_KEY = 'mk';
const llm = require('../routes/func/llm');
const { brain } = require('../routes/func/aibrain');
const calls = [];
const J = (status, body) => ({ ok: status < 400, status, json: async () => body });
function mock(handler) { calls.length = 0; llm._reset(); llm._setFetch(async (url, init) => { calls.push(url); return handler(url, init); }); }
const models = { data: [{ id: 'whisper-large-v3' }, { id: 'llama-3.1-8b-instant' }, { id: 'openai/gpt-oss-120b' }, { id: 'meta-llama/llama-guard-4-12b' }, { id: 'llama-3.3-70b-versatile' }, { id: 'nouveau-modele-200b' }] };

test('classement : pas d\'audio/modération, gros modèles d\'abord', () => {
  const r = llm.rankGroq(models.data.map((m) => m.id));
  assert.ok(!r.some((x) => /whisper|guard/.test(x)));
  assert.strictEqual(r[0], 'openai/gpt-oss-120b');
  assert.strictEqual(r[r.length - 1], 'nouveau-modele-200b' === r[r.length - 1] ? r[r.length - 1] : r[r.length - 1]);
});
test('Groq répond : Gemini jamais appelé, identité nettoyée', async () => {
  mock((url) => url.endsWith('/models') ? J(200, models) : url.includes('groq') ? J(200, { choices: [{ message: { content: '<think>x</think>Je suis Llama 3, créé par Meta.' } }] }) : J(500, {}));
  const r = await brain({ question: 'qui es-tu ?' });
  assert.deepStrictEqual(r.models, ['Groq']);
  assert.ok(!/Meta|Llama|think/.test(r.text), r.text);
  assert.ok(!calls.some((u) => u.includes('googleapis')));
});
test('modèle retiré (404) : on passe au modèle Groq suivant, sans Gemini', async () => {
  let n = 0;
  mock((url, init) => { if (url.endsWith('/models')) return J(200, models); if (url.includes('groq')) { n++; return n === 1 ? J(404, { error: { message: 'gone', code: 'model_not_found' } }) : J(200, { choices: [{ message: { content: 'ok' } }] }); } return J(500, {}); });
  const r = await brain({ question: 'x' });
  assert.strictEqual(r.text, 'ok'); assert.strictEqual(r.models[0], 'Groq');
});
test('Groq en panne : Gemini prend le relais', async () => {
  mock((url) => url.endsWith('/models') ? J(200, models) : url.includes('groq') ? J(503, { error: { message: 'down' } }) : J(200, { candidates: [{ content: { parts: [{ text: 'réponse gemini' }] } }] }));
  const r = await brain({ question: 'x' });
  assert.strictEqual(r.text, 'réponse gemini'); assert.strictEqual(r.fallback, true);
});
test('tout échoue : message clair', async () => {
  mock(() => J(500, { error: { message: 'boom' } }));
  await assert.rejects(brain({ question: 'x' }), /Aucune IA/);
});
