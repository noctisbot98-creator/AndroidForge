// Cypher Z — serveur de l'application (comptes, quota de requêtes, IA).
// Autonome : aucune dépendance avec l'ancien projet API. Les clés Groq / Gemini restent ICI (variables d'environnement).
process.on('uncaughtException', (err) => { console.error('Erreur non interceptée :', err); });
process.on('unhandledRejection', (reason) => { console.error('Rejet de promesse non géré :', reason); });

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const nodemailer = require('nodemailer');
const activityLog = require('./routes/func/activity');
const { router: adminRouter, getAdmin } = require('./admin/adminRouter');
const llm = require('./routes/func/llm');

const app = express();
const PORT = parseInt(process.env.SERVER_PORT || process.env.PORT || 2035, 10);
const startedAt = Date.now();
let totalRequests = 0;

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(cors());
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  next();
});

// E-mails (vérification du compte, mot de passe oublié)
if (process.env.new_user_verification === 'true' && process.env.smtp_user && process.env.smtp_password) {
  try {
    const transporter = nodemailer.createTransport({
      host: process.env.smtp_host || 'smtp-relay.brevo.com',
      port: Number(process.env.smtp_port) || 587,
      secure: process.env.smtp_is_secure === 'true',
      auth: { user: process.env.smtp_user, pass: process.env.smtp_password },
    });
    global.mTransporter = transporter;
    transporter.verify().then(
      () => { global.mailStatus = { ok: true, at: new Date().toISOString() }; console.log('[mail] SMTP prêt.'); },
      (err) => { global.mailStatus = { ok: false, at: new Date().toISOString(), error: String(err?.message || err) }; console.error(require('./routes/func/mailutil').describeMailError(err)); }
    );
  } catch (err) { console.error('Erreur d\'initialisation SMTP :', err); }
}

// ── Limite anti-abus sur la connexion / l'inscription (par adresse IP) ──
const authHits = new Map();
setInterval(() => { const cut = Date.now() - 15 * 60 * 1000; for (const [k, v] of authHits) { const w = v.filter((t) => t > cut); if (w.length) authHits.set(k, w); else authHits.delete(k); } }, 60000).unref();
function authLimiter(req, res, next) {
  if (req.method !== 'POST' || !/^\/(login|register|google|requestReset|reset)$/.test(req.path)) return next();
  const ip = String(req.ip || req.socket.remoteAddress || '');
  const now = Date.now();
  const w = (authHits.get(ip) || []).filter((t) => t > now - 15 * 60 * 1000);
  if (w.length >= Number(process.env.AUTH_MAX_PER_15MIN || 40)) return res.status(429).json({ status: false, message: 'Trop de tentatives. Réessayez dans quelques minutes.' });
  w.push(now); authHits.set(ip, w);
  next();
}

// Journal d'activité (sans contenu des messages) + maintenance
app.use((req, res, next) => {
  totalRequests++;
  const full = req.originalUrl || req.url || '';
  if (!full.startsWith('/api/') || /^\/api\/admin(\/|$)/.test(full)) return next();
  const pathOnly = full.split('?')[0];
  const isAuth = pathOnly.startsWith('/api/manageusers');
  if (!isAuth && activityLog.getSettings().maintenance) return res.status(503).json({ status: false, message: 'Cypher Z est en maintenance, réessayez dans quelques instants.' });
  const started = process.hrtime.bigint();
  res.on('finish', () => {
    try {
      activityLog.record({
        type: isAuth ? 'auth' : 'api', mail: null, key: null, method: req.method,
        path: pathOnly.replace(/^\/api/, '') || '/', status: res.statusCode,
        ms: Math.round(Number(process.hrtime.bigint() - started) / 1e6),
        ip: String(req.socket.remoteAddress || '').replace(/^::ffff:/, ''), ua: String(req.headers['user-agent'] || '').slice(0, 100),
      });
    } catch { /* le journal ne doit jamais casser une requête */ }
  });
  next();
});

const favicon = path.join(__dirname, 'public', 'favicon.ico');
app.get('/favicon.ico', (req, res) => (fs.existsSync(favicon) ? res.sendFile(favicon) : res.status(204).end()));

// ── Routes ──
app.use('/api/admin', adminRouter);
app.get('/admin', (req, res) => {
  if (!getAdmin(req)) return res.redirect(302, '/login.html?next=/admin');
  res.setHeader('Cache-Control', 'no-store');
  res.sendFile(path.join(__dirname, 'admin', 'admin-panel.html'));
});
// Configuration publique de l'application (bandeau, suggestions, mises à jour…) : aucune donnée sensible.
app.get('/api/app-config', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  const { guestEnabled, guestDailyLimit, keyHelp, ...cfg } = require('./routes/func/appconfig').get();
  res.json({ status: true, config: cfg });
});
app.use('/api/manageusers', authLimiter, express.json({ limit: '30kb' }), require('./routes/manageusers'));
app.use('/api/ai', express.json({ limit: '300kb' }), require('./routes/ai'));
app.get('/', (req, res) => res.redirect(302, '/login.html'));
app.get('/status', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json({ status: true, name: 'Cypher Z', uptimeSeconds: Math.floor((Date.now() - startedAt) / 1000), totalRequests });
});

// Pages de compte uniquement (connexion, liaison de l'application, mot de passe oublié) — aucune page d'API.
app.use(express.static(path.join(__dirname, 'public'), { index: false, extensions: ['html'] }));

app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ status: false, message: 'Introuvable.' });
  res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
});
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  if (err && err.type === 'entity.too.large') return res.status(413).json({ status: false, message: 'Message trop volumineux.' });
  if (err && err.type === 'entity.parse.failed') return res.status(400).json({ status: false, message: 'Requête invalide.' });
  console.error(err);
  res.status(500).json({ status: false, message: 'Erreur du serveur.' });
});

// Nettoyage des anciens fichiers temporaires
setInterval(() => {
  const dir = path.join(__dirname, 'tmp');
  fs.readdir(dir, (e, files) => { if (!e) (files || []).forEach((f) => fs.unlink(path.join(dir, f), () => {})); });
}, 10 * 60 * 1000).unref();

app.listen(PORT, '0.0.0.0', () => {
  llm.warmUp();
  const s = llm.status();
  console.log(`Cypher Z — serveur actif sur le port ${PORT}`);
  console.log(`IA principale : Groq ${s.groq.configured ? 'configuré' : '⚠️ NON configuré (GROQ_API_KEY)'} · renfort : Gemini ${s.gemini.configured ? 'configuré' : 'non configuré'}`);
});
