const express = require('express');
const router = express.Router();
const path = require('path');
const crypto = require('crypto');
const { mailFrom, publicBase, describeMailError } = require('./func/mailutil');
const database = require('./func/database');
const jwt = require('jsonwebtoken');
const { jwtSecret } = require('./func/secret');
const {
    clearSessionCookie,
    getSessionToken,
    setSessionCookie,
    verifySessionToken
} = require('./func/session');

let processR = process.env.use_recaptcha;
processR = processR === 'true';

router.post('/login', async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const { mail, password } = req.body;
    if (!mail || !password) {
        return res.status(400).json({ status: false, message: "Donnees de connexion manquantes." });
    }
    
    let unbase64;
    try {
        unbase64 = Buffer.from(password, 'base64').toString('utf-8');
    } catch {
        unbase64 = password;
    }
    const hashPasswd = crypto.createHash('md5').update(unbase64).digest('hex');
    const user = database.getDatabaseByUser(mail, true);

    if (!user) {
        return res.status(404).json({ status: false, message: "Utilisateur introuvable, veuillez contacter le dev." });
    }

    if (user.isBanned) {
        return res.status(403).json({ status: false, message: "Vous etes banni, contactez le dev." });
    }

    if (user.hashPassword !== hashPasswd) {
        return res.status(401).json({ status: false, message: "Mot de passe incorrect." });
    }

    if (!user.isVerified) {
        return res.status(401).json({ status: false, message: "Compte non verifie. Consultez votre boite de reception ou les spams." });
    }

    const token = jwt.sign(
        { mail: user.mail, userid: user.userId },
        jwtSecret(),
        { expiresIn: '7d' }
    );

    // La session HTTP permet au serveur de protéger /docs avant même
    // que le JavaScript de la page ne soit exécuté.
    setSessionCookie(req, res, token);
    return res.status(200).json({ status: true, token: token, message: "Connexion reussie." });
});

// ── Connexion avec Google (jeton d'identité Google, vérifié auprès de Google) ──
const googleIds = () => String(process.env.GOOGLE_CLIENT_IDS || process.env.GOOGLE_CLIENT_ID || '').split(',').map((x) => x.trim()).filter(Boolean);

router.get('/google-config', (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json({ status: true, clientId: googleIds()[0] || '' });
});

router.post('/google', async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const ids = googleIds();
    const credential = String((req.body && (req.body.credential || req.body.idToken)) || '');
    if (!ids.length) return res.status(503).json({ status: false, message: "La connexion Google n'est pas configurée sur ce serveur." });
    if (credential.length < 20) return res.status(400).json({ status: false, message: 'Jeton Google manquant.' });
    let info;
    try {
        const r = await (global.fetch || require('node-fetch'))(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`);
        info = await r.json();
        if (!r.ok || !info || info.error_description || info.error) throw new Error('refusé');
    } catch {
        return res.status(401).json({ status: false, message: 'Connexion Google refusée. Réessayez.' });
    }
    const okIssuer = info.iss === 'accounts.google.com' || info.iss === 'https://accounts.google.com';
    const verified = info.email_verified === true || info.email_verified === 'true';
    if (!ids.includes(info.aud) || !okIssuer || !verified || !info.email || Number(info.exp) * 1000 < Date.now()) {
        return res.status(401).json({ status: false, message: 'Compte Google non valide pour ce site.' });
    }
    const mail = String(info.email).trim();
    let user = database.getDatabaseByUser(mail, true) || database.getDatabaseByUser(mail.toLowerCase(), true);
    let created = false;
    if (user && user.isBanned) return res.status(403).json({ status: false, message: 'Vous etes banni, contactez le dev.' });
    if (!user) {
        // Nouveau compte : e-mail déjà vérifié par Google, mot de passe aléatoire (il pourra en définir un via « mot de passe oublié »).
        database.PostDatabase(mail.toLowerCase(), crypto.randomBytes(24).toString('hex'), true, String(info.name || '').slice(0, 40) || undefined);
        user = database.getDatabaseByUser(mail.toLowerCase(), true);
        created = true;
    } else if (!user.isVerified) {
        database.UpdateDatabase(user.mail, { isVerified: true, verifyCode: undefined });
        user = database.getDatabaseByUser(user.mail, true);
    }
    const token = jwt.sign({ mail: user.mail, userid: user.userId }, jwtSecret(), { expiresIn: '7d' });
    setSessionCookie(req, res, token);
    return res.status(200).json({ status: true, token, created, message: 'Connexion Google reussie.' });
});

// ── Jumelage de l'application Cypher Z avec un compte déjà connecté sur le site (ex. via Google) ──
// 1) l'appli demande un code  2) l'utilisateur ouvre /app-link.html?code=… sur le site (connecté)  3) l'appli récupère sa session.
const links = new Map(); // code -> { created, mail?, userId? }
setInterval(() => { const now = Date.now(); for (const [c, l] of links) if (now - l.created > 10 * 60 * 1000) links.delete(c); }, 60 * 1000).unref();
const LINK_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const newLinkCode = () => Array.from(crypto.randomBytes(8), (b) => LINK_ALPHABET[b % LINK_ALPHABET.length]).join('');
const linkCode = (v) => String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);

router.post('/app-link/start', (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    if (links.size > 5000) return res.status(429).json({ status: false, message: 'Trop de demandes, réessayez dans un instant.' });
    const code = newLinkCode();
    links.set(code, { created: Date.now() });
    res.json({ status: true, code, expiresIn: 600 });
});

router.post('/app-link/confirm', (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const decoded = verifySessionToken(getSessionToken(req));
    const user = decoded && database.getDatabaseByUser(decoded.mail);
    if (!user || user.isBanned || !user.isVerified) return res.status(401).json({ status: false, message: 'Connectez-vous d\'abord sur le site.' });
    const l = links.get(linkCode(req.body && req.body.code));
    if (!l || Date.now() - l.created > 10 * 60 * 1000) return res.status(404).json({ status: false, message: 'Code expiré ou inconnu. Relancez la connexion depuis l\'application.' });
    l.mail = user.mail; l.userId = user.userId;
    res.json({ status: true, message: 'Application reliée à votre compte.' });
});

router.get('/app-link/poll', (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const code = linkCode(req.query.code);
    const l = links.get(code);
    if (!l) return res.status(404).json({ status: false, message: 'Code expiré.' });
    if (!l.mail) return res.json({ status: true, pending: true });
    links.delete(code); // usage unique
    const token = jwt.sign({ mail: l.mail, userid: l.userId }, jwtSecret(), { expiresIn: '7d' });
    res.json({ status: true, pending: false, token, mail: l.mail });
});

router.post('/logout', (req, res) => {
    clearSessionCookie(req, res);
    return res.status(200).json({ status: true, message: "Deconnexion reussie." });
});

router.post('/register', async (req, res) => {
    const { mail, password, recaptchaVerify } = req.body;
    const username = String(req.body.username || '').trim();
    if (!mail || !password) {
        return res.status(400).json({ status: false, message: "Donnees manquantes." });
    }

    if (!/^[A-Za-z0-9_.\-]{3,20}$/.test(username)) {
        return res.status(400).json({ status: false, message: "Nom d'utilisateur invalide (3 à 20 caractères : lettres, chiffres, _ . -)." });
    }
    if (database.getDatabase().some(u => String(u.username || '').toLowerCase() === username.toLowerCase())) {
        return res.status(409).json({ status: false, message: "Ce nom d'utilisateur est déjà pris." });
    }

    if (processR && !recaptchaVerify) {
        return res.status(400).json({ status: false, message: "reCAPTCHA manquant." });
    }

    const user = database.getDatabaseByUser(mail);
    if (user) {
        return res.status(409).json({ status: false, message: "Compte deja enregistre. Connectez-vous ou contactez le dev." });
    }

    if (processR) {
        try {
            const recaptcha = await fetch(`https://www.google.com/recaptcha/api/siteverify?secret=${process.env.recaptcha_secret}&response=${recaptchaVerify}`, {
                method: 'POST'
            });
            const recaptchaJson = await recaptcha.json();
            if (!recaptchaJson.success) {
                return res.status(400).json({ status: false, message: "reCAPTCHA invalide." });
            }
        } catch {
            return res.status(400).json({ status: false, message: "Erreur de verification reCAPTCHA." });
        }
    }

    let unbase64;
    try {
        unbase64 = Buffer.from(password, 'base64').toString('utf-8');
    } catch {
        unbase64 = password;
    }

    const newUser = database.PostDatabase(mail, unbase64, !(process.env.new_user_verification === 'true'), username);

    if (process.env.new_user_verification === 'true') {
        try {
            if (global.mTransporter) {
                await global.mTransporter.sendMail({
                    from: mailFrom(),
                    to: mail,
                    subject: "Cypher Z - Verification de votre adresse e-mail",
                    html: `
                        <!DOCTYPE html>
                        <html>
                        <head>
                        <meta charset="utf-8">
                        <style>
                        body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #0b1120; color: #e2e8f0; padding: 20px; }
                        .container { max-width: 600px; margin: 0 auto; padding: 25px; background-color: #111a2e; border-radius: 12px; border: 1px solid #4f46e5; }
                        h1 { color: #6366f1; text-align: center; font-size: 24px; }
                        p { margin-bottom: 16px; line-height: 1.6; color: #cbd5e1; }
                        .btn { display: inline-block; background: linear-gradient(135deg, #4f46e5, #0284c7); color: #ffffff !important; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: bold; margin: 15px 0; text-align: center; }
                        .signature { margin-top: 25px; border-top: 1px solid #2d3748; padding-top: 15px; text-align: center; font-size: 13px; color: #94a3b8; }
                        </style>
                        </head>
                        <body>
                        <div class="container">
                            <h1>Cypher Z - Verification de compte</h1>
                            <p>Bonjour,</p>
                            <p>Merci pour votre inscription sur Cypher Z, creee par Zidane.</p>
                            <p>Pour activer votre acces API, veuillez cliquer sur le bouton ci-dessous :</p>
                            <p style="text-align: center;"><a href="${publicBase(req)}/api/manageusers/verify?token=${newUser.verifyCode}" class="btn">Verifier mon compte</a></p>
                            <p>Si vous n avez pas demande cette inscription, ignorez simplement cet e-mail.</p>
                            <div class="signature">
                                <p><strong>Cypher Z</strong></p>
                                <p>Zidane - Developpeur Camerounais</p>
                                <p>WhatsApp : +237621862134</p>
                            </div>
                        </div>
                        </body>
                        </html>
                    `
                });
            }
            return res.status(200).json({ status: true, message: "Compte enregistre. Veuillez verifier votre e-mail pour finaliser l activation." });
        } catch (error) {
            console.error(describeMailError(error));
            database.DeleteDatabase(newUser.mail);
            return res.status(500).json({ status: false, message: "Erreur lors de l envoi de l e-mail, contactez le dev via WhatsApp (+237621862134)." });
        }
    }

    return res.status(200).json({ status: true, message: "Compte enregistre avec succes." });
});

router.get('/user', async (req, res) => {
    res.setHeader('Cache-Control', 'private, no-store');
    const token = getSessionToken(req);
    if (!token) {
        return res.status(401).json({ status: false, message: "Aucun jeton d autorisation fourni." });
    }

    const decoded = verifySessionToken(token);
    if (!decoded) {
        clearSessionCookie(req, res);
        return res.status(401).json({ status: false, message: "Session expiree ou jeton invalide." });
    }

    const user = database.getDatabaseByUser(decoded.mail);
    if (!user || (decoded.userid && user.userId !== decoded.userid)) {
        clearSessionCookie(req, res);
        return res.status(404).json({ status: false, message: "Utilisateur introuvable." });
    }
    if (user.isBanned) {
        clearSessionCookie(req, res);
        return res.status(403).json({ status: false, message: "Vous etes banni, contactez le dev." });
    }
    if (!user.isVerified) {
        clearSessionCookie(req, res);
        return res.status(401).json({ status: false, message: "Compte non verifie." });
    }

    // Migre aussi les sessions existantes stockées uniquement dans localStorage.
    setSessionCookie(req, res, token);

    const currentLimit = require('./func/quota').getLimit(user);
    return res.status(200).json({
        status: true,
        user: (({ apikey, hashPassword, verifyCode, resetCode, ...safe }) => safe)(user),
        CurrentLimit: currentLimit
    });
});

router.get('/fetchRecaptcha', async (req, res) => {
    if (!processR) {
        return res.status(404).json({ status: false, message: "reCAPTCHA desactive." });
    }
    const recaptchaSiteKey = process.env.recaptcha_site_key;
    return res.status(200).json({ status: true, sitekey: recaptchaSiteKey });
});

router.get('/verify', async (req, res) => {
    const token = req.query.token;
    if (!token) {
        return res.status(400).json({ status: false, message: "Jeton de verification manquant." });
    }
    const user = database.getDatabaseByVerifyCode(token);
    if (!user) {
        return res.status(404).json({ status: false, message: "Utilisateur introuvable." });
    }
    if (user.isVerified) {
        return res.redirect("/login.html?verified=already");
    }
    database.UpdateDatabase(user.mail, { isVerified: true });
    return res.redirect("/login.html?verified=true");
});

router.post('/requestReset', async (req, res) => {
    const mail = req.body.mail;
    const recaptchaVerify = req.body.recaptchaVerify;
    if (!mail) {
        return res.status(400).json({ status: false, message: "Adresse e-mail requise." });
    }
    const user = database.getDatabaseByUser(mail);
    if (!user) {
        return res.status(404).json({ status: false, message: "Aucun compte associe a cet e-mail." });
    }
    if (user.isBanned) {
        return res.status(403).json({ status: false, message: "Vous etes banni, contactez le dev." });
    }

    if (processR && !recaptchaVerify) {
        return res.status(400).json({ status: false, message: "reCAPTCHA manquant." });
    }

    if (processR) {
        try {
            const recaptcha = await fetch(`https://www.google.com/recaptcha/api/siteverify?secret=${process.env.recaptcha_secret}&response=${recaptchaVerify}`, {
                method: 'POST'
            });
            const recaptchaJson = await recaptcha.json();
            if (!recaptchaJson.success) {
                return res.status(400).json({ status: false, message: "reCAPTCHA invalide." });
            }
        } catch {
            return res.status(400).json({ status: false, message: "Erreur de verification reCAPTCHA." });
        }
    }

    const resetCode = crypto.randomBytes(20).toString('hex');
    database.UpdateDatabase(user.mail, { resetCode: resetCode });
    try {
        if (global.mTransporter) {
            await global.mTransporter.sendMail({
                from: mailFrom(),
                to: mail,
                subject: "Cypher Z - Reinitialisation de mot de passe",
                html: `
                    <!DOCTYPE html>
                    <html>
                    <head>
                    <meta charset="utf-8">
                    <style>
                    body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #0b1120; color: #e2e8f0; padding: 20px; }
                    .container { max-width: 600px; margin: 0 auto; padding: 25px; background-color: #111a2e; border-radius: 12px; border: 1px solid #4f46e5; }
                    h1 { color: #6366f1; text-align: center; }
                    p { margin-bottom: 16px; line-height: 1.6; color: #cbd5e1; }
                    .btn { display: inline-block; background: linear-gradient(135deg, #4f46e5, #0284c7); color: #ffffff !important; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: bold; margin: 15px 0; }
                    .signature { margin-top: 25px; border-top: 1px solid #2d3748; padding-top: 15px; text-align: center; font-size: 13px; color: #94a3b8; }
                    </style>
                    </head>
                    <body>
                    <div class="container">
                        <h1>Cypher Z - Reinitialisation</h1>
                        <p>Bonjour,</p>
                        <p>Pour reinitialiser votre mot de passe, veuillez cliquer sur le lien ci-dessous :</p>
                        <p style="text-align: center;"><a href="${publicBase(req)}/api/manageusers/reset?token=${resetCode}" class="btn">Reinitialiser mon mot de passe</a></p>
                        <p>Si vous n avez pas demande cette reinitialisation, ignorez cet e-mail.</p>
                        <div class="signature">
                            <p><strong>Cypher Z</strong></p>
                            <p>Zidane - Developpeur Camerounais</p>
                        </div>
                    </div>
                    </body>
                    </html>
                `
            });
        }
        return res.status(200).json({ status: true, message: "E-mail de reinitialisation envoye. Consultez votre boite de reception ou les spams." });
    } catch (error) {
        console.error(describeMailError(error));
        return res.status(500).json({ status: false, message: "Erreur lors de l envoi de l e-mail, contactez le dev via WhatsApp (+237621862134)." });
    }
});

router.get('/reset', async (req, res) => {
    const token = req.query.token;
    return res.redirect("/reset.html?resetToken=" + encodeURIComponent(token || ''));
});

router.post('/reset', async (req, res) => {
    const token = req.body.tokenReset;
    const password = req.body.password;
    if (!token || !password) {
        return res.status(400).json({ status: false, message: "Donnees requises manquantes." });
    }
    const users = database.getDatabase();
    const user = users.find(u => u.resetCode === token);
    if (!user) {
        return res.status(404).json({ status: false, message: "Jeton de reinitialisation invalide ou expire." });
    }
    let unbase64;
    try {
        unbase64 = Buffer.from(password, 'base64').toString('utf-8');
    } catch {
        unbase64 = password;
    }
    database.UpdateDatabase(user.mail, {
        hashPassword: crypto.createHash('md5').update(unbase64).digest('hex'),
        resetCode: undefined
    });
    return res.status(200).json({ status: true, message: "Mot de passe reinitialise avec succes." });
});

module.exports = router;
