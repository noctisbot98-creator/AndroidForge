// Aides e-mail : expéditeur valide, adresse publique des liens, journal détaillé des échecs.

/** Expéditeur. Avec Brevo, smtp_user est un identifiant de connexion (xxx@smtp-brevo.com) : il n'est PAS un expéditeur valide.
 *  Mets dans `smtp_from` une adresse validée dans Brevo (Senders & IP), ex. "zidane_api <ton.email@gmail.com>". */
function mailFrom() {
  return process.env.smtp_from || process.env.smtp_user;
}

/** Adresse publique pour les liens des e-mails : PUBLIC_URL si défini (ex. http://zidanexmd.space:25563),
 *  sinon protocole réel de la requête (http ou https) — l'ancien code forçait toujours https:// (lien cassé en HTTP). */
function publicBase(req) {
  const fixed = String(process.env.PUBLIC_URL || '').trim().replace(/\/+$/, '');
  if (fixed) return fixed;
  const proto = String(req.headers['x-forwarded-proto'] || req.protocol || 'http').split(',')[0].trim();
  return `${proto}://${req.headers.host}`;
}

/** Message lisible pour la console du serveur (Pterodactyl) : la vraie cause de l'échec. */
function describeMailError(err) {
  const parts = [err?.code, err?.responseCode, err?.command, err?.response || err?.message].filter(Boolean);
  let hint = '';
  const txt = String(err?.response || err?.message || '').toLowerCase();
  if (err?.code === 'EAUTH' || /authentication|535|invalid login/.test(txt)) hint = 'Identifiants SMTP refusés : smtp_user / smtp_password doivent être ceux de la clé SMTP Brevo (pas le mot de passe du compte).';
  else if (/sender|from|not valid|not verified|unauthorized/.test(txt)) hint = 'Expéditeur refusé : ajoute smtp_from=une adresse validée dans Brevo (Senders & IP).';
  else if (['ETIMEDOUT', 'ECONNECTION', 'ESOCKET', 'ECONNREFUSED', 'EDNS', 'ENOTFOUND'].includes(err?.code)) hint = 'Connexion au serveur SMTP impossible : port sortant bloqué par l\'hébergeur ? essaie smtp_port=2525 (ou 465 avec smtp_is_secure=true).';
  return `[mail] échec d'envoi : ${parts.join(' | ')}${hint ? `\n[mail] → ${hint}` : ''}`;
}

module.exports = { mailFrom, publicBase, describeMailError };
