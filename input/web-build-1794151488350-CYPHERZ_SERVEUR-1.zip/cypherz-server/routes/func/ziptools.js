// ══════════════════════════════════════════════════════════════════════════
// Outils d'archives en Node pur (aucune dépendance) :
//  • lecture : ZIP, TAR, TAR.GZ/TGZ (RAR / 7z seulement si l'outil `7z` ou `unrar` est installé sur le serveur)
//  • écriture : ZIP et TAR.GZ  (le format RAR ne peut PAS être créé : format propriétaire)
// Protections : nombre d'entrées, taille par fichier, taille totale décompressée (anti « zip bomb »), chemins nettoyés.
// ══════════════════════════════════════════════════════════════════════════
const zlib = require('zlib');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');

const LIMITS = { maxEntries: 5000, maxFileBytes: 2 * 1024 * 1024, maxTotalBytes: 120 * 1024 * 1024 };

// ── Chemins ──
function cleanPath(p) {
  const parts = String(p || '').replace(/\\/g, '/').replace(/[\u0000-\u001f]/g, '').split('/').filter((s) => s && s !== '.');
  if (!parts.length || parts.some((s) => s === '..')) return null;
  const out = parts.join('/');
  return out.length > 220 ? null : out;
}

// ── CRC32 ──
const CRC_TABLE = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(buf) { let c = 0xffffffff; for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }

// ══ LECTURE ══
function detectFormat(buf) {
  if (buf.length >= 4 && buf.readUInt32LE(0) === 0x04034b50) return 'zip';
  if (buf.length >= 4 && buf.readUInt32LE(0) === 0x06054b50) return 'zip'; // zip vide
  if (buf.length >= 2 && buf[0] === 0x1f && buf[1] === 0x8b) return 'gz';
  if (buf.length >= 4 && buf.toString('latin1', 0, 4) === 'Rar!') return 'rar';
  if (buf.length >= 6 && buf[0] === 0x37 && buf[1] === 0x7a && buf[2] === 0xbc && buf[3] === 0xaf) return '7z';
  if (buf.length >= 262 && buf.toString('latin1', 257, 262) === 'ustar') return 'tar';
  return null;
}

function readZip(buf, limits = LIMITS) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 22 - 65535); i--) { if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; } }
  if (eocd < 0) throw new Error('Archive ZIP invalide ou corrompue.');
  const total = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  if (total === 0xffff || off === 0xffffffff) throw new Error('ZIP64 non pris en charge : recompressez en ZIP standard.');
  if (total > limits.maxEntries) throw new Error(`Trop de fichiers dans l'archive (${total} > ${limits.maxEntries}).`);
  const entries = [];
  let declared = 0;
  for (let n = 0; n < total; n++) {
    if (off + 46 > buf.length || buf.readUInt32LE(off) !== 0x02014b50) throw new Error('Répertoire central du ZIP corrompu.');
    const flags = buf.readUInt16LE(off + 8), method = buf.readUInt16LE(off + 10);
    const comp = buf.readUInt32LE(off + 20), size = buf.readUInt32LE(off + 24);
    const nl = buf.readUInt16LE(off + 28), el = buf.readUInt16LE(off + 30), cl = buf.readUInt16LE(off + 32);
    const local = buf.readUInt32LE(off + 42);
    const rawName = buf.toString(flags & 0x0800 ? 'utf8' : 'latin1', off + 46, off + 46 + nl);
    off += 46 + nl + el + cl;
    if (rawName.endsWith('/')) continue; // dossier
    const p = cleanPath(rawName);
    if (!p) continue;
    declared += size;
    if (declared > limits.maxTotalBytes) throw new Error('Archive trop volumineuse une fois décompressée.');
    entries.push({
      path: p, size, encrypted: !!(flags & 1),
      read(max = limits.maxFileBytes) {
        if (flags & 1) throw new Error('fichier chiffré');
        if (buf.readUInt32LE(local) !== 0x04034b50) throw new Error('en-tête local invalide');
        const start = local + 30 + buf.readUInt16LE(local + 26) + buf.readUInt16LE(local + 28);
        const data = buf.subarray(start, start + comp);
        if (method === 0) return data.subarray(0, max);
        if (method === 8) {
          // Taille annoncée plafonnée à 16 Mo (un en-tête mensonger ne peut pas faire exploser la mémoire), puis découpe à `max`.
          const cap = Math.min(Math.max(size, 1), 16 * 1024 * 1024);
          return zlib.inflateRawSync(data, { maxOutputLength: cap }).subarray(0, max);
        }
        throw new Error(`méthode de compression ${method} non prise en charge`);
      },
    });
  }
  return entries;
}

function readTar(buf, limits = LIMITS) {
  const entries = [];
  let off = 0, longName = null, declared = 0;
  while (off + 512 <= buf.length) {
    const h = buf.subarray(off, off + 512);
    if (h.every((b) => b === 0)) break;
    let name = h.toString('utf8', 0, 100).replace(/\0.*$/, '');
    const prefix = h.toString('utf8', 345, 500).replace(/\0.*$/, '');
    const size = parseInt(h.toString('latin1', 124, 136).replace(/\0.*$/, '').trim() || '0', 8) || 0;
    const type = String.fromCharCode(h[156] || 48);
    off += 512;
    const data = buf.subarray(off, off + size);
    off += Math.ceil(size / 512) * 512;
    if (type === 'L') { longName = data.toString('utf8').replace(/\0.*$/, ''); continue; }
    if (type === 'x' || type === 'g') continue; // en-têtes étendus PAX ignorés
    if (longName) { name = longName; longName = null; } else if (prefix) name = `${prefix}/${name}`;
    if (type !== '0' && type !== '\0') continue; // fichiers réguliers seulement
    const p = cleanPath(name);
    if (!p) continue;
    declared += size;
    if (declared > limits.maxTotalBytes) throw new Error('Archive trop volumineuse une fois décompressée.');
    if (entries.length >= limits.maxEntries) throw new Error(`Trop de fichiers dans l'archive (> ${limits.maxEntries}).`);
    entries.push({ path: p, size, read: (max = limits.maxFileBytes) => data.subarray(0, max) });
  }
  return entries;
}

function walkDir(dir, base = dir, out = [], limits = LIMITS) {
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name); const st = fs.lstatSync(full);
    if (st.isSymbolicLink()) continue;
    if (st.isDirectory()) walkDir(full, base, out, limits);
    else if (st.isFile()) {
      const p = cleanPath(path.relative(base, full)); if (!p) continue;
      if (out.length >= limits.maxEntries) throw new Error(`Trop de fichiers dans l'archive (> ${limits.maxEntries}).`);
      out.push({ path: p, size: st.size, read: (max = limits.maxFileBytes) => fs.readFileSync(full).subarray(0, max) });
    }
  }
  return out;
}

/** RAR / 7z : uniquement si un outil est installé sur le serveur ; sinon message clair. */
function readViaCli(buf, ext) {
  return new Promise((resolve, reject) => {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'zai-'));
    const file = path.join(tmp, `in.${ext}`), out = path.join(tmp, 'out');
    fs.writeFileSync(file, buf); fs.mkdirSync(out);
    const cleanup = () => { try { fs.rmSync(tmp, { recursive: true, force: true }); } catch {} };
    const attempts = ext === 'rar'
      ? [['unrar', ['x', '-y', '-inul', file, out + path.sep]], ['7z', ['x', '-y', `-o${out}`, file]]]
      : [['7z', ['x', '-y', `-o${out}`, file]]];
    const tryNext = (i) => {
      if (i >= attempts.length) { cleanup(); return reject(new Error(`Le format .${ext} n'est pas pris en charge sur ce serveur (outil 7z/unrar absent). Envoyez un fichier .zip ou .tar.gz.`)); }
      execFile(attempts[i][0], attempts[i][1], { timeout: 60000 }, (err) => {
        if (err) return tryNext(i + 1);
        try {
          const entries = walkDir(out);
          // les fichiers sont lus en mémoire AVANT le nettoyage
          const mem = entries.map((e) => { const data = e.read(); return { path: e.path, size: e.size, read: (max = LIMITS.maxFileBytes) => data.subarray(0, max) }; });
          cleanup(); resolve(mem);
        } catch (e) { cleanup(); reject(e); }
      });
    };
    tryNext(0);
  });
}

/** Lit une archive (ZIP / TAR / TAR.GZ / RAR / 7z) → Promise<[{path,size,read()}]>. */
async function readArchive(buf, limits = LIMITS) {
  const fmt = detectFormat(buf);
  if (fmt === 'zip') return readZip(buf, limits);
  if (fmt === 'gz') {
    let tar;
    try { tar = zlib.gunzipSync(buf, { maxOutputLength: limits.maxTotalBytes }); } catch { throw new Error('Archive .gz invalide ou trop volumineuse.'); }
    if (detectFormat(tar) !== 'tar') throw new Error('Ce fichier .gz n\'est pas une archive .tar.gz.');
    return readTar(tar, limits);
  }
  if (fmt === 'tar') return readTar(buf, limits);
  if (fmt === 'rar' || fmt === '7z') return readViaCli(buf, fmt);
  throw new Error('Format d\'archive non reconnu. Formats acceptés : .zip, .tar, .tar.gz (.rar / .7z si le serveur a l\'outil).');
}

// ══ ÉCRITURE ══
function dosDateTime(d = new Date()) {
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2);
  const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  return { time, date };
}
/** files : [{ path, content (string|Buffer) }] → Buffer ZIP (UTF-8, deflate). */
function buildZip(files) {
  const { time, date } = dosDateTime();
  const chunks = [], central = [];
  let offset = 0;
  for (const f of files) {
    const name = Buffer.from(f.path, 'utf8');
    const raw = Buffer.isBuffer(f.content) ? f.content : Buffer.from(String(f.content ?? ''), 'utf8');
    const deflated = raw.length ? zlib.deflateRawSync(raw) : raw;
    const useDeflate = raw.length > 0 && deflated.length < raw.length;
    const data = useDeflate ? deflated : raw, method = useDeflate ? 8 : 0, crc = crc32(raw);
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(method, 8);
    lh.writeUInt16LE(time, 10); lh.writeUInt16LE(date, 12); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(data.length, 18);
    lh.writeUInt32LE(raw.length, 22); lh.writeUInt16LE(name.length, 26); lh.writeUInt16LE(0, 28);
    chunks.push(lh, name, data);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(method, 10);
    ch.writeUInt16LE(time, 12); ch.writeUInt16LE(date, 14); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(data.length, 20); ch.writeUInt32LE(raw.length, 24);
    ch.writeUInt16LE(name.length, 28); ch.writeUInt32LE(0o100644 << 16 >>> 0, 38); ch.writeUInt32LE(offset, 42);
    central.push(ch, name);
    offset += 30 + name.length + data.length;
  }
  const cd = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...chunks, cd, end]);
}

function tarHeader(name, size, mtime) {
  const h = Buffer.alloc(512);
  let nm = name, prefix = '';
  if (Buffer.byteLength(nm) > 100) { const i = nm.lastIndexOf('/', nm.length - 1); const idx = nm.slice(0, i), rest = nm.slice(i + 1); if (i > 0 && Buffer.byteLength(idx) <= 155 && Buffer.byteLength(rest) <= 100) { prefix = idx; nm = rest; } else nm = nm.slice(-100); }
  h.write(nm, 0, 100, 'utf8'); h.write('0000644\0', 100); h.write('0000000\0', 108); h.write('0000000\0', 116);
  h.write(size.toString(8).padStart(11, '0') + '\0', 124); h.write(Math.floor(mtime / 1000).toString(8).padStart(11, '0') + '\0', 136);
  h.write('        ', 148); h.write('0', 156); h.write('ustar\0', 257); h.write('00', 263); if (prefix) h.write(prefix, 345, 155, 'utf8');
  let sum = 0; for (let i = 0; i < 512; i++) sum += h[i];
  h.write(sum.toString(8).padStart(6, '0') + '\0 ', 148);
  return h;
}
function buildTarGz(files) {
  const parts = []; const now = Date.now();
  for (const f of files) {
    const raw = Buffer.isBuffer(f.content) ? f.content : Buffer.from(String(f.content ?? ''), 'utf8');
    parts.push(tarHeader(f.path, raw.length, now), raw, Buffer.alloc((512 - (raw.length % 512)) % 512));
  }
  parts.push(Buffer.alloc(1024));
  return zlib.gzipSync(Buffer.concat(parts));
}

module.exports = { LIMITS, cleanPath, crc32, detectFormat, readArchive, readZip, readTar, buildZip, buildTarGz };
