// ══════════════════════════════════════════════════════════════════════════
// « Cerveau » de Cypher Z : Groq d'abord, Gemini seulement en renfort.
//  • On interroge Groq. S'il répond, c'est fini : Gemini n'est JAMAIS appelé.
//  • Si Groq échoue (panne, quota, modèle indisponible, délai), Gemini prend le relais.
// ══════════════════════════════════════════════════════════════════════════
const llm = require('./llm');

const GROQ_CTX = Number(process.env.GROQ_CTX_CHARS || 32000);
const GEMINI_CTX = Number(process.env.GEMINI_CTX_CHARS || 90000);

const clip = (s, n) => (String(s).length > n ? `${String(s).slice(0, n)}…` : String(s));

/** Fournisseurs dans l'ordre d'appel : Groq (principal), puis Gemini (renfort). */
function providers() {
  const list = [];
  if (llm.hasGroq()) list.push({ id: 'groq', label: 'Groq', ctx: GROQ_CTX, big: false, ask: async (t, sys) => (await llm.askGroq(t, { system: sys })).text });
  if (llm.hasGemini()) list.push({ id: 'gemini', label: 'Gemini', ctx: GEMINI_CTX, big: true, fallback: true, ask: async (t, sys) => (await llm.askGemini(t, { system: sys })).text });
  return list;
}
const hasBigProvider = () => providers().some((p) => p.big);

/** Interroge UN fournisseur ; renvoie '' en cas d'échec (jamais d'exception). */
async function safeAsk(p, text, sys) {
  try { return (await p.ask(clip(text, p.ctx), clip(sys || '', 2400))) || ''; } catch { return ''; }
}

/**
 * Réponse : le premier fournisseur (Groq) ; en cas d'échec, le suivant (Gemini).
 * @returns {{ text: string, models: string[], mode: 'single' }} ou lance une Error si personne ne répond.
 */
async function brain({ question, persona = '' }) {
  for (const p of providers()) {
    const text = await safeAsk(p, question, persona);
    if (text) return { text, models: [p.label], mode: 'single', fallback: !!p.fallback };
  }
  throw new Error("Aucune IA n'a répondu, réessayez dans un instant.");
}

// ── Intention de la demande (mode automatique de l'application) ──
function detectIntent(text) {
  const t = String(text || '').toLowerCase();
  const verb = /(g[ée]n[èe]re|cr[ée]e|cr[ée]er|dessine|fais|fabrique|imagine|produis|r[ée]alise|make|generate|draw|create|build)/;
  if (verb.test(t) && /\b(une?\s+|des\s+|l['’])?(image|photo|illustration|logo|dessin|affiche|wallpaper|portrait|picture|avatar|banni[èe]re)s?\b/.test(t)) return 'image';
  if (/^(dessine|imagine)\b/.test(t.trim())) return 'image';
  if (verb.test(t) && /\b(zip|rar|tar\.?gz|archive)\b/.test(t)) return 'archive';
  if (verb.test(t) && /\b(projet|site\s+web|site|application|app|script|bot|programme)\b/.test(t) && /\b(fichiers?|complet|dossier)\b/.test(t)) return 'archive';
  return 'chat';
}

/** Transforme une demande d'image en prompt anglais plus riche ; retombe sur le texte d'origine. */
async function enhanceImagePrompt(userText) {
  const sys = 'You write prompts for an image generator. Reply with ONE English prompt only (max 45 words): subject, style, lighting, composition, quality keywords. No quotes, no explanations.';
  for (const p of providers()) {
    const out = await safeAsk(p, `Image request: ${clip(userText, 400)}`, sys);
    const clean = out.replace(/^["'`\s]+|["'`\s]+$/g, '').replace(/\s+/g, ' ');
    if (clean && clean.length >= 8 && clean.length <= 600) return clean;
  }
  return clip(userText, 400);
}

module.exports = { brain, providers, hasBigProvider, detectIntent, enhanceImagePrompt, safeAsk };
