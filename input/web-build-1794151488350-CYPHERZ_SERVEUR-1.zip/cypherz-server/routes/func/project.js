// ══════════════════════════════════════════════════════════════════════════
// Analyse d'un projet (archive) et génération de projets (fichiers → ZIP / TAR.GZ).
//  • Avec un fournisseur « grand contexte » (Gemini / LLM compatible) : les fichiers les plus pertinents sont envoyés EN UNE FOIS.
//  • Sans : méthode « résumer puis synthétiser » (map-reduce) : résumé fichier par fichier des plus importants, puis réponse
//    finale multi-modèles. Moins précis, mais fonctionne avec des IA gratuites à contexte court.
// ══════════════════════════════════════════════════════════════════════════
const path = require('path');
const { readArchive, cleanPath, buildZip, buildTarGz } = require('./ziptools');
const { brain, providers, safeAsk } = require('./aibrain');

const IGNORE = /(^|\/)(node_modules|\.git|dist|build|out|\.next|\.nuxt|\.dart_tool|__pycache__|venv|\.venv|vendor|target|coverage|\.idea|\.vscode|\.gradle|Pods|\.cache|bower_components)(\/|$)/i;
const TEXT_EXT = new Set(['js', 'mjs', 'cjs', 'jsx', 'ts', 'tsx', 'json', 'md', 'markdown', 'txt', 'html', 'htm', 'css', 'scss', 'less', 'py', 'java', 'kt', 'kts', 'dart', 'go', 'rs', 'rb', 'php', 'c', 'h', 'cpp', 'hpp', 'cs', 'swift', 'sh', 'bash', 'bat', 'ps1', 'yml', 'yaml', 'toml', 'ini', 'cfg', 'conf', 'env', 'xml', 'gradle', 'properties', 'sql', 'vue', 'svelte', 'lua', 'r', 'dockerfile', 'makefile', 'gitignore', 'lock', 'csv', 'tsv', 'graphql', 'proto']);
const NAMED_TEXT = /^(dockerfile|makefile|readme|license|procfile|gemfile|rakefile|\.env(\.example)?|\.gitignore)$/i;
const LANG = { js: 'JavaScript', mjs: 'JavaScript', cjs: 'JavaScript', jsx: 'React JSX', ts: 'TypeScript', tsx: 'React TSX', py: 'Python', java: 'Java', kt: 'Kotlin', dart: 'Dart', go: 'Go', rs: 'Rust', rb: 'Ruby', php: 'PHP', c: 'C', cpp: 'C++', cs: 'C#', swift: 'Swift', html: 'HTML', css: 'CSS', scss: 'SCSS', sh: 'Shell', sql: 'SQL', vue: 'Vue', svelte: 'Svelte', json: 'JSON', yml: 'YAML', yaml: 'YAML', md: 'Markdown' };
const ENTRY = /(^|\/)(main|index|app|server|bot|cli|manage|__main__)\.[a-z]+$/i;
const MANIFEST = /(^|\/)(package\.json|pubspec\.yaml|requirements\.txt|pyproject\.toml|pom\.xml|build\.gradle|go\.mod|cargo\.toml|composer\.json|gemfile|dockerfile|docker-compose\.ya?ml|readme(\.md)?)$/i;

const ext = (p) => { const b = path.posix.basename(p); const i = b.lastIndexOf('.'); return i > 0 ? b.slice(i + 1).toLowerCase() : b.toLowerCase(); };
const isTextName = (p) => TEXT_EXT.has(ext(p)) || NAMED_TEXT.test(path.posix.basename(p));
const looksBinary = (buf) => { const n = Math.min(buf.length, 2000); for (let i = 0; i < n; i++) if (buf[i] === 0) return true; return false; };
const words = (q) => [...new Set(String(q || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').split(/[^a-z0-9_]+/).filter((w) => w.length >= 4))].slice(0, 12);
const clip = (s, n) => (s.length > n ? `${s.slice(0, n)}\n…[tronqué]` : s);

/** Lit et classe les fichiers texte d'une archive. */
async function loadProject(buffer, { maxFileBytes = 400 * 1024 } = {}) {
  const entries = await readArchive(buffer, { maxEntries: 8000, maxFileBytes, maxTotalBytes: 80 * 1024 * 1024 });
  // dossier racine commun (ex. « monprojet/… ») retiré pour l'affichage
  const roots = new Set(entries.map((e) => e.path.split('/')[0]));
  const strip = roots.size === 1 && entries.every((e) => e.path.includes('/')) ? `${[...roots][0]}/` : '';
  const files = [], skipped = { ignored: 0, binary: 0, big: 0, error: 0 };
  for (const e of entries) {
    const p = strip ? e.path.slice(strip.length) : e.path;
    if (IGNORE.test(`/${p}`)) { skipped.ignored++; continue; }
    if (!isTextName(p)) { skipped.binary++; continue; }
    if (e.size > maxFileBytes) { skipped.big++; continue; }
    try {
      const buf = e.read(maxFileBytes);
      if (looksBinary(buf)) { skipped.binary++; continue; }
      files.push({ path: p, text: buf.toString('utf8') });
    } catch { skipped.error++; }
  }
  return { files, skipped, totalEntries: entries.length, root: strip.replace(/\/$/, '') };
}

function overview(project) {
  const byLang = {};
  let lines = 0;
  for (const f of project.files) { const l = LANG[ext(f.path)]; if (l) byLang[l] = (byLang[l] || 0) + 1; lines += f.text.split('\n').length; }
  const langs = Object.entries(byLang).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([l, n]) => `${l} (${n})`).join(', ') || 'non déterminé';
  const deps = [];
  const pkg = project.files.find((f) => /(^|\/)package\.json$/.test(f.path));
  if (pkg) { try { const j = JSON.parse(pkg.text); deps.push(...Object.keys({ ...j.dependencies, ...j.devDependencies }).slice(0, 25)); } catch {} }
  const pub = project.files.find((f) => /(^|\/)pubspec\.yaml$/.test(f.path));
  if (pub) deps.push(...(pub.text.match(/^  [a-z_0-9]+:/gm) || []).map((s) => s.trim().replace(':', '')).slice(0, 25));
  const req = project.files.find((f) => /(^|\/)requirements\.txt$/.test(f.path));
  if (req) deps.push(...req.text.split('\n').map((l) => l.split(/[=<>~! ]/)[0].trim()).filter(Boolean).slice(0, 25));
  const tree = project.files.map((f) => f.path).sort().slice(0, 120);
  return { langs, lines, deps: [...new Set(deps)], tree, fileCount: project.files.length };
}

function score(file, qWords) {
  let s = 0;
  const p = file.path.toLowerCase();
  if (MANIFEST.test(file.path)) s += 60;
  if (ENTRY.test(file.path)) s += 45;
  if (/(^|\/)(routes?|controllers?|api|services?|core|lib|src)\//.test(p)) s += 12;
  if (/(^|\/)(tests?|__tests__|spec|docs?|examples?|assets|public\/(css|img))\//.test(p)) s -= 12;
  if (/\.(lock|min\.js|map|csv|tsv)$/i.test(p)) s -= 40;
  const lower = file.text.toLowerCase();
  for (const w of qWords) { if (p.includes(w)) s += 25; const hits = lower.split(w).length - 1; s += Math.min(18, hits * 2); }
  s -= Math.min(20, Math.floor(file.text.length / 8000));
  return s;
}

function heuristicSummary(file) {
  const lines = file.text.split('\n').map((l) => l.trim()).filter((l) => l && !/^[{}()[\];,]+$/.test(l));
  const decl = lines.filter((l) => /^(export |module\.exports|class |function |def |async function |const [A-Za-z_]+ = (require|async|\()|import )/.test(l)).slice(0, 4);
  return clip((decl.length ? decl : lines.slice(0, 3)).join(' | '), 220);
}

const SYS_REVIEW = "Tu es un ingénieur logiciel senior qui analyse un projet. Réponds en français, de façon précise et structurée (Markdown). Appuie-toi UNIQUEMENT sur le contenu fourni ; si une information manque, dis-le.";

/**
 * @param {Buffer} buffer archive
 * @param {string} question
 * @param {(p:{done:number,total:number,label:string})=>void} [onProgress]
 */
async function analyzeProject(buffer, question, onProgress = () => {}) {
  onProgress({ done: 0, total: 1, label: "Lecture de l'archive" });
  const project = await loadProject(buffer);
  if (!project.files.length) throw new Error("Aucun fichier texte exploitable dans l'archive (code, documents, configuration…).");
  const info = overview(project);
  const q = String(question || '').trim() || "Analyse ce projet : à quoi sert-il, comment est-il organisé, quelles sont ses forces et ses faiblesses, et que corriger en priorité ?";
  const qWords = words(q);
  const ranked = [...project.files].sort((a, b) => score(b, qWords) - score(a, qWords));
  const big = providers()[0]; // le fournisseur principal (Groq) ; s'il échoue ou si le projet est trop gros : voie 2 (Gemini en renfort)
  const head = `📦 *Aperçu du projet*\n• Fichiers analysables : ${info.fileCount} (sur ${project.totalEntries} dans l'archive)\n• Langages : ${info.langs}\n• ≈ ${info.lines.toLocaleString('fr-FR')} lignes${info.deps.length ? `\n• Dépendances : ${info.deps.slice(0, 15).join(', ')}` : ''}`;

  // ── Voie 1 : grand contexte, un seul appel ──
  if (big) {
    onProgress({ done: 0, total: 1, label: 'Analyse du projet' });
    const budget = Math.min(big.ctx, 90000) - q.length - 4000;
    let used = 0; const parts = []; const included = [];
    for (const f of ranked) {
      const block = `\n=== ${f.path} ===\n${clip(f.text, 7000)}\n`;
      if (used + block.length > budget) continue;
      parts.push(block); used += block.length; included.push(f.path);
    }
    const tree = info.tree.join('\n');
    const prompt = `Arborescence (extrait) :\n${tree}\n\nFichiers :\n${parts.join('')}\n\nQuestion : ${q}`;
    const answer = await safeAsk(big, prompt, SYS_REVIEW);
    if (answer) { onProgress({ done: 1, total: 1, label: 'Terminé' }); return { answer: `${answer}\n\n---\n${head}\n• Méthode : lecture directe de ${included.length} fichier(s)`, mode: 'direct', analyzed: included.length, total: info.fileCount }; }
    // si le grand modèle échoue, on retombe sur la voie 2
  }

  // ── Voie 2 : résumer chaque fichier important, puis synthétiser ──
  const picked = ranked.slice(0, 22);
  const total = picked.length + 1;
  const summaries = new Array(picked.length);
  let done = 0, next = 0;
  const worker = async () => {
    while (next < picked.length) {
      const i = next++; const f = picked[i];
      const text = `Fichier : ${f.path}\n---\n${clip(f.text, 2400)}`;
      let sum = '';
      try { sum = (await brain({ question: text, persona: "Résume en 1 ou 2 phrases le RÔLE de ce fichier de code (fonctions/classes principales, dépendances). Français, sans introduction.", })).text; } catch {}
      summaries[i] = { path: f.path, text: clip((sum || heuristicSummary(f)).replace(/\s+/g, ' '), 260) };
      onProgress({ done: ++done, total, label: `Résumé : ${f.path}` });
    }
  };
  await Promise.all([worker(), worker(), worker()]);

  let digest = `Projet : ${info.fileCount} fichiers, langages ${info.langs}.${info.deps.length ? ` Dépendances : ${info.deps.slice(0, 12).join(', ')}.` : ''}\nFichiers clés :\n`;
  for (const s of summaries) { const line = `- ${s.path} : ${s.text}\n`; if (digest.length + line.length + q.length > 3000) break; digest += line; }
  onProgress({ done, total, label: 'Rédaction de la réponse finale' });
  const final = await brain({ question: `${digest}\nQuestion : ${clip(q, 400)}`, persona: SYS_REVIEW });
  onProgress({ done: total, total, label: 'Terminé' });
  return { answer: `${final.text}\n\n---\n${head}\n• Méthode : résumé de ${summaries.length} fichier(s) clés puis synthèse.\n• ⚠️ Projet volumineux : l'analyse est partielle (fichiers les plus pertinents).`, mode: 'map-reduce', analyzed: summaries.length, total: info.fileCount };
}

// ══ Génération de projet ══
const GEN_SYS = `Tu es un générateur de projets. Réponds UNIQUEMENT avec les fichiers du projet, chacun dans ce format EXACT :
=== FILE: chemin/relatif/fichier.ext ===
contenu complet du fichier
=== END ===
Règles : 3 à 12 fichiers maximum, chemins relatifs, inclure un README.md court, code complet et fonctionnel, aucun texte en dehors des blocs.`;

function parseFiles(text) {
  const files = [];
  const re = /^={3}\s*FILE:\s*(.+?)\s*={3}[ \t]*\r?\n([\s\S]*?)(?:\r?\n={3}\s*END\s*={3}|(?=^={3}\s*FILE:)|$(?![\s\S]))/gm;
  let m;
  while ((m = re.exec(text))) {
    let body = m[2].replace(/^```[a-zA-Z0-9_+-]*\r?\n/, '').replace(/\r?\n```\s*$/, '');
    const p = cleanPath(m[1].replace(/^[`"']|[`"']$/g, ''));
    if (p) files.push({ path: p, content: body });
    if (!m[0].length) re.lastIndex++;
  }
  if (!files.length) {
    // repli : blocs de code Markdown (nom deviné via un commentaire « file: x » ou le langage)
    const defaults = { html: 'index.html', css: 'style.css', js: 'script.js', javascript: 'script.js', python: 'main.py', py: 'main.py', json: 'data.json', bash: 'run.sh', sh: 'run.sh', java: 'Main.java', dart: 'main.dart', php: 'index.php' };
    const used = new Set(); const rb = /```([a-zA-Z0-9_+-]*)\r?\n([\s\S]*?)```/g; let b;
    while ((b = rb.exec(text))) {
      const named = /(?:file|fichier|path)\s*[:=]\s*([\w./-]+)/i.exec(b[2].split('\n')[0] || '');
      let name = cleanPath(named ? named[1] : defaults[(b[1] || '').toLowerCase()] || `fichier${files.length + 1}.txt`);
      if (!name) continue; while (used.has(name)) name = `copie_${name}`; used.add(name);
      files.push({ path: name, content: b[2].replace(/\r?\n$/, '') });
    }
  }
  return files;
}

/** Fabrique une archive à partir d'une demande en langage naturel. */
async function generateProject(request, { format = 'zip', name = 'projet', extra = '', apikey = '' } = {}) {
  const res = await brain({ question: String(request).slice(0, 1500) + (extra ? `\n\n${String(extra).slice(0, 3200)}` : ''), persona: GEN_SYS });
  let files = parseFiles(res.text).slice(0, 40);
  if (!files.length) throw new Error("L'IA n'a pas produit de fichiers exploitables. Reformulez la demande (ex. « crée un site HTML/CSS/JS avec une page d'accueil »).");
  let total = 0; files = files.filter((f) => (total += Buffer.byteLength(f.content)) <= 2 * 1024 * 1024);
  if (!files.some((f) => /^readme(\.md)?$/i.test(f.path))) files.push({ path: 'README.md', content: `# ${name}\n\nProjet généré par Cypher Z (créé par Zidane).\n\n> Demande : ${String(request).slice(0, 300)}\n` });
  const fmt = format === 'tar.gz' || format === 'tgz' ? 'tar.gz' : 'zip';
  const buffer = fmt === 'zip' ? buildZip(files) : buildTarGz(files);
  const safe = (String(name).replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^-+|-+$/g, '') || 'projet').slice(0, 40);
  return { buffer, fileName: `${safe}.${fmt}`, mime: fmt === 'zip' ? 'application/zip' : 'application/gzip', files: files.map((f) => ({ path: f.path, size: Buffer.byteLength(f.content) })), models: res.models, notes: res.text.length };
}

module.exports = { loadProject, overview, analyzeProject, parseFiles, generateProject, score, words };
