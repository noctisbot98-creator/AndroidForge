// Journal d'activité : mémoire (anneau) + fichier JSONL hors du dossier public.
const fs = require('fs');
const path = require('path');

const DIR = path.resolve(__dirname, '../../activity');
const FILE = path.join(DIR, 'activity.jsonl');
const SETTINGS_FILE = path.join(DIR, 'settings.json');
const RING_MAX = 5000;
const ROTATE_BYTES = 5 * 1024 * 1024;

let ring = [];
let loaded = false;

function ensureDir() { try { fs.mkdirSync(DIR, { recursive: true }); } catch {} }

function load() {
  if (loaded) return;
  loaded = true;
  ensureDir();
  try {
    const lines = fs.readFileSync(FILE, 'utf8').split('\n').filter(Boolean).slice(-RING_MAX);
    ring = lines.map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  } catch { ring = []; }
}

function maskKey(key) {
  const k = String(key || '');
  if (!k) return null;
  return k.length <= 6 ? '***' : `${k.slice(0, 3)}…${k.slice(-2)}`;
}

function record(entry) {
  load();
  const row = { t: new Date().toISOString(), ...entry };
  ring.push(row);
  if (ring.length > RING_MAX) ring.shift();
  try {
    ensureDir();
    try { if (fs.statSync(FILE).size > ROTATE_BYTES) fs.renameSync(FILE, FILE + '.1'); } catch {}
    fs.appendFileSync(FILE, JSON.stringify(row) + '\n');
  } catch { /* disque indisponible : on garde la mémoire */ }
  return row;
}

function query({ limit = 200, type, mail, status, q, since } = {}) {
  load();
  const needle = q ? String(q).toLowerCase() : '';
  const out = [];
  for (let i = ring.length - 1; i >= 0 && out.length < Math.min(Number(limit) || 200, 1000); i--) {
    const r = ring[i];
    if (type && r.type !== type) continue;
    if (mail && String(r.mail || '').toLowerCase() !== String(mail).toLowerCase()) continue;
    if (status === 'error' && !(r.status >= 400)) continue;
    if (status === 'ok' && !(r.status < 400)) continue;
    if (since && r.t < since) continue;
    if (needle && !JSON.stringify(r).toLowerCase().includes(needle)) continue;
    out.push(r);
  }
  return out;
}

function all() { load(); return ring; }

function clear() {
  load();
  ring = [];
  try { fs.rmSync(FILE, { force: true }); fs.rmSync(FILE + '.1', { force: true }); } catch {}
}

function getSettings() {
  try { return { maintenance: false, blockedIps: [], ...JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')) }; }
  catch { return { maintenance: false, blockedIps: [] }; }
}

function setSettings(patch) {
  ensureDir();
  const next = { ...getSettings(), ...patch };
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(next, null, 2));
  return next;
}

module.exports = { record, query, all, clear, maskKey, getSettings, setSettings };
