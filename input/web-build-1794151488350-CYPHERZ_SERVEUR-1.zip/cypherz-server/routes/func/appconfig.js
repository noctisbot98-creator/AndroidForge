// Configuration de l'application mobile, modifiable depuis le panneau admin (sans recompiler l'APK).
const fs = require('fs');
const path = require('path');
const DIR = path.resolve(__dirname, '../../activity');
const FILE = path.join(DIR, 'appconfig.json');

const DEFAULTS = {
  announcement: '',          // bandeau affiché en haut du chat (vide = aucun)
  tagline: '',               // sous-titre (vide = celui de l'app)
  suggestions: [],           // suggestions d'accueil (vide = celles de l'app)
  personas: {},              // { "Nom": "consigne" } (vide = celles de l'app)
  defaultPersona: '',
  adminWhatsapp: '',         // chiffres uniquement, ex. 237621862134
  adminWhatsappDisplay: '',
  latestVersion: 0,          // numéro de build le plus récent
  minVersion: 0,             // en dessous : mise à jour obligatoire
  apkUrl: '',                // lien de téléchargement du nouvel APK
  updateMessage: '',
  signupEnabled: true,
  keyHelp: '',               // texte sous « Je n'ai pas de clé »
  guestEnabled: true,        // mode sans clé (questions/réponses seulement)
  guestDailyLimit: 20,       // messages par jour et par compte sans clé
};

const str = (v, n) => String(v == null ? '' : v).trim().slice(0, n);

function sanitize(input) {
  const b = input && typeof input === 'object' ? input : {};
  const personas = {};
  if (b.personas && typeof b.personas === 'object') {
    for (const [k, v] of Object.entries(b.personas).slice(0, 12)) {
      const name = str(k, 24), val = str(v, 700);
      if (name && val) personas[name] = val;
    }
  }
  const suggestions = (Array.isArray(b.suggestions) ? b.suggestions : []).map((s) => str(s, 160)).filter(Boolean).slice(0, 12);
  const apkUrl = str(b.apkUrl, 500);
  return {
    announcement: str(b.announcement, 300),
    tagline: str(b.tagline, 80),
    suggestions,
    personas,
    defaultPersona: str(b.defaultPersona, 700),
    adminWhatsapp: str(b.adminWhatsapp, 20).replace(/\D/g, ''),
    adminWhatsappDisplay: str(b.adminWhatsappDisplay, 30),
    latestVersion: Math.max(0, parseInt(b.latestVersion, 10) || 0),
    minVersion: Math.max(0, parseInt(b.minVersion, 10) || 0),
    apkUrl: /^https?:\/\//i.test(apkUrl) ? apkUrl : '',
    updateMessage: str(b.updateMessage, 300),
    signupEnabled: b.signupEnabled !== false && b.signupEnabled !== 'false',
    keyHelp: str(b.keyHelp, 200),
    guestEnabled: b.guestEnabled !== false && b.guestEnabled !== 'false',
    guestDailyLimit: Math.min(1000, Math.max(0, b.guestDailyLimit === '' || b.guestDailyLimit == null ? 20 : (parseInt(b.guestDailyLimit, 10) || 0))),
  };
}

function get() {
  try { return { ...DEFAULTS, ...sanitize(JSON.parse(fs.readFileSync(FILE, 'utf8'))) }; }
  catch { return { ...DEFAULTS }; }
}

function set(input) {
  const clean = sanitize(input);
  fs.mkdirSync(DIR, { recursive: true });
  const tmp = FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(clean, null, 2));
  fs.renameSync(tmp, FILE);
  return clean;
}

module.exports = { get, set, DEFAULTS };
