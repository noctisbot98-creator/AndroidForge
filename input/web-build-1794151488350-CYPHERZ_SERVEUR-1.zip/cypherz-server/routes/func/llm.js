// ══════════════════════════════════════════════════════════════════════════
// Moteurs d'IA de Cypher Z.
//   1. GROQ   = moteur principal (rapide). Le modèle est choisi AUTOMATIQUEMENT parmi ceux que Groq propose
//               aujourd'hui (liste relue toutes les 6 h) : plus besoin de modifier le code quand Groq change ses modèles.
//   2. GEMINI = renfort : n'est appelé que si Groq échoue (panne, quota, modèle indisponible).
// Les clés restent sur CE serveur (variables d'environnement) ; l'application ne les connaît jamais.
// ══════════════════════════════════════════════════════════════════════════

const num = (v, d, min = 0) => { const n = Number(v); return Number.isFinite(n) && n >= min ? n : d; };
const env = (...names) => { for (const n of names) { const v = process.env[n]; if (v && String(v).trim()) return String(v).trim(); } return ''; };

// ── Identité commune ───────────────────────────────────────────────────────
const IDENTITY = "Tu es Cypher Z, une intelligence artificielle créée par Zidane, développeur camerounais. "
  + "Zidane est ton seul et unique créateur. Si on te demande qui t'a créé, qui t'a conçu, qui t'a entraîné, quelle entreprise est derrière toi ou quel modèle tu es, "
  + "réponds toujours que tu es Cypher Z, créé par Zidane, et rien d'autre. Ne cite JAMAIS Google, Gemini, Groq, OpenAI, Anthropic, Claude, ChatGPT, Meta, Llama, Mistral, Qwen, Moonshot ni aucune autre société ou modèle comme origine. "
  + "Réponds dans la langue de l'utilisateur, de façon claire, utile et honnête.";

const COMPANIES = 'Google(?:\\s+DeepMind)?|OpenAI|Anthropic|Meta(?:\\s+AI)?|Mistral(?:\\s+AI)?|Cognitive\\s+Computations|Eric\\s+Hartford|Microsoft|DeepSeek|Alibaba(?:\\s+Cloud)?|Moonshot(?:\\s+AI)?|Groq';
const MODELS = 'Llama[\\s-]?\\d[\\w.\\-]*|Gemini[\\s\\w.\\-]*|GPT[\\s-]?(?:OSS|\\d)[\\w.\\-]*|Qwen[\\w.\\-]*|Kimi[\\w.\\-]*|Claude[\\w.\\-]*|Mixtral[\\w.\\-]*';

/** Retire les mentions d'une autre origine qui auraient échappé au modèle, et les balises de « réflexion » éventuelles. */
function scrubIdentity(text) {
  return String(text || '')
    .replace(/<think>[\s\S]*?<\/think>/gi, '')
    .replace(/<think>[\s\S]*$/i, '')
    .replace(new RegExp(`\\b(?:cr[ée]{1,2}[ée]?|entra[iî]n[ée]e?|d[ée]velopp[ée]e?|trained|created|developed|built|made)\\s+(?:par|by)\\s+(?:${COMPANIES})\\b`, 'gi'), (m) => (/par/i.test(m) ? 'créé par Zidane' : 'created by Zidane'))
    .replace(new RegExp(`\\b(je suis|i am|i'm)\\s+(?:un\\s+(?:mod[èe]le|assistant)\\s+(?:de langage\\s+)?(?:nomm[ée]\\s+|called\\s+)?)?(?:${MODELS})`, 'gi'), (m, a) => `${a} Cypher Z`)
    .replace(/\bGoogle\s+DeepMind\b/g, 'Zidane')
    .trim();
}

let _fetch = null;
function fetchImpl() { return _fetch || (_fetch = typeof globalThis.fetch === 'function' ? globalThis.fetch.bind(globalThis) : require('node-fetch')); }
async function timedFetch(url, init = {}, ms = 30000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try { return await fetchImpl()(url, { ...init, signal: ctrl.signal }); } finally { clearTimeout(t); }
}

// ══ GROQ ═══════════════════════════════════════════════════════════════════
const groqKey = () => env('GROQ_API_KEY', 'groq_api_key');
const groqBase = () => (env('GROQ_BASE_URL') || 'https://api.groq.com/openai/v1').replace(/\/+$/, '');

// Modèles de secours si la liste ne peut pas être lue (ordre = préférence).
const GROQ_FALLBACK = ['llama-3.3-70b-versatile', 'openai/gpt-oss-120b', 'openai/gpt-oss-20b', 'llama-3.1-8b-instant'];
// Préférences de qualité (le premier motif qui correspond gagne). Les modèles inconnus passent après, triés par taille.
const GROQ_PREFS = [
  /kimi-k2/i, /gpt-oss-120b/i, /llama-4-maverick/i, /llama-3\.3-70b/i, /qwen3?-?.*(32b|235b|80b)/i,
  /gpt-oss-20b/i, /llama-4-scout/i, /llama-3\.1-70b/i, /llama-3\.1-8b/i,
];
// À ne jamais utiliser pour discuter (audio, modération, voix, embeddings, agents).
const GROQ_SKIP = /(whisper|guard|safeguard|tts|orpheus|playai|embed|distil|compound|vision-preview|speech|transcri)/i;

let groqModels = [];          // classés, venant de Groq
let groqModelsAt = 0;
let groqListing = null;
const cooldown = new Map();   // modèle → timestamp jusqu'auquel on l'évite (429 / indisponible)

function sizeOf(id) { const m = String(id).match(/(\d+(?:\.\d+)?)b\b/i); return m ? Number(m[1]) : 0; }
function rankGroq(ids) {
  const usable = ids.filter((id) => !GROQ_SKIP.test(id));
  const score = (id) => { const i = GROQ_PREFS.findIndex((re) => re.test(id)); return i === -1 ? 100 - Math.min(sizeOf(id), 99) / 100 : i; };
  return [...usable].sort((a, b) => score(a) - score(b) || sizeOf(b) - sizeOf(a) || a.localeCompare(b));
}

/** Relit la liste des modèles disponibles chez Groq (au plus une fois par 6 h, ou sur demande). */
async function refreshGroqModels(force = false) {
  if (!groqKey()) return groqModels;
  const maxAge = num(env('GROQ_MODELS_REFRESH_MS'), 6 * 3600 * 1000, 60000);
  if (!force && groqModels.length && Date.now() - groqModelsAt < maxAge) return groqModels;
  if (groqListing) return groqListing;
  groqListing = (async () => {
    try {
      const r = await timedFetch(`${groqBase()}/models`, { headers: { Authorization: `Bearer ${groqKey()}` } }, 12000);
      const data = await r.json().catch(() => null);
      if (!r.ok || !data || !Array.isArray(data.data)) throw new Error(`HTTP ${r.status}`);
      const ids = data.data.filter((m) => m && m.id && m.active !== false).map((m) => String(m.id));
      const ranked = rankGroq(ids);
      if (ranked.length) { groqModels = ranked; groqModelsAt = Date.now(); }
    } catch (e) {
      if (!groqModels.length) groqModelsAt = Date.now() - maxAge + 60000; // on réessaie dans 1 min
    } finally { groqListing = null; }
    return groqModels;
  })();
  return groqListing;
}

/** Modèles Groq à essayer, du meilleur au moins bon (GROQ_MODEL, s'il est défini, passe en premier). */
function groqCandidates() {
  const forced = env('GROQ_MODEL', 'groq_model');
  const list = groqModels.length ? groqModels : GROQ_FALLBACK;
  const out = [];
  if (forced && forced.toLowerCase() !== 'auto') out.push(forced);
  for (const m of list) if (!out.includes(m)) out.push(m);
  const now = Date.now();
  const ready = out.filter((m) => (cooldown.get(m) || 0) <= now);
  return (ready.length ? ready : out).slice(0, num(env('GROQ_MAX_MODELS'), 3, 1));
}

async function groqOnce(model, question, system, maxTokens) {
  const r = await timedFetch(`${groqBase()}/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${groqKey()}` },
    body: JSON.stringify({
      model,
      messages: [{ role: 'system', content: system }, { role: 'user', content: question }],
      temperature: 0.6,
      max_tokens: maxTokens,
    }),
  }, num(env('REQUEST_TIMEOUT_MS'), 45000, 1000));
  const data = await r.json().catch(() => null);
  if (!r.ok) {
    const e = new Error((data && data.error && data.error.message) || `Groq HTTP ${r.status}`);
    e.upstreamStatus = r.status; e.code = data && data.error && data.error.code;
    throw e;
  }
  const text = scrubIdentity((((data.choices || [])[0] || {}).message || {}).content || '');
  if (!text) throw new Error('Réponse vide.');
  return text;
}

/** @returns {Promise<{text:string, model:string}>} */
async function askGroq(question, { system = '', maxTokens = 4096 } = {}) {
  if (!groqKey()) { const e = new Error('Groq non configuré.'); e.statusCode = 503; throw e; }
  const sys = system ? `${IDENTITY}\n\n${system}` : IDENTITY;
  await refreshGroqModels();
  let last;
  for (const model of groqCandidates()) {
    try { return { text: await groqOnce(model, question, sys, maxTokens), model: 'groq' }; }
    catch (e) {
      last = e;
      const st = e.upstreamStatus;
      if (st === 429 || st === 503) cooldown.set(model, Date.now() + 60 * 1000);
      if (st === 404 || e.code === 'model_decommissioned' || e.code === 'model_not_found') { cooldown.set(model, Date.now() + 6 * 3600 * 1000); groqModelsAt = 0; }
      if (st === 401 || st === 403) break; // clé refusée : inutile d'essayer les autres modèles
      if (st === 413) continue;            // trop long pour ce modèle : le suivant a peut-être plus de marge
    }
  }
  const err = new Error(last && last.message ? last.message : 'Groq est indisponible.'); err.statusCode = 503; throw err;
}

// ══ GEMINI (renfort) ═══════════════════════════════════════════════════════
const GEMINI_MODELS = ['gemini-3.5-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-3-flash-preview', 'gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-2.5-pro'];
const geminiModel = () => { const m = env('GEMINI_MODEL', 'gemini_model'); return m || 'gemini-3.5-flash'; };
const geminiKey = () => env('GEMINI_API_KEY', 'gemini_api_key');
const geminiBase = () => (env('GEMINI_BASE_URL') || 'https://generativelanguage.googleapis.com').replace(/\/+$/, '');

async function geminiOnce(model, question, system, maxTokens) {
  const r = await timedFetch(`${geminiBase()}/v1beta/models/${model}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': geminiKey() },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: system }] },
      contents: [{ role: 'user', parts: [{ text: question }] }],
      generationConfig: { temperature: 0.7, maxOutputTokens: maxTokens },
    }),
  }, num(env('REQUEST_TIMEOUT_MS'), 45000, 1000));
  const data = await r.json().catch(() => null);
  if (!r.ok) { const e = new Error((data && data.error && data.error.message) || `Gemini HTTP ${r.status}`); e.upstreamStatus = r.status; throw e; }
  if (data && data.promptFeedback && data.promptFeedback.blockReason) throw new Error(`Demande bloquée (${data.promptFeedback.blockReason}).`);
  const parts = (((data.candidates || [])[0] || {}).content || {}).parts || [];
  const text = parts.filter((p) => !p.thought && typeof p.text === 'string').map((p) => p.text).join('').trim();
  if (!text) throw new Error('Réponse vide.');
  return text;
}

/** @returns {Promise<{text:string, model:string}>} */
async function askGemini(question, { system = '', maxTokens = 4096 } = {}) {
  if (!geminiKey()) { const e = new Error('Gemini non configuré.'); e.statusCode = 503; throw e; }
  const sys = system ? `${IDENTITY}\n\n${system}` : IDENTITY;
  const models = [geminiModel(), ...GEMINI_MODELS.filter((m) => m !== geminiModel())].slice(0, 2);
  let last;
  for (const m of models) {
    try { return { text: scrubIdentity(await geminiOnce(m, question, sys, maxTokens)), model: 'gemini' }; }
    catch (e) { last = e; if (e.upstreamStatus === 401 || e.upstreamStatus === 403) break; }
  }
  const err = new Error(last && last.message ? last.message : 'Gemini est indisponible.'); err.statusCode = 503; throw err;
}

function warmUp() {
  if (!groqKey()) return;
  refreshGroqModels(true).catch(() => {});
  setInterval(() => { refreshGroqModels(true).catch(() => {}); }, num(env('GROQ_MODELS_REFRESH_MS'), 6 * 3600 * 1000, 60000)).unref();
}

const status = () => ({
  groq: { configured: !!groqKey(), models: groqCandidates() },
  gemini: { configured: !!geminiKey(), role: 'renfort' },
});

module.exports = {
  IDENTITY, scrubIdentity, askGroq, askGemini,
  hasGroq: () => !!groqKey(), hasGemini: () => !!geminiKey(),
  status, warmUp, refreshGroqModels, rankGroq,
  _setFetch: (f) => { _fetch = f; },
  _reset: () => { groqModels = []; groqModelsAt = 0; cooldown.clear(); },
};
