// Secret de signature des sessions (JWT). Jamais de valeur par défaut connue : sinon n'importe qui pourrait fabriquer un faux jeton.
//  • JWT_SECRET (variable d'environnement) s'il est défini (≥ 16 caractères) ;
//  • sinon un secret aléatoire est créé une fois et conservé dans data/jwt-secret.txt.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const FILE = path.resolve(__dirname, '../../data/jwt-secret.txt');
let cached = '';
function jwtSecret() {
  if (cached) return cached;
  const fromEnv = String(process.env.JWT_SECRET || '').trim();
  if (fromEnv.length >= 16) return (cached = fromEnv);
  try { const v = fs.readFileSync(FILE, 'utf8').trim(); if (v.length >= 32) return (cached = v); } catch {}
  const v = crypto.randomBytes(48).toString('hex');
  try { fs.mkdirSync(path.dirname(FILE), { recursive: true }); fs.writeFileSync(FILE, v, { mode: 0o600 }); } catch {}
  return (cached = v);
}
module.exports = { jwtSecret };
