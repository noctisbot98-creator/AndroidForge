// Quota total de requêtes par compte (valeur unique utilisée partout)
const ADMIN_WHATSAPP = '+237621862134';
const ADMIN_WA_LINK = 'https://wa.me/237621862134';

function getLimit(user) {
  const free = Number(process.env.free_user_limit || 20);
  const prem = Number(process.env.premium_user_limit || 1000000);
  const admins = String(process.env.ADMIN_EMAILS || 'zidanetedoum9@gmail.com').split(',').map((x) => x.trim().toLowerCase()).filter(Boolean);
  if (user && user.mail && admins.includes(String(user.mail).toLowerCase())) return prem; // le compte administrateur est illimité (clé utilisée par le bot et l'application)
  const c = user && user.customLimit;
  if (c !== null && c !== undefined && c !== '' && Number.isFinite(Number(c))) return Number(c);
  return user && user.isPremium ? prem : free;
}

// Coût (en requêtes) des fonctions IA coûteuses ; tout le reste coûte 1. Le suivi d'un job et le téléchargement sont gratuits.
const COSTS = { '/ai/image': 2, '/ai/project': 5, '/ai/generate': 5 };
const FREE_PATHS = [/^\/proxyfile$/, /^\/ai\/job\/[\w-]+$/, /^\/ai\/download\/[\w-]+$/, /^\/ai\/status$/];
function costFor(reqPath) {
  const p = String(reqPath || '').split('?')[0].replace(/\/+$/, '');
  if (FREE_PATHS.some((r) => r.test(p))) return 0;
  return COSTS[p] || 1;
}

module.exports = { costFor, getLimit, ADMIN_WHATSAPP, ADMIN_WA_LINK };
