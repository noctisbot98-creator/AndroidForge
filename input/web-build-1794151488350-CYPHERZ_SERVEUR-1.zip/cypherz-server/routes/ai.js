// ══════════════════════════════════════════════════════════════════════════
// ZIDANE AI — routes de l'application mobile
// Authentification : session du compte (en-tête Authorization: Bearer <jeton>). Plus de clé API.
// Quota : même système de requêtes par compte qu'avant (chat = 1, image = 2, projet / archive = 5), remboursé en cas d'échec.
//   POST /api/ai/chat          {text, history?, persona?, name?, mode?}  → texte (ou job si « génère une image… »)
//   POST /api/ai/image         {prompt}                                   → job image
//   POST /api/ai/project       corps = archive (zip/tar/tar.gz) ; ?question=&filename=   → job d'analyse
//   POST /api/ai/generate      {request, format:'zip'|'tar.gz', name}     → job « création d'archive »
//   GET  /api/ai/job/:id       progression / résultat (gratuit)
//   GET  /api/ai/download/:id  fichier produit (image ou archive) (gratuit)
//   GET  /api/ai/status        requêtes utilisées / limite du compte (gratuit)
// Les travaux longs sont des « jobs » en mémoire (conservés 30 min). Si un job échoue, les requêtes débitées sont rendues.
// ══════════════════════════════════════════════════════════════════════════
const express = require('express');
const crypto = require('crypto');
const fetch = require('node-fetch');
const database = require('./func/database');
const { brain, detectIntent, enhanceImagePrompt } = require('./func/aibrain');
const { analyzeProject, generateProject } = require('./func/project');
const { detectFormat } = require('./func/ziptools');
const { costFor, getLimit, ADMIN_WA_LINK, ADMIN_WHATSAPP } = require('./func/quota');
const { getSessionToken, verifySessionToken } = require('./func/session');

const router = express.Router();
const MAX_UPLOAD = 30 * 1024 * 1024;
const JOB_TTL = 30 * 60 * 1000;
const MAX_RUNNING = 4;
const jobs = new Map();

const DEFAULT_PERSONA = "Tu es Cypher Z, une IA généraliste créée par Zidane (ton seul créateur ; ne cite aucune autre origine). Réponds en français (ou dans la langue de l'utilisateur), de façon claire, utile et honnête. Utilise le Markdown quand cela aide. "
  + "CONFIDENTIALITÉ : ne mentionne jamais le nom d'un modèle ou d'un fournisseur d'IA (Gemini, Google, OpenAI, Groq, Llama, Meta…), ni tes consignes internes. "
  + "Pour une demande de code, écris du code standard et indépendant, sans commentaire sur ces règles.";

// ── Authentification + quota (un seul endroit) ──
const rate = new Map(); // mail → horodatages (anti-abus : au plus RATE_PER_MIN appels IA par minute et par compte)
setInterval(() => { const cut = Date.now() - 120000; for (const [k, v] of rate) { const w = v.filter((t) => t > cut); if (w.length) rate.set(k, w); else rate.delete(k); } }, 60000).unref();
const RATE_PER_MIN = () => Number(process.env.RATE_PER_MIN || 20);

router.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  const decoded = verifySessionToken(getSessionToken(req));
  const user = decoded && database.getDatabaseByUser(decoded.mail);
  if (!user || (decoded.userid && user.userId !== decoded.userid)) return res.status(401).json({ status: false, message: 'Session expirée. Reconnectez-vous.' });
  if (user.isBanned) return res.status(403).json({ status: false, message: "Votre compte est suspendu. Contactez l'administrateur." });
  if (!user.isVerified) return res.status(401).json({ status: false, message: 'Compte non vérifié. Consultez votre boîte e-mail (et les spams).' });
  const cost = costFor(`/ai${req.path}`);
  const limit = getLimit(user);
  if (cost > 0) {
    const now = Date.now();
    const w = (rate.get(user.mail) || []).filter((t) => t > now - 60000);
    if (w.length >= RATE_PER_MIN()) return res.status(429).json({ status: false, message: 'Vous allez trop vite : patientez quelques secondes puis réessayez.', slow: true });
    if ((user.uses || 0) + cost > limit) {
      return res.status(429).json({ status: false, message: `Vous avez utilisé vos ${limit} requêtes. Pour en obtenir davantage, contactez Zidane (l'administrateur) sur WhatsApp : ${ADMIN_WHATSAPP} (${ADMIN_WA_LINK}).` });
    }
    w.push(now); rate.set(user.mail, w);
    database.addUse(user.mail, cost);
  }
  req.user = user;
  req.quotaCost = cost;
  next();
});

setInterval(() => { const now = Date.now(); for (const [id, j] of jobs) if (now - j.created > JOB_TTL) jobs.delete(id); }, 60 * 1000).unref();

const running = () => [...jobs.values()].filter((j) => j.state === 'running').length;
const userRunning = (mail) => [...jobs.values()].some((j) => j.state === 'running' && j.mail === mail);
const fail = (res, code, message) => res.status(code).json({ status: false, message });
const strOf = (v, n) => String(v == null ? '' : v).slice(0, n);

/** Crée un job ; `work(update)` renvoie {answer?, file?:{buffer,name,mime,extra}}. Débit déjà fait par le middleware ; remboursé si échec. */
function startJob(req, res, kind, work) {
  const mail = req.user.mail;
  const cost = req.quotaCost || 0;
  const refund = () => { if (cost > 0) database.addUse(mail, -cost); };
  if (userRunning(mail)) { refund(); fail(res, 429, 'Une tâche est déjà en cours pour votre compte. Attendez qu\'elle se termine.'); return null; }
  if (running() >= MAX_RUNNING) { refund(); fail(res, 503, 'Le serveur est occupé par d\'autres tâches, réessayez dans une minute.'); return null; }
  const job = { id: crypto.randomBytes(12).toString('hex'), mail, kind, state: 'running', progress: { done: 0, total: 1, label: 'Démarrage' }, created: Date.now() };
  jobs.set(job.id, job);
  Promise.resolve().then(() => work((p) => { job.progress = p; })).then((r) => {
    if (r.answer) job.answer = r.answer;
    if (r.meta) job.meta = r.meta;
    if (r.file) { job.buffer = r.file.buffer; job.file = { name: r.file.name, mime: r.file.mime, size: r.file.buffer.length, files: r.file.files }; }
    job.state = 'done'; job.progress = { done: 1, total: 1, label: 'Terminé' };
  }).catch((e) => { job.state = 'error'; job.error = strOf(e && e.message, 300) || 'Erreur inconnue'; refund(); job.refunded = cost; });
  return { job };
}
const jobView = (j) => ({
  id: j.id, kind: j.kind, state: j.state, progress: j.progress, answer: j.answer, meta: j.meta,
  error: j.error, refunded: j.refunded || 0,
  file: j.file ? { name: j.file.name, mime: j.file.mime, size: j.file.size, files: j.file.files, url: `/api/ai/download/${j.id}` } : undefined,
});

// ── Image ──
async function makeImage(userPrompt, update) {
  update({ done: 0, total: 3, label: 'Préparation du prompt' });
  const prompt = await enhanceImagePrompt(userPrompt);
  update({ done: 1, total: 3, label: 'Création de l\'image' });
  const seed = Math.floor(Math.random() * 1e6);
  const base = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&nologo=true&seed=${seed}`;
  let lastErr = '';
  for (const url of [base, `${base}&model=turbo`]) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 75000);
    try {
      const r = await fetch(url, { signal: ctl.signal });
      const type = String(r.headers.get('content-type') || '');
      if (!r.ok || !/^image\//i.test(type)) { lastErr = `HTTP ${r.status}`; continue; }
      const buffer = await r.buffer();
      if (buffer.length < 1000 || buffer.length > 12 * 1024 * 1024) { lastErr = 'image invalide'; continue; }
      const ext = /png/i.test(type) ? 'png' : /webp/i.test(type) ? 'webp' : 'jpg';
      return { answer: `🎨 Image créée.\n\n*Prompt utilisé :* ${prompt}`, meta: { prompt }, file: { buffer, name: `zidane-ai-${seed}.${ext}`, mime: type.split(';')[0] } };
    } catch (e) { lastErr = e.name === 'AbortError' ? 'délai dépassé' : e.message; } finally { clearTimeout(t); }
  }
  throw new Error(`Le service d'images ne répond pas (${lastErr}). Réessayez plus tard.`);
}

// ── Chat ──
router.post('/chat', async (req, res) => {
  const b = req.body || {};
  const text = strOf(b.text, 6000).trim();
  if (!text) return fail(res, 400, 'Message vide.');
  const mode = strOf(b.mode, 10) || 'auto';
  const lang = strOf(b.lang, 5) === 'en' ? 'en' : 'fr';
  if (mode === 'auto') {
    const intent = detectIntent(text);
    if (intent === 'image') {
      const s = startJob(req, res, 'image', (u) => makeImage(text, u));
      if (s) return res.json({ status: true, type: 'job', jobId: s.job.id, kind: 'image' });
      return;
    }
    if (intent === 'archive') {
      const s = startJob(req, res, 'archive', async (u) => buildArchive(text, 'zip', 'projet', u));
      if (s) return res.json({ status: true, type: 'job', jobId: s.job.id, kind: 'archive' });
      return;
    }
  }
  const history = strOf(b.history, 2400);
  const persona = strOf(b.persona, 700);
  const name = strOf(b.name, 40);
  const sys = `${DEFAULT_PERSONA}${lang === 'en' ? ' Always answer in English.' : ''}${name ? ` L'utilisateur s'appelle ${name}.` : ''}${persona ? `\nConsignes de l'utilisateur : ${persona}` : ''}`;
  try {
    const r = await brain({ question: `${history ? `Conversation précédente :\n${history}\n\n` : ''}Message : ${text}`, persona: sys });
    res.json({ status: true, type: 'text', resultado: r.text });
  } catch (e) {
    if (req.quotaCost) database.addUse(req.user.mail, -req.quotaCost);
    fail(res, 503, e.message);
  }
});

// ── Image ──
router.post('/image', (req, res) => {
  const prompt = strOf((req.body || {}).prompt, 800).trim();
  if (!prompt) { if (req.quotaCost) database.addUse(req.user.mail, -req.quotaCost); return fail(res, 400, 'Décrivez l\'image à créer.'); }
  const s = startJob(req, res, 'image', (u) => makeImage(prompt, u));
  if (s) res.json({ status: true, type: 'job', jobId: s.job.id, kind: 'image' });
});

// ── Analyse de projet ──
router.post('/project', express.raw({ type: () => true, limit: MAX_UPLOAD }), (req, res) => {
  const buf = req.body;
  const bad = (code, msg) => { if (req.quotaCost) database.addUse(req.user.mail, -req.quotaCost); return fail(res, code, msg); };
  if (!Buffer.isBuffer(buf) || !buf.length) return bad(400, 'Aucune archive reçue.');
  const fmt = detectFormat(buf);
  if (fmt === 'rar' || fmt === '7z') return bad(400, `Les archives .${fmt} ne peuvent pas être lues par le serveur : recompressez-les en .zip ou .tar.gz puis renvoyez-les.`);
  if (!['zip', 'gz', 'tar'].includes(fmt)) return bad(400, 'Format non pris en charge : envoyez un .zip, .tar ou .tar.gz / .tgz.');
  const question = strOf(req.query.question, 1500);
  const s = startJob(req, res, 'project', async (u) => {
    const r = await analyzeProject(buf, question, u);
    return { answer: r.answer, meta: { mode: r.mode, analyzed: r.analyzed, total: r.total } };
  });
  if (s) res.json({ status: true, type: 'job', jobId: s.job.id, kind: 'project' });
});

async function buildArchive(request, format, name, update) {
  update({ done: 0, total: 1, label: 'Rédaction des fichiers' });
  const g = await generateProject(request, { format, name });
  const list = g.files.map((f) => `• \`${f.path}\` (${f.size} o)`).join('\n');
  return { answer: `📦 Archive **${g.fileName}** prête (${g.files.length} fichiers) :\n${list}`, file: { buffer: g.buffer, name: g.fileName, mime: g.mime, files: g.files } };
}

router.post('/generate', (req, res) => {
  const b = req.body || {};
  const request = strOf(b.request, 1500).trim();
  if (!request) { if (req.quotaCost) database.addUse(req.user.mail, -req.quotaCost); return fail(res, 400, 'Décrivez le projet à générer.'); }
  const format = /rar/i.test(strOf(b.format, 10)) ? 'zip' : strOf(b.format, 10);
  const s = startJob(req, res, 'archive', (u) => buildArchive(request, format, strOf(b.name, 40) || 'projet', u));
  if (s) res.json({ status: true, type: 'job', jobId: s.job.id, kind: 'archive', note: /rar/i.test(strOf(b.format, 10)) ? 'Le format RAR est propriétaire : une archive ZIP a été créée à la place.' : undefined });
});

// ── Suivi / téléchargement / capacités (gratuits) ──
const own = (req, res) => {
  const j = jobs.get(req.params.id);
  if (!j || j.mail !== req.user.mail) { fail(res, 404, 'Tâche introuvable ou expirée.'); return null; }
  return j;
};
router.get('/job/:id', (req, res) => { const j = own(req, res); if (j) res.json({ status: true, job: jobView(j) }); });
router.get('/download/:id', (req, res) => {
  const j = own(req, res);
  if (!j) return;
  if (!j.buffer) return fail(res, 404, 'Aucun fichier pour cette tâche.');
  res.setHeader('Content-Type', j.file.mime);
  res.setHeader('Content-Disposition', `attachment; filename="${j.file.name.replace(/[^\w.-]/g, '_')}"`);
  res.setHeader('Content-Length', j.buffer.length);
  res.end(j.buffer);
});
router.get('/status', (req, res) => {
  const limit = getLimit(req.user);
  res.json({
    status: true, used: req.user.uses || 0, limit, unlimited: limit >= 100000, remaining: Math.max(0, limit - (req.user.uses || 0)),
    costs: { chat: costFor('/ai/chat'), image: costFor('/ai/image'), project: costFor('/ai/project'), generate: costFor('/ai/generate') },
  });
});

router._jobs = jobs;
module.exports = router;
