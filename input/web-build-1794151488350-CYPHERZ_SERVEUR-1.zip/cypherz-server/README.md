# Cypher Z — serveur (autonome)

Comptes + quota de requêtes + IA. **Groq d'abord, Gemini seulement en renfort.** Aucune page d'API, aucun lien avec l'ancien projet.

## Installer
1. `npm install` puis copie `example.env` en `.env` et remplis au minimum `GROQ_API_KEY` (et `GEMINI_API_KEY` pour le renfort).
2. `npm start` (port 2035 par défaut, ou `PORT`).
3. Dans l'application, `lib/config.dart` → `defaultBaseUrl` doit pointer vers ce serveur (ou compile avec `--dart-define=CYPHERZ_SERVER=https://...`).

## Garder les comptes existants
Copie l'ancien `database.json` à la racine de ce dossier (mêmes utilisateurs, mots de passe, compteurs). Mets le même `JWT_SECRET` que l'ancien serveur pour que les gens restent connectés.

## Groq toujours à jour
Le serveur relit la liste des modèles Groq au démarrage puis toutes les 6 h et choisit le meilleur disponible (audio/modération exclus). Si un modèle est retiré ou saturé, il essaie le suivant avant de passer à Gemini. `GROQ_MODEL=auto` (défaut) ou un nom précis pour l'imposer.

## Sécurité
- Les clés ne sont QUE dans l'environnement du serveur ; l'application n'en contient aucune.
- Chaque appel IA exige une session de compte, vérifie le quota, et est limité (`RATE_PER_MIN`/minute/compte). Connexion/inscription limitées par IP.
- Secret de session : jamais de valeur par défaut connue (aléatoire et conservé si `JWT_SECRET` est absent).
- Le contenu des messages n'est pas écrit dans les journaux.
- Panneau admin : `/admin` (comptes admin = `ADMIN_EMAILS`). « Tester Groq et Gemini » vérifie les clés.
- Mets le serveur derrière HTTPS (proxy/hébergeur) : sinon mots de passe et jetons circulent en clair.

## Tests
`npm test` (moteurs IA : Groq → Gemini, modèles retirés, identité).
